import { useEffect, useState, useCallback } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Avatar, AvatarFallback, AvatarImage } from "../../components/ui/avatar";
import { Button } from "../../components/ui/button";
import { Settings, Plus, MoreVertical } from "lucide-react";
import { staffApi } from "../../api";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { showErrorToast, showSuccessToast } from "@/utils/toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../../components/ui/dropdown-menu";
import { useTranslation } from "react-i18next";
import { MasterListLayout } from '@/components/layout/master-list-layout';

export default function StaffList() {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const pageSize = 10;
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [filter] = useState({
    is_active: "",
    role_code: "",
    joined_at_start: "",
    joined_at_end: ""
  });
  const { t } = useTranslation();
  const [error, setError] = useState(null);
  const [totalPages, setTotalPages] = useState(1);

  useBreadcrumb(t('staff.staff_list'), '/staffs');

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await staffApi.getStaff({
        page,
        pagesize: pageSize,
        keyword: search,
        filters: {
          ...(filter.is_active && { is_active: filter.is_active }),
          ...(filter.role_code && { role_code: filter.role_code }),
          ...(filter.joined_at_start && { joined_at_start: filter.joined_at_start }),
          ...(filter.joined_at_end && { joined_at_end: filter.joined_at_end }),
        }
      });
      if (result.success) {
        setData(result.items || []);
        setTotal(result.total || 0);
        setTotalPages(Math.ceil((result.total || 0) / pageSize));
      } else {
        setError(result.error || t("errors.staffList"));
        setData([]);
        setTotal(0);
        setTotalPages(1);
      }
    } catch {
      setError(t("errors.staffList"));
      setData([]);
      setTotal(0);
      setTotalPages(1);
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, search, filter, t]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (search.length === 0 || search.length > 3) {
        fetchData();
      }
    }, 400);
    return () => clearTimeout(timeout);
  }, [fetchData, search.length]);

  const handleDelete = async (id) => {
    try {
      const result = await staffApi.deleteStaff(id);
      if (result.success) {
        showSuccessToast(t("success.deleteStaff"));
        fetchData();
      } else {
        showErrorToast(result.error || t('errors.delete_staff'));
      }
    } catch {
      showErrorToast(t('errors.delete_staff'));
    }
  };

  // Define columns for DataTable
  const columns = [
    {
      key: 'name',
      header: t('staff.staff_name'),
      width: '300px',
      cellRenderer: (user) => (
        <div 
          className="flex items-center gap-3 cursor-pointer"
          onClick={() => navigate(`/staffs/${user.user_id}`)}
        >
          <Avatar className="h-8 w-8">
            <AvatarImage src={user.avatar} alt={user.full_name} />
            <AvatarFallback className="bg-muted text-muted-foreground text-[12px] font-semibold">
              {user.full_name ? user.full_name.substring(0, 2).toUpperCase() : "NV"}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="text-sm font-medium text-[#020617]">{user.full_name}</div>
            <div className="text-xs text-[#64748B]">{user.user_code}</div>
          </div>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-gray-200 animate-pulse"></div>
          <div className="space-y-2">
            <div className="h-4 w-[180px] bg-gray-200 rounded animate-pulse"></div>
            <div className="h-3 w-[100px] bg-gray-200 rounded animate-pulse"></div>
          </div>
        </div>
      )
    },
    {
      key: 'roles',
      header: t('staff.role'),
      width: '200px',
      cellRenderer: (user) => (
        <div className="flex gap-2">
          <span className="px-2 py-1 text-xs font-medium text-brand bg-brand-lighter rounded-full">
            {user.roles && user.roles.length > 0 ? user.roles[0].name : t('staff.unassigned_role')}
          </span>
          {user.roles && user.roles.length > 1 && (
            <span className="px-2 py-1 text-xs font-medium text-brand bg-brand-lighter rounded-full">
              +{user.roles.length - 1}
            </span>
          )}
        </div>
      ),
      skeletonRenderer: () => (
        <div className="h-6 w-[100px] bg-gray-200 rounded-full animate-pulse"></div>
      )
    },
    {
      key: 'phone_number',
      header: t('personal.phone'),
      width: '150px',
      cellRenderer: (user) => <span className="text-[#020617]">{user.phone_number || "-"}</span>,
      skeletonWidth: 'w-[120px]'
    },
    {
      key: 'email',
      header: t('personal.email'),
      width: '200px',
      cellRenderer: (user) => <span className="text-[#020617]">{user.email || "-"}</span>,
      skeletonWidth: 'w-[150px]'
    },
    {
      key: 'actions',
      header: '',
      width: '120px',
      align: 'right',
      cellRenderer: (user) => (
        <div className="flex items-center justify-end gap-3">
          <Button
            variant="link"
            className="text-brand hover:text-brand/90 p-0 h-auto font-medium"
            onClick={() => navigate(`/staffs/${user.user_id}`)}
          >
            {t('common.detail')}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7 hover:bg-[#F8FAFC]">
                <MoreVertical className="h-4 w-4 text-brand" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[160px]">
              <DropdownMenuItem asChild className="py-2 text-[13px] text-[#0F172A] hover:text-brand cursor-pointer">
                <Link to={`/staffs/${user.user_id}/edit`}>{t('common.edit')}</Link>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="py-2 text-[13px] text-[#0F172A] hover:text-brand cursor-pointer"
                onClick={() => handleDelete(user.user_id)}
              >
                {t('common.delete')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex items-center justify-end gap-3">
          <div className="h-4 w-[50px] bg-gray-200 rounded animate-pulse"></div>
          <div className="h-7 w-7 bg-gray-200 rounded-md animate-pulse"></div>
        </div>
      )
    }
  ];

  return (
    <MasterListLayout
      title={t('staff.staff_list')}
      searchPlaceholder={t('staff.search_staff_placeholder')}
      searchValue={search}
      onSearchChange={(value) => {
        setSearch(value);
        if (page !== 1) setPage(1);
      }}
      columns={columns}
      data={data}
      loading={loading}
      error={error}
      currentPage={page}
      totalPages={totalPages}
      onPageChange={setPage}
      totalItems={total}
      itemsLabel={t('staff.staff').toLowerCase()}
      emptyTitle={t('no_staff', 'Chưa có nhân viên nào')}
      emptySubtitle={t('no_staff_subtitle', 'Khi có nhân viên, họ sẽ xuất hiện tại đây.')}
      emptyButtonText={t('common.addNew', 'Thêm mới')}
      onEmptyAction={() => navigate('/staffs/create')}
      emptyButtonIcon={<Plus className="w-4 h-4" />}
      showAddButton={true}
      addButtonText={t('common.addNew')}
      onAddClick={() => navigate('/staffs/create')}
      additionalActions={
        <Button variant="outline" size="sm" className="h-9 flex items-center gap-2">
          <Settings className="w-3.5 h-3.5" />
          {t('staff.permissions_group')}
        </Button>
      }
    />
  );
} 