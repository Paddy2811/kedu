import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { 
  PencilLine, Copy, CheckCircle, CircleUser, NotebookTabs, 
  NotepadText, Building2, Users2, BookText, UserRound 
} from "lucide-react";

// Components
import MainLayout from "../../components/layout/main-layout";
import { PageContainer } from "@/components/page-container";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Pagination } from "@/components/ui/pagination";
import { PlaceholderText } from "@/components/ui/placeholder-text";

// Hooks and utils
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { formatDateDMY } from "@/lib/utils";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { getFullAddress } from "@/utils/address";

// API and constants
import { staffApi } from "@/api";
import { GENDER_OPTIONS } from "@/data/constants";

// Mock data for courses
const MOCK_COURSES = Array(9).fill(null).map((_, index) => ({
  id: index + 1,
  name: "Toán cơ bản 1",
  status: "active",
  branch: "Cơ sở Cửa Bắc",
  type: "Toán - Cơ bản",
  students: "1/10"
}));

// Component for copyable text field
const CopyableText = ({ value, type, onCopy, isCopied }) => (
  <div className="flex items-center gap-1">
    <div className="text-[13px] text-[#0F172A]">
      <PlaceholderText value={value} />
    </div>
    <button 
      onClick={() => onCopy(value, type)}
      className="p-0.5 hover:bg-[#F8FAFC] rounded"
    >
      {isCopied ? (
        <CheckCircle className="w-3.5 h-3.5 text-[#008A2E]" />
      ) : (
        <Copy className="w-3.5 h-3.5 text-[#64748B]" />
      )}
    </button>
  </div>
);

// Component for info field
const InfoField = ({ label, value, className = "" }) => (
  <div className={className}>
    <span className="text-[13px] text-[#64748B]">{label}</span>
    <div className="text-[13px] text-[#0F172A] mt-1">
      <PlaceholderText value={value} />
    </div>
  </div>
);

// Component for section header
const SectionHeader = ({ icon, title }) => {
  const Icon = icon;
  return (
    <div className="flex items-center gap-2 mb-4">
      <Icon className="w-4 h-4 text-[#0F172A]" />
      <h3 className="text-[15px] font-medium text-[#0F172A]">{title}</h3>
    </div>
  );
};

// Loading skeleton for profile card
const ProfileCardSkeleton = () => (
  <div className="flex items-center gap-3">
    <Skeleton className="w-10 h-10 rounded-lg" />
    <div className="flex flex-col gap-2">
      <Skeleton className="w-32 h-5" />
      <div className="flex gap-8">
        <div className="flex flex-col gap-1">
          <Skeleton className="w-20 h-4" />
          <Skeleton className="w-16 h-4" />
        </div>
        <div className="flex flex-col gap-1">
          <Skeleton className="w-20 h-4" />
          <Skeleton className="w-24 h-4" />
        </div>
        <div className="flex flex-col gap-1">
          <Skeleton className="w-20 h-4" />
          <Skeleton className="w-32 h-4" />
        </div>
      </div>
    </div>
  </div>
);

// Course card component
const CourseCard = ({ course, t }) => (
  <div className="rounded-xl border border-[#E2E8F0] bg-white p-4">
    <div className="flex items-center justify-between mb-3">
      <h3 className="text-[15px] font-medium text-[#0F172A]">{course.name}</h3>
      <span className="px-2 py-1 bg-[#F0FDF4] text-[#008A2E] text-[13px] rounded whitespace-nowrap">
        {course.status === 'active' ? t('class.active_status') : course.status}
      </span>
    </div>
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Building2 className="w-4 h-4 text-[#64748B]" />
        <span className="text-[13px] text-[#64748B]">{course.branch}</span>
      </div>
      <div className="grid grid-cols-2 gap-6">
        <div className="flex items-center gap-2">
          <BookText className="w-4 h-4 text-[#64748B]" />
          <span className="text-[13px] text-[#64748B]">{course.type}</span>
        </div>
        <div className="flex items-center gap-2">
          <Users2 className="w-4 h-4 text-[#64748B]" />
          <span className="text-[13px] text-[#64748B]">{course.students}</span>
        </div>
      </div>
    </div>
  </div>
);

// Personal information section component
const PersonalInfoSection = ({ staff, t }) => (
  <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
    <SectionHeader icon={CircleUser} title={t('personal.personal_info')} />
    <div className="grid grid-cols-3 gap-4">
      <InfoField 
        label={t('staff.role')} 
        value={staff?.roles?.map(role => role.name).join(', ')} 
      />
      <InfoField 
        label={t('personal.gender')} 
        value={staff?.gender ? (GENDER_OPTIONS.find(option => option.value === staff.gender)?.label): ''} 
      />
      <InfoField 
        label={t('personal.dob')} 
        value={formatDateDMY(staff?.dob)} 
      />
    </div>
  </div>
);

// Contact information section component
const ContactInfoSection = ({ staff, t, onCopy, copiedPhone, copiedEmail }) => (
  <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
    <SectionHeader icon={NotebookTabs} title={t('personal.contact_info')} />
    <div className="grid grid-cols-3 gap-4">
      <div>
        <span className="text-[13px] text-[#64748B]">{t('personal.phone_staff')}</span>
        <div className="mt-1">
          <CopyableText 
            value={staff?.phone_number} 
            type="phone"
            onCopy={onCopy}
            isCopied={copiedPhone}
          />
        </div>
      </div>
      <div>
        <span className="text-[13px] text-[#64748B]">{t('personal.email')}</span>
        <div className="mt-1">
          <CopyableText 
            value={staff?.email} 
            type="email"
            onCopy={onCopy}
            isCopied={copiedEmail}
          />
        </div>
      </div>
      <InfoField 
        label={t('personal.emergency_contact')} 
        value={staff?.emergency_contact ? `${staff.emergency_contact}${staff?.emergency_relationship ? ` (${staff.emergency_relationship})` : ''}` : ''} 
      />
      <InfoField 
        label={t('personal.address')} 
        value={getFullAddress(staff?.address, staff?.city, staff?.district, staff?.ward)} 
        className="col-span-3"
      />
    </div>
  </div>
);

// Notes section component
const NotesSection = ({ staff, t }) => (
  <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
    <SectionHeader icon={NotepadText} title={t('personal.notes_comments')} />
    <div className="mt-1">
      <div className="text-[13px] text-[#0F172A]">
        <PlaceholderText value={staff?.note} />
      </div>
    </div>
  </div>
);

// General info tab content
const GeneralInfoTab = ({ staff, t, isLoading, onCopy, copiedPhone, copiedEmail }) => {
  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="w-full h-[120px] rounded-xl" />
        <Skeleton className="w-full h-[180px] rounded-xl" />
        <Skeleton className="w-full h-[100px] rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <PersonalInfoSection staff={staff} t={t} />
      <ContactInfoSection 
        staff={staff} 
        t={t} 
        onCopy={onCopy}
        copiedPhone={copiedPhone}
        copiedEmail={copiedEmail}
      />
      <NotesSection staff={staff} t={t} />
    </div>
  );
};

// Courses tab content
const CoursesTab = ({ paginatedCourses, totalCourses, currentPage, totalPages, setCurrentPage, t }) => (
  <div>
    <div className="flex items-center justify-between mb-4">
      <p className="text-[13px] text-[#64748B]">
        {t('common.total')}: {totalCourses} {t('course.courses').toLowerCase()}
      </p>
    </div>
    <div className="grid grid-cols-3 gap-4 mb-6">
      {paginatedCourses.map((course) => (
        <CourseCard key={course.id} course={course} t={t} />
      ))}
    </div>
    
    <Pagination
      currentPage={currentPage}
      totalPages={totalPages}
      onPageChange={setCurrentPage}
      className="px-1"
    />
  </div>
);

export default function StaffDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("courses");
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [staff, setStaff] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const { t } = useTranslation();
  
  const itemsPerPage = 3;
  const totalPages = Math.ceil(MOCK_COURSES.length / itemsPerPage);

  const paginatedCourses = MOCK_COURSES.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Set breadcrumbs
  useBreadcrumb(t('staff.staff_list'), '/staffs');
  useBreadcrumb(t('staff.staff_detail'));

  // Fetch staff details
  useEffect(() => {
    const fetchStaffDetail = async () => {
      try {
        setIsLoading(true);
        const result = await staffApi.getStaffById(id);
        if (result.success) {
          setStaff(result.data);
        } else {
          throw new Error(result.error || t('errors.generic'));
        }
      } catch (err) {
        setStaff(null);
        showErrorToast(err.message || t('errors.generic'));
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchStaffDetail();
  }, [id, t]);

  // Handle copy to clipboard
  const handleCopyToClipboard = useCallback(async (text, type) => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'phone') {
        setCopiedPhone(true);
        setTimeout(() => setCopiedPhone(false), 2000);
        showSuccessToast(t('success.copy_phone_success'));
      } else if (type === 'email') {
        setCopiedEmail(true);
        setTimeout(() => setCopiedEmail(false), 2000);
        showSuccessToast(t('success.copy_email_success'));
      }
    } catch (error) {
      showErrorToast(t('error.copy_error'));
      console.error('Copy to clipboard error:', error);
    }
  }, [t]);

  return (
    <MainLayout>
      <PageContainer title={t('staff.staff_detail')}>
        <div>
          {/* Profile Card */}
          <div className="w-full rounded-xl border border-[#E2E8F0] bg-white mb-4">
            <div className="p-6 flex justify-between">
              {isLoading ? (
                <>
                  <ProfileCardSkeleton />
                  <Skeleton className="w-[100px] h-9" />
                </>
              ) : (
                <>
                  <div className="flex gap-5">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                        <UserRound size={24} className="text-muted-foreground"/>
                    </div>
                    <div className="flex flex-col">
                      <h2 className="text-[18px] font-semibold text-[#0F172A] mb-2">
                        <PlaceholderText value={staff?.full_name} />
                      </h2>
                      <div className="flex gap-8">
                        <InfoField label={t('personal.staff_code')} value={staff?.user_code} />
                        <InfoField label={t('staff.role')} value={staff?.roles?.map(role => role.name).join(', ')} />
                        <div>
                          <span className="text-[13px] text-[#64748B]">{t('personal.phone_staff')}</span>
                          <div className="text-[13px] text-[#0F172A] mt-1">
                            <CopyableText 
                              value={staff?.phone_number} 
                              type="phone"
                              onCopy={handleCopyToClipboard}
                              isCopied={copiedPhone}
                            />
                          </div>
                        </div>
                        <div>
                          <span className="text-[13px] text-[#64748B]">{t('personal.email')}</span>
                          <div className="text-[13px] text-[#0F172A] mt-1">
                            <CopyableText 
                              value={staff?.email} 
                              type="email"
                              onCopy={handleCopyToClipboard}
                              isCopied={copiedEmail}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Button 
                    onClick={() => navigate(`/staffs/${id}/edit`)}
                    variant="outline" 
                  >
                    <PencilLine className="w-4 h-4 mr-2" />
                    {t('common.edit')}
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="bg-[#F8FAFC] p-1 h-auto rounded-lg mb-4 border border-[#E2E8F0]">
              <TabsTrigger 
                value="courses"
                className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
              >
                {t('course.courses')}
              </TabsTrigger>
              <TabsTrigger 
                value="general"
                className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
              >
                {t('staff.general_info', 'Thông tin chung')}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="courses">
              <CoursesTab 
                paginatedCourses={paginatedCourses}
                totalCourses={MOCK_COURSES.length}
                  currentPage={currentPage}
                  totalPages={totalPages}
                setCurrentPage={setCurrentPage}
                t={t}
                />
            </TabsContent>

            <TabsContent value="general">
              <GeneralInfoTab 
                staff={staff}
                t={t}
                isLoading={isLoading}
                onCopy={handleCopyToClipboard}
                copiedPhone={copiedPhone}
                copiedEmail={copiedEmail}
              />
            </TabsContent>
          </Tabs>
        </div>
      </PageContainer>
    </MainLayout>
  );
} 