import { useState, useEffect } from "react";
import { useNavigate, Link, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DatePicker } from "@/components/ui/date-picker";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import MainLayout from "@/components/layout/main-layout";
import { provinces, getDistricts, getWards } from "@/data/vietnam-provinces";
import { GENDER_OPTIONS } from "@/data/constants";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { PageContainer } from "@/components/page-container";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { ERROR_MESSAGES } from "@/data/constants";
import { Combobox } from "@/components/ui/combobox";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { roleApi, staffApi } from "@/api";
import { useTranslation } from "react-i18next";

export default function CreateStaff() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = Boolean(id);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [roleOptions, setRoleOptions] = useState([]);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone_number: "",
    dob: "",
    gender: "",
    city: "",
    district: "",
    ward: "",
    address: "",
    note: "",
    emergency_contact: "",
    emergency_relationship: "",
    roles: []
  });

  // State for districts and wards based on selected province/district
  const [districts, setDistricts] = useState([]);
  const [wards, setWards] = useState([]);

  const { t } = useTranslation();

  // Fetch staff data if editing
  useEffect(() => {
    if (isEditing) {
      const fetchStaffData = async () => {
        setLoading(true);
        try {
          const result = await staffApi.getStaffById(id);
          if (result.success && result.data) {
            const staffData = result.data;
            setFormData({
              full_name: staffData.full_name || "",
              email: staffData.email || "",
              phone_number: staffData.phone_number || "",
              dob: staffData.dob || "",
              gender: staffData.gender || "",
              city: staffData.city || "",
              district: staffData.district || "",
              ward: staffData.ward || "",
              address: staffData.address || "",
              note: staffData.note || "",
              emergency_contact: staffData.emergency_contact || "",
              emergency_relationship: staffData.emergency_relationship || "",
              roles: Array.isArray(staffData.roles) ? staffData.roles.map(r => r.code) : []
            });

            // Set districts and wards if city/district is selected
            if (staffData.city) {
              setDistricts(getDistricts(staffData.city));
              if (staffData.district) {
                setWards(getWards(staffData.city, staffData.district));
              }
            }
          } else {
            showErrorToast(ERROR_MESSAGES.LOAD_STUDENT_ERROR);
            navigate("/staffs");
          }
        } catch {
          showErrorToast(ERROR_MESSAGES.LOAD_STUDENT_ERROR);
          navigate("/staffs");
        } finally {
          setLoading(false);
        }
      };

        fetchStaffData();
    }
  }, [id, isEditing, navigate]);

  useEffect(() => {
    const fetchRoleOptions = async () => {
      setLoading(true);
      try {
        const [rolesRes] = await Promise.all([
          roleApi.getRoles(),
        ]);
        setRoleOptions(rolesRes.items || []);
      } catch {
        showErrorToast(t('errors.load_role_data'));
        navigate("/staffs");
      } finally {
        setLoading(false);
      }
    };
    fetchRoleOptions();
  }, [navigate, t]);

const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Reset dependent fields when province/district changes
    if (name === 'city') {
      setFormData(prev => ({
        ...prev,
        district: '',
        ward: '',
        [name]: value
      }));
      setDistricts(getDistricts(value));
      setWards([]);
    } else if (name === 'district') {
      setFormData(prev => ({
        ...prev,
        ward: '',
        [name]: value
      }));
      setWards(getWards(formData.city, value));
    }

    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: null
      }));
    }
  };

  const handleRolesChange = (value) => {
    setFormData(prev => ({
      ...prev,
      roles: value ? [value] : [] // Convert single value to array
    }));
    if (errors.roles) {
      setErrors(prev => ({
        ...prev,
        roles: null
      }));
    }
  };

  const getErrorMessage = (error) => {
    if (Array.isArray(error)) {
      // Pydantic error array
      return error.map(e => e.msg || JSON.stringify(e)).join(', ');
    }
    if (typeof error === 'object' && error !== null) {
      if (error.detail && Array.isArray(error.detail)) {
        return error.detail.map(e => e.msg || JSON.stringify(e)).join(', ');
      }
      return error.msg || JSON.stringify(error);
    }
    return error;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate form data
      const validation = staffApi.validateStaffData(formData);
      if (!validation.isValid) {
        setErrors(validation.errors);
        showErrorToast(t('errors.required_fields'));
        setLoading(false);
        return;
      }

      // Prepare data for API
      const {
        full_name,
        phone_number,
        email,
        dob,
        gender,
        city,
        district,
        ward,
        address,
        note,
        emergency_contact,
        emergency_relationship,
        roles
      } = formData;

      const staffData = {
        full_name: full_name.trim(),
        phone_number: phone_number.trim(),
        email: email?.trim() || undefined,
        dob: dob || undefined,
        gender: gender || undefined,
        city: city || undefined,
        district: district || undefined,
        ward: ward || undefined,
        address: address?.trim() || undefined,
        note: note?.trim() || undefined,
        emergency_contact: emergency_contact?.trim() || undefined,
        emergency_relationship: emergency_relationship?.trim() || undefined,
        roles: Array.isArray(roles) ? roles : roles ? [roles] : []
      };

      let result;
      if (isEditing) {
        result = await staffApi.updateStaff(id, staffData);
      } else {
        result = await staffApi.createStaff(staffData);
      }
      
      if (result.success) {
        showSuccessToast(isEditing ? t('success.updateStaff') : t('success.createStaff'));
        navigate(isEditing ? `/staffs/${id}` : "/staffs");
      } else {
        setLoading(false);
        setErrors(result.error ? { api: getErrorMessage(result.error) } : {});
        showErrorToast(getErrorMessage(result.error) || ERROR_MESSAGES.LOAD_STAFF_ERROR);
      }
    } catch (err) {
      setLoading(false);
      showErrorToast(
        getErrorMessage(err?.response?.data?.error) || ERROR_MESSAGES.LOAD_STAFF_ERROR
      );
    }
  };

  useBreadcrumb(t('staffs'), '/staffs');
  useBreadcrumb(isEditing ? t('staff.update_staff') : t('staff.create_staff'));

  const provinceOptions = provinces;

  return (
    <MainLayout>
      <PageContainer title={isEditing ? t('staff.update_staff') : t('staff.create_staff')}>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Row 1: Họ và tên, Số điện thoại, Email */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label htmlFor="full_name" className="text-sm font-medium text-[#344054]">
                {t('personal.full_name')} <span className="text-red-500">*</span>
              </Label>
              <Input
                id="full_name"
                name="full_name"
                placeholder={t('personal.enter_full_name_placeholder')}
                value={formData.full_name}
                onChange={handleInputChange}
                className={`h-9 px-3 py-2 bg-white ${errors.full_name ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FEE4E2]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.full_name && (
                <span className="text-sm text-[#F04438]">{errors.full_name}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="phone_number" className="text-sm font-medium text-[#344054]">
                {t('personal.phone')} <span className="text-red-500">*</span>
              </Label>
              <Input
                id="phone_number"
                name="phone_number"
                placeholder={t('personal.enter_phone_placeholder')}
                value={formData.phone_number}
                onChange={handleInputChange}
                disabled={isEditing}
                className={`h-9 px-3 py-2 ${isEditing ? "bg-[#F5F5F5] text-[#71717A]" : "bg-white"} ${errors.phone_number ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FEE4E2]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.phone_number && (
                <span className="text-sm text-[#F04438]">{errors.phone_number}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="email" className="text-sm font-medium text-[#344054]">
                {t('personal.email')}
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder={t('personal.enter_email_placeholder')}
                value={formData.email}
                onChange={handleInputChange}
                className={`h-9 px-3 py-2 bg-white ${errors.email ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FEE4E2]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.email && (
                <span className="text-sm text-[#F04438]">{errors.email}</span>
              )}
            </div>
          </div>
          
          {/* Row 2: Role, Ngày sinh, Giới tính */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#344054]">
                {t('staff.role')}
              </Label>
              <Select
                value={formData.roles && formData.roles.length > 0 ? formData.roles[0] : ""}
                onValueChange={handleRolesChange}
              >
                <SelectTrigger className="w-full h-9 px-3 py-2 bg-white border border-[#E4E4E7] text-sm" id="roles">
                  <SelectValue placeholder={t('staff.select_role_placeholder', 'Chọn vai trò')} />
                </SelectTrigger>
                <SelectContent>
                  {roleOptions.map(t => (
                    <SelectItem key={t.code} value={t.code+''}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="dob" className="text-sm font-medium text-[#344054]">
                {t('personal.dob')}
              </Label>
              <DatePicker
                value={formData.dob}
                onChange={(v)=>handleInputChange({target:{name:'dob', value:v}})}
                placeholder={t('personal.select_dob_placeholder')}
                className={`h-9 ${errors.dob ? 'border-[#FDA29B]' : 'border-[#E4E4E7]'}`}
              />
              {errors.dob && (
                <span className="text-sm text-[#F04438]">{errors.dob}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="gender" className="text-sm font-medium text-[#344054]">
                {t('personal.gender')}
              </Label>
              <Select
                value={formData.gender}
                onValueChange={(v)=>handleInputChange({target:{name:'gender', value:v}})}
              >
                <SelectTrigger className="w-full h-9 px-3 py-2 bg-white border border-[#E4E4E7] text-sm">
                  <SelectValue placeholder={t('personal.select_gender_placeholder')} />
                </SelectTrigger>
                <SelectContent className="max-h-60 overflow-y-auto">
                  {GENDER_OPTIONS.map(option => (
                    <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Row 3: Tỉnh/Thành phố, Quận/Huyện, Phường/Xã */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label htmlFor="city" className="text-sm font-medium text-[#344054]">
                {t('facility.province')}
              </Label>
              <Combobox
                options={provinceOptions.map(p=>({value:p.code,label:p.name}))}
                value={formData.city}
                onChange={(value)=>handleInputChange({target:{name:'city',value}})}
                placeholder={t('facility.select_province_placeholder')}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="district" className="text-sm font-medium text-[#344054]">
                {t('facility.district')}
              </Label>
              <Combobox
                options={districts.map(d=>({value:d.code,label:d.name}))}
                value={formData.district}
                onChange={(value)=>handleInputChange({target:{name:'district',value}})}
                placeholder={t('facility.select_district_placeholder')}
                disabled={!formData.city}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="ward" className="text-sm font-medium text-[#344054]">
                {t('facility.ward')}
              </Label>
              <Combobox
                options={wards.map(w=>({value:w.code,label:w.name}))}
                value={formData.ward}
                onChange={(value)=>handleInputChange({target:{name:'ward',value}})}
                placeholder={t('facility.select_ward_placeholder')}
                disabled={!formData.district}
              />
            </div>
          </div>

          {/* Row 4: Địa chỉ cụ thể */}
          <div className="space-y-1">
            <Label htmlFor="address" className="text-sm font-medium text-[#344054]">
              {t('personal.address_specific')}
            </Label>
            <Input
              id="address"
              name="address"
              placeholder={t('facility.enter_address_placeholder')}
              value={formData.address}
              onChange={handleInputChange}
              className="h-9 px-3 py-2 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"
            />
          </div>

          {/* Row 5: Liên hệ khẩn cấp */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="emergency_contact" className="text-sm font-medium text-[#344054]">
                {t('personal.emergency_contact')}
              </Label>
              <Input
                id="emergency_contact"
                name="emergency_contact"
                placeholder={t('personal.enter_emergency_contact_placeholder', 'Nhập số điện thoại liên hệ khẩn cấp')}
                value={formData.emergency_contact}
                onChange={handleInputChange}
                className="h-9 px-3 py-2 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="emergency_relationship" className="text-sm font-medium text-[#344054]">
                {t('personal.emergency_relationship', 'Mối quan hệ')}
              </Label>
              <Input
                id="emergency_relationship"
                name="emergency_relationship"
                placeholder={t('personal.enter_emergency_relationship_placeholder', 'Nhập mối quan hệ')}
                value={formData.emergency_relationship}
                onChange={handleInputChange}
                className="h-9 px-3 py-2 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"
              />
            </div>
          </div>

          {/* Row 6: Ghi chú */}
          <div className="space-y-1">
            <Label htmlFor="note" className="text-sm font-medium text-[#344054]">
              {t('common.note')}
            </Label>
            <Textarea
              id="note"
              name="note"
              placeholder={t('common.enter_note_placeholder')}
              value={formData.note}
              onChange={handleInputChange}
              className="min-h-[80px] px-3 py-2 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7] resize-none"
            />
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(isEditing ? `/staffs/${id}` : "/staffs")}
              className="h-9 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB]"
            >
              {t('common.cancel')}
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className={`h-9 px-4 py-2 bg-brand hover:bg-brand/90 text-white font-medium ${
                loading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {loading ? t('common.processing') : (isEditing ? t('common.update') : t('common.create'))}
            </Button>
          </div>
        </form>
      </PageContainer>
    </MainLayout>
  );
} 