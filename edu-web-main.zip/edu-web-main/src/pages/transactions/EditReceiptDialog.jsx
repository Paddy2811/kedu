import { useState, useEffect, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { Loader2 } from "lucide-react";

import {
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogClose,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PrefilledInput } from "@/components/ui/prefilled-input";
import { Badge } from "@/components/ui/badge";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { formatNumber, formatDateTime } from "@/lib/utils";
import { getFinancialLogStatusBadge, PaymentMethod, updateFinancialLog, getFinancialLogDetail } from "@/api/services/financial_logs";

// Validate form data before submission
const validateReceiptData = (data, t) => {
  const errors = {};
  if (!data.payment_method) {
    errors.payment_method = t("error_missing_receipt_method", "Please select payment method");
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export function EditReceiptDialog({ open, onOpenChange, onSuccess, receiptId }) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [isLoadingDetail, setIsLoadingDetail] = useState(false);
  const [errors, setErrors] = useState({});

  
  // Form state
  const [formData, setFormData] = useState({
    code: "",
    created_by: "",
    created_by_full_name: "",
    created_at: "",
    status: "",
    amount: "",
    payment_method: "",
    note: ""
  });

  // Fetch receipt detail when dialog opens
  const fetchReceiptDetail = useCallback(async () => {
    if (!receiptId) return;
    
    setIsLoadingDetail(true);
    setErrors({});
    
    try {
      const response = await getFinancialLogDetail(receiptId);
      
      if (response.success) {
        setFormData({
          code: response.data.code || "",
          created_by: response.data.created_by || "",
          created_by_full_name: response.data.created_by_full_name || "",
          created_at: response.data.created_at || "",
          status: response.data.status || "",
          amount: response.data.amount || "",
          payment_method: response.data.payment_method || "",
          note: response.data.note || ""
        });
      } else {
        showErrorToast(
          t("error.receipt_update_error", "Error updating receipt"),
          response.error
        );
      }
    } catch (error) {
      console.error("Error fetching receipt detail:", error);
      showErrorToast(
        t("error.receipt_update_error", "Error updating receipt"),
        error.message
      );
    } finally {
      setIsLoadingDetail(false);
    }
  }, [receiptId, t]);

  // Fetch detail when dialog opens
  useEffect(() => {
    if (open && receiptId) {
      fetchReceiptDetail();
    }
  }, [open, receiptId, fetchReceiptDetail]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!open) {
      setFormData({
        code: "",
        created_by: "",
        created_by_full_name: "",
        created_at: "",
        status: "",
        amount: "",
        payment_method: "",
        note: ""
      });
      setErrors({});
    }
  }, [open]);

  // Payment methods (use enum values for id, i18n for label)
  const paymentMethods = [
    { id: PaymentMethod.CASH, name: t("transaction.payment_method_cash", "Tiền mặt") },
    { id: PaymentMethod.BANK_TRANSFER, name: t("transaction.payment_method_bank_transfer", "Chuyển khoản") },
  ];

  // Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };



  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors({});
    
    // Validate form
    const validation = validateReceiptData(formData, t);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }
    
    setLoading(true);
    try {
      // Only send note and payment_method
      const updateData = {
        note: formData.note,
        payment_method: formData.payment_method,
      };
      const response = await updateFinancialLog(receiptId, updateData);
      if (response.success) {
      showSuccessToast(t("success.receipt_updated_success", "Receipt updated successfully"));
      onOpenChange(false);
      if (onSuccess) {
          onSuccess(response.data);
        }
      } else {
        showErrorToast(
          t("error.receipt_update_error", "Error updating receipt"),
          response.error
        );
      }
    } catch (error) {
      console.error("Error updating receipt:", error);
      showErrorToast(
        t("error.receipt_update_error", "Error updating receipt"),
        error.message
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="sm:max-w-[600px] p-6"
        style={{ 
          boxShadow: "0px 4px 6px -4px rgba(0, 0, 0, 0.1), 0px 10px 15px -3px rgba(0, 0, 0, 0.1)"
        }}
      >
        <DialogHeader className="space-y-1">
          <DialogTitle className="text-lg font-semibold text-[#020617]">
            {t("transaction.edit_receipt", "Chỉnh sửa phiếu thu")}
          </DialogTitle>
          <DialogDescription className="text-[#64748B] text-sm">
            {t("transaction.edit_receipt_description", "Nhấn lưu để lưu lại các chỉnh sửa phiếu")}
          </DialogDescription>
        </DialogHeader>
        
        {isLoadingDetail ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="w-6 h-6 text-[#E67364] animate-spin" />
            <span className="ml-2 text-[#71717A]">{t("common.loading")}</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Receipt Info Section */}
            <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-sm font-medium text-[#64748B]">
                  {t("receipt_code", "Mã phiếu thu")}
                </Label>
                <div className="text-sm text-[#09090B]">{formData.code}</div>
              </div>
              
              <div className="space-y-1">
                <Label className="text-sm font-medium text-[#64748B]">
                  {t("common.status", "Trạng thái")}
                </Label>
                <div>
                  {formData.status && (
                    <Badge 
                      variant="outline" 
                      className={getFinancialLogStatusBadge(formData.status, t).className}
                    >
                      {getFinancialLogStatusBadge(formData.status, t).label}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-sm font-medium text-[#64748B]">
                  {t("transaction.created_by", "Người lập phiếu")}
                </Label>
                <div className="text-sm text-[#09090B]">{formData.created_by_full_name}</div>
              </div>
              
              <div className="space-y-1">
                <Label className="text-sm font-medium text-[#64748B]">
                  {t("transaction.created_date", "Thời gian lập phiếu")}
                </Label>
                <div className="text-sm text-[#09090B]">{formData.created_at ? formatDateTime(formData.created_at) : ""}</div>
              </div>
            </div>
          </div>
          
          {/* Receipt Amount and Payment Method */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="amount" className="text-sm font-medium text-[#344054] flex items-center">
                {t("receipt_amount", "Giá trị phiếu thu")}
                <span className="text-[#DC2626] ml-1">*</span>
              </Label>
              <PrefilledInput
                id="amount"
                name="amount"
                value={formatNumber(formData.amount)}
                postfix="đ"
              />
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="payment_method" className="text-sm font-medium text-[#344054] flex items-center">
                {t("transaction.payment_method", "Phương thức thanh toán")}
                <span className="text-[#DC2626] ml-1">*</span>
              </Label>
              <PrefilledInput
                id="payment_method"
                name="payment_method"
                value={paymentMethods.find(method => method.id === formData.payment_method)?.name || formData.payment_method}
              />
              {errors.payment_method && (
                <span className="text-sm text-[#F04438]">{errors.payment_method}</span>
              )}
            </div>
          </div>
          
          {/* Note */}
          <div className="space-y-1">
            <Label htmlFor="note" className="text-sm font-medium text-[#344054]">
              {t("common.note", "Ghi chú")}
            </Label>
            <Input
              id="note"
              name="note"
              value={formData.note}
              onChange={handleChange}
              placeholder={t("common.enter_note", "Nhập ghi chú")}
            />
          </div>
          
          <DialogFooter className="pt-4 flex justify-end gap-2">
            <DialogClose asChild>
              <Button 
                type="button" 
                variant="outline" 
                className="h-10 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB] rounded-md font-semibold"
              >
                {t("common.cancel", "Hủy bỏ")}
              </Button>
            </DialogClose>
            <Button 
              type="submit" 
              disabled={loading}
              className={`h-10 px-4 py-2 bg-[#E67364] hover:bg-[#d66559] text-white font-semibold rounded-md ${
                loading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {loading ? t("common.saving", "Đang lưu...") : t("common.save", "Lưu")}
            </Button>
          </DialogFooter>
        </form>
        )}
      </DialogContent>
    </Dialog>
  );
} 