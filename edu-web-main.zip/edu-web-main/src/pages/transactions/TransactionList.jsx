import React, { useState, useEffect, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { Filter, SquarePen, Plus, Search } from "lucide-react";
import { format } from "date-fns";

import { MasterListLayout } from "@/components/layout/master-list-layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SkeletonRenderers } from "@/components/ui/data-table";
import { showErrorToast } from "@/utils/toast";
import { Input } from "@/components/ui/input";
// Import will be used when API is implemented
// import { transactionApi } from "@/api/services/transaction";
import { Skeleton } from "@/components/ui/skeleton";
import { CreatePaymentDialog } from "./CreatePaymentDialog";
import { EditPaymentDialog } from "./EditPaymentDialog";
import { EditReceiptDialog } from "./EditReceiptDialog";
import { FinancialLogType, getFinancialLogs, FinancialLogStatus, getFinancialLogStatusBadge } from "@/api/services/financial_logs";
import { CreateReceiptDialog } from "./CreateReceiptDialog";

// Remove MOCK_TRANSACTIONS and all related mock data code

const TransactionList = () => {
  const { t } = useTranslation();

  // State
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [keyword, setKeyword] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [isReceiptDialogOpen, setIsReceiptDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [isEditPaymentDialogOpen, setIsEditPaymentDialogOpen] = useState(false);
  const [isEditReceiptDialogOpen, setIsEditReceiptDialogOpen] = useState(false);
  const [selectedPaymentId, setSelectedPaymentId] = useState(null);
  const [selectedReceiptId, setSelectedReceiptId] = useState(null);

  // Helper function to format UTC date to local time
  const formatDateTime = useCallback((dateString, formatPattern = "dd/MM/yyyy HH:mm") => {
    if (!dateString) return "";
    try {
      let date;
      // Handle different date string formats from server
      if (dateString.includes('T')) {
        // If it's ISO format but missing 'Z', assume it's UTC
        if (!dateString.endsWith('Z') && !dateString.includes('+') && !dateString.includes('-', 10)) {
          // Add 'Z' to indicate UTC time
          const utcDateString = dateString + 'Z';
          date = new Date(utcDateString);
        } else {
          // Already has timezone info
          date = new Date(dateString);
        }
      } else {
        // If it's not ISO format, try to parse as is
        date = new Date(dateString);
      }
      // Check if date is valid
      if (isNaN(date.getTime())) {
        console.warn("Invalid date string:", dateString);
        return dateString; // Return original string if parsing fails
      }
      // Format using date-fns with the client's local timezone
      const formattedDate = format(date, formatPattern);
      return formattedDate;
    } catch (error) {
      console.error("Error formatting date:", error, "Original:", dateString);
      return dateString; // Return original string if error occurs
    }
  }, []);
  
  // Fetch transactions
  const fetchTransactions = useCallback(async (page = 1) => {
    setLoading(true);
    setError(null);
    try {
      // Only call API if keyword is empty or has at least 3 characters
      if (keyword && keyword.length < 3) {
        setTransactions([]);
        setCurrentPage(1);
        setTotalPages(1);
        setTotalItems(0);
        setLoading(false);
        return;
      }
      const response = await getFinancialLogs({
        page,
        pagesize: 10,
        keyword,
      });
      if (response.success) {
        setTransactions(response.data);
        setCurrentPage(response.pagination.currentPage);
        setTotalPages(response.pagination.totalPages);
        setTotalItems(response.pagination.totalItems);
      } else {
        throw new Error(response.error || t("errors.load_transaction_list"));
      }
    } catch (error) {
      setError(error.message);
      showErrorToast(t("errors.load_transaction_list"), error);
    } finally {
      setLoading(false);
    }
  }, [t, keyword]);

  // Initial data load
  useEffect(() => {
    fetchTransactions(1);
  }, [fetchTransactions]);

  // Handle page change
  const handlePageChange = (page) => {
    setCurrentPage(page);
    fetchTransactions(page);
  };

  // Handle search
  const handleSearch = (value) => {
    setKeyword(value);
    setCurrentPage(1);
  };

  // Handle create receipt
  const handleCreateReceipt = (receiptData) => {
    console.log("Receipt created:", receiptData);
    fetchTransactions(currentPage);
  };

  // Handle edit payment
  const handleEditPayment = (paymentData) => {
    console.log("Payment updated:", paymentData);
    fetchTransactions(currentPage);
  };

  // Handle edit receipt
  const handleEditReceipt = (receiptData) => {
    console.log("Receipt updated:", receiptData);
    fetchTransactions(currentPage);
  };

  // Handle create payment
  const handleCreatePayment = (paymentData) => {
    console.log("Payment created:", paymentData);
    fetchTransactions(currentPage);
  };

  // Open edit payment dialog
  const openEditPaymentDialog = (payment) => {
    setSelectedPaymentId(payment.id);
    setIsEditPaymentDialogOpen(true);
  };

  // Open edit receipt dialog
  const openEditReceiptDialog = (receipt) => {
    setSelectedReceiptId(receipt.id);
    setIsEditReceiptDialogOpen(true);
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN').format(Math.abs(amount));
  };

  // Table columns definition
  const columns = [
    {
      key: "date",
      header: t("transaction.transaction_date", "Thời gian lập"),
      width: "160px",
      cellRenderer: (row) => (
        <div className="text-[#020617]">
          {formatDateTime(row.created_at)}
        </div>
      ),
      skeletonRenderer: () => <Skeleton className="h-5 w-[120px]" />,
    },
    {
      key: "code",
      header: t("transaction.transaction_code", "Mã phiếu"),
      width: "120px",
      cellRenderer: (row) => (
        <div className="text-[#020617]">{row.code}</div>
      ),
      skeletonRenderer: () => <Skeleton className="h-5 w-[80px]" />,
    },
    {
      key: "type",
      header: t("transaction.transaction_type", "Loại phiếu"),
      width: "120px",
      cellRenderer: (row) => (
        <div className="text-[#020617]">
          {row.type === FinancialLogType.RECEIPT
            ? t("transaction.transaction_type_receipt", "Phiếu thu") 
            : t("transaction.transaction_type_payment", "Phiếu chi")}
        </div>
      ),
      skeletonRenderer: () => <Skeleton className="h-5 w-[80px]" />,
    },
    {
      key: "reason",
      header: t("transaction.transaction_reason", "Lý do"),
      width: "auto", // Add a specific width to control the column size
      cellRenderer: (row) => (
        <div className="text-[#020617] truncate overflow-hidden whitespace-nowrap w-full" title={row.reason}>
          {row.note}
        </div>
      ),
      skeletonRenderer: () => <Skeleton className="h-5 w-full" />,
    },
    {
      key: "amount",
      header: t("transaction.transaction_amount", "Giá trị"),
      width: "150px",
      cellRenderer: (row) => (
        <div className={row.type === FinancialLogType.RECEIPT ? "text-[#008A2E] font-medium" : "text-[#DC2626] font-medium"}>
          {row.type === FinancialLogType.RECEIPT ? `+${formatCurrency(row.amount)}` : `-${formatCurrency(row.amount)}`}
        </div>
      ),
      skeletonRenderer: () => <Skeleton className="h-5 w-[100px]" />,
    },
    {
      key: "status",
      header: t("transaction.transaction_status", "Trạng thái"),
      width: "140px",
      align: "center",
      cellRenderer: (row) => {
        const badge = getFinancialLogStatusBadge(row.status, t);
        return (
          <Badge variant={badge.variant} className={badge.className}>
            {badge.label}
          </Badge>
        );
      },
      skeletonRenderer: SkeletonRenderers.badge,
    },
    {
      key: "actions",
      width: "auto",
      cellRenderer: (row) => (
        <div className="flex items-center justify-end gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:text-[#E67364]"
            onClick={() => row.type === FinancialLogType.PAYMENT
              ? openEditPaymentDialog(row) 
              : openEditReceiptDialog(row)
            }
          >
            <SquarePen className="h-4 w-4" />
          </Button>
        </div>
      ),
      skeletonRenderer: () => <Skeleton className="h-5 w-[100px] mx-auto" />,
    },
  ];

  // Custom search component with filter button
  const SearchWithFilter = (
    <div className="flex flex-col gap-1">
    <div className="flex items-center gap-3">
      <div className="relative w-[384px]">
        <div className="flex items-center border border-[#E2E8F0] rounded-lg focus-within:ring-1 focus-within:ring-brand focus-within:border-brand bg-white h-9">
          <Search className="w-4 h-4 ml-3 text-[#94A3B8]" />
          <Input
            type="text"
            placeholder={t("transaction.search_by_code", "Tìm theo mã phiếu")}
            className="border-0 w-full h-9 px-3 py-2 text-[13px] focus-visible:ring-0 placeholder:text-[#94A3B8] bg-transparent"
            value={keyword}
            onChange={(e) => handleSearch(e.target.value)}
          />
        </div>
      </div>
      
      <Button
        variant="outline"
        className="flex items-center gap-2 border-[#E5E5E5] h-9 whitespace-nowrap"
      >
        <Filter className="h-4 w-4 text-[#09090B]" />
        <span className="text-[#18181B] font-medium">
          {t("transaction.filter_transactions", "Lọc giao dịch")}
        </span>
      </Button>
      </div>
      {keyword && keyword.length > 0 && keyword.length < 3 && (
        <span className="text-xs text-[#F04438] ml-1 mt-1">
          {t("transaction.search_min_3_chars", "Vui lòng nhập ít nhất 3 ký tự để tìm kiếm")}
        </span>
      )}
    </div>
  );

  // Additional actions for the master list layout
  const additionalActions = (
    <>
      <Button
        variant="default"
        className="bg-[#E67364] hover:bg-[#d66559]"
        onClick={() => setIsPaymentDialogOpen(true)}
      >
        <Plus className="mr-2 h-4 w-4" />
        {t("transaction.create_payment", "Lập phiếu chi")}
      </Button>
    </>
  );

  return (
    <>
      <MasterListLayout
        title={t("transaction.transaction_list", "Danh sách giao dịch")}
        searchPlaceholder={t("transaction.search_by_code", "Tìm theo mã phiếu")}
        searchValue={keyword}
        onSearchChange={handleSearch}
        columns={columns}
        data={transactions}
        loading={loading}
        error={error}
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
        totalItems={totalItems}
        itemsLabel={t("transaction.transactions", "giao dịch")}
        emptyTitle={t("transaction.no_transactions", "Không có giao dịch nào")}
        emptySubtitle={t("transaction.no_transactions_subtitle", "Chưa có giao dịch nào được tạo.")}
        showAddButton={false}
        additionalActions={additionalActions}
        searchWithFilter={SearchWithFilter}
      >
      </MasterListLayout>

      {/* Create Payment Dialog */}
      <CreatePaymentDialog
        open={isPaymentDialogOpen}
        onOpenChange={setIsPaymentDialogOpen}
        onSuccess={handleCreatePayment}
      />

      {/* Create Receipt Dialog */}
      <CreateReceiptDialog
        open={isReceiptDialogOpen}
        onOpenChange={setIsReceiptDialogOpen}
        onSuccess={handleCreateReceipt}
      />

      {/* Edit Payment Dialog */}
      <EditPaymentDialog
        open={isEditPaymentDialogOpen}
        onOpenChange={setIsEditPaymentDialogOpen}
        onSuccess={handleEditPayment}
        paymentId={selectedPaymentId}
      />

      {/* Edit Receipt Dialog */}
      <EditReceiptDialog
        open={isEditReceiptDialogOpen}
        onOpenChange={setIsEditReceiptDialogOpen}
        onSuccess={handleEditReceipt}
        receiptId={selectedReceiptId}
      />
    </>
  );
};

export default TransactionList; 