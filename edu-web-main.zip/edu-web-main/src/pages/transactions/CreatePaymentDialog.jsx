import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { PlusIcon } from "lucide-react";

import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
    DialogClose,
    DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import staffApi from "@/api/services/staff";
import { createFinancialLog, FinancialLogType, RecipientGroup, PaymentType } from "@/api/services/financial_logs";
import { getPaymentTypeOptions, getPaymentMethodOptions } from "@/api/services/financial_logs";

// Validate form data before submission
const validatePaymentData = (data, t) => {
    const errors = {};
    if (!data.type) {
    errors.type = t("validation.required_payment_type", "Please select payment type");
    }
    if (!data.amount) {
    errors.amount = t("validation.required_payment_amount", "Please enter payment amount");
    }
  if (!data.method) {
    errors.method = t("validation.required_payment_method", "Please select payment method");
  }
  if (!data.receiverGroup) {
    errors.receiverGroup = t("validation.required_payment_receiver_group", "Please select receiver group");
  }
  if (!data.receiver) {
    errors.receiver = t("validation.required_payment_receiver", "Please select receiver");
    }

    return {
        isValid: Object.keys(errors).length === 0,
        errors
    };
};

export function CreatePaymentDialog({ open, onOpenChange, onSuccess }) {
    const { t } = useTranslation();
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});

    // Form state
    const [formData, setFormData] = useState({
    code: "PC00001",
    createdBy: "Trương Minh Tuấn",
        type: "",
        amount: "",
    method: "",
    receiverGroup: RecipientGroup.STAFF,
    receiver: "",
        note: ""
    });

  const [staffOptions, setStaffOptions] = useState([]);
  const [staffLoading, setStaffLoading] = useState(false);
  const [staffSearch, setStaffSearch] = useState("");

    // Reset form when dialog opens
    useEffect(() => {
        if (open) {
            setFormData({
        code: "PC00001", // In a real app, this would be generated/fetched
        createdBy: "Trương Minh Tuấn", // In a real app, this would be the current user
                type: "",
                amount: "",
        method: "",
        receiverGroup: RecipientGroup.STAFF,
        receiver: "",
                note: ""
            });
            setErrors({});
        }
    }, [open]);

  // Thay thế các mảng hardcode bằng hàm tiện ích
  const paymentTypes = getPaymentTypeOptions(t);
  const paymentMethods = getPaymentMethodOptions(t);

  // Fetch staff when receiverGroup is STAFF or staffSearch changes
  useEffect(() => {
    if (formData.receiverGroup === RecipientGroup.STAFF) {
      setStaffLoading(true);
      staffApi.getStaff({ keyword: staffSearch, page: 1, pagesize: 10 }).then(res => {
        if (res.success) {
          setStaffOptions(res.items);
        } else {
          setStaffOptions([]);
        }
        setStaffLoading(false);
      });
    }
  }, [formData.receiverGroup, staffSearch]);

  // Reset receiver when receiver group changes
  useEffect(() => {
    if (formData.receiverGroup && formData.receiver) {
      // No longer need to check if receiver exists in mock data, as staffOptions will be populated
    }
  }, [formData.receiverGroup, formData.receiver]);

    // Handle form field changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: null }));
        }
    };

  // Handle amount input change - let InputWithPostfix handle formatting
    const handleAmountChange = (e) => {
    const { value } = e.target;
    setFormData(prev => ({ ...prev, amount: value }));
        if (errors.amount) {
            setErrors(prev => ({ ...prev, amount: null }));
        }
    };

    // Handle select changes
  const handleSelectChange = (name, value, extra) => {
    setFormData(prev => ({ ...prev, [name]: value, ...(extra || {}) }));
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: null }));
        }
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({});

        // Validate form
    const validation = validatePaymentData(formData, t);
        if (!validation.isValid) {
            setErrors(validation.errors);
            return;
        }

        setLoading(true);
        try {
      // Prepare payment data
      const paymentData = {
        payment_type: formData.type,
        amount: formData.amount.replace(/,/g, ""),
        payment_method: formData.method,
        recipient_group: formData.receiverGroup,
        user_id: formData.receiver, // sẽ sửa thành user_id bên dưới
        note: formData.note,
        type: FinancialLogType.PAYMENT,
      };
      // Không truyền recipient_name
      const response = await createFinancialLog(paymentData);
      if (response.success) {
        showSuccessToast(t("success.payment_created_success", "Tạo phiếu chi thành công"));
            onOpenChange(false);
            if (onSuccess) {
          onSuccess(response.data);
        }
      } else {
        showErrorToast(
          t("error.payment_creation_error", "Lỗi khi tạo phiếu chi"),
          response.error
        );
            }
        } catch (error) {
      console.error("Error creating payment:", error);
            showErrorToast(
        t("error.payment_creation_error", "Lỗi khi tạo phiếu chi"),
                error.message
            );
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent
        className="sm:max-w-[600px] p-6"
                style={{
                    boxShadow: "0px 4px 6px -4px rgba(0, 0, 0, 0.1), 0px 10px 15px -3px rgba(0, 0, 0, 0.1)"
                }}
            >
                <DialogHeader className="space-y-1">
                    <DialogTitle className="text-lg font-semibold text-[#020617]">
            {t("transaction.create_new_payment", "Create new payment")}
                    </DialogTitle>
                    <DialogDescription className="text-[#64748B] text-sm">
            {t("transaction.create_new_payment_description", "Enter details to create a new payment")}
                    </DialogDescription>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4">
          {/* Payment Code and Created By */}
          <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <Label className="text-sm font-medium text-[#64748B]">
                {t("transaction.payment_code", "Payment code")}
                        </Label>
                        <div className="text-sm text-[#09090B]">{formData.code}</div>
                    </div>

                    <div className="space-y-1">
              <Label className="text-sm font-medium text-[#64748B]">
                {t("transaction.created_by", "Created by")}
                        </Label>
              <div className="text-sm text-[#09090B]">{formData.createdBy}</div>
            </div>
                    </div>

          {/* Payment Type */}
                    <div className="flex items-end space-x-2">
                        <div className="flex-1 space-y-1">
                            <Label htmlFor="type" className="text-sm font-medium text-[#344054] flex items-center">
                {t("transaction.payment_type", "Payment type")}
                                <span className="text-[#DC2626] ml-1">*</span>
                            </Label>
                            <Select
                value={formData.type || ""}
                                onValueChange={(value) => handleSelectChange("type", value)}
                            >
                                <SelectTrigger className={`w-full ${errors.type ? "border-[#FDA29B]" : ""}`}>
                  <SelectValue placeholder={t("transaction.select_payment_type", "Select payment type")} />
                                </SelectTrigger>
                                <SelectContent>
                  {paymentTypes.map((type) => (
                                        <SelectItem key={type.id} value={type.id}>
                                            {type.name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            {errors.type && (
                <span className="text-sm text-[#F04438]">{errors.type}</span>
                            )}
                        </div>
                        <Button
                            type="button"
                            size="icon"
                            className="h-9 w-9 bg-[#F5F5F5] border-0 rounded-md hover:bg-gray-100"
                        >
                            <PlusIcon className="h-4 w-4 text-[#09090B] stroke-2" />
                        </Button>
                    </div>

          {/* Receiver Group and Receiver */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="receiverGroup" className="text-sm font-medium text-[#344054] flex items-center">
                {t("transaction.receiver_group", "Receiver group")}
                <span className="text-[#DC2626] ml-1">*</span>
              </Label>
              <Select
                value={formData.receiverGroup || ""}
                onValueChange={(value) => handleSelectChange("receiverGroup", value)}
              >
                <SelectTrigger className={`w-full ${errors.receiverGroup ? "border-[#FDA29B]" : ""}`}>
                  <SelectValue placeholder={t("transaction.select_receiver_group", "Select receiver group")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem key={RecipientGroup.STAFF} value={RecipientGroup.STAFF}>{t("transaction.receiver_group_staff", "Staff")}</SelectItem>
                  {/* <SelectItem key={RecipientGroup.SUPPLIER} value={RecipientGroup.SUPPLIER}>{t("transaction.receiver_group_vendor", "Vendor")}</SelectItem>
                  <SelectItem key={RecipientGroup.OTHER} value={RecipientGroup.OTHER}>{t("transaction.receiver_group_other", "Other")}</SelectItem> */}
                </SelectContent>
              </Select>
              {errors.receiverGroup && (
                <span className="text-sm text-[#F04438]">{errors.receiverGroup}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="receiver" className="text-sm font-medium text-[#344054] flex items-center">
                {t("transaction.receiver", "Receiver")}
                <span className="text-[#DC2626] ml-1">*</span>
              </Label>
              {formData.receiverGroup === RecipientGroup.STAFF ? (
                <Select
                  value={formData.receiver || ""}
                  onValueChange={(value) => {
                    const staff = staffOptions.find(s => String(s.user_id) === value);
                    handleSelectChange("receiver", value, staff ? { receiver_name: staff.full_name } : {});
                  }}
                >
                  <SelectTrigger className={`w-full ${errors.receiver ? "border-[#FDA29B]" : ""} ${!formData.receiverGroup ? "bg-[#FAFAFA] text-[#A1A1AA]" : "bg-white"}`}>
                    <SelectValue>
                      {formData.receiver
                        ? (staffOptions.find(s => String(s.user_id) === formData.receiver)?.full_name
                            || formData.receiver_name
                            || t("transaction.select_receiver", "Select receiver"))
                        : t("transaction.select_receiver", "Select receiver")}
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <div className="px-2 py-1">
                      <Input
                        placeholder={t("transaction.search_staff", "Tìm kiếm nhân viên")}
                        value={staffSearch}
                        onChange={e => setStaffSearch(e.target.value)}
                        className="mb-2"
                      />
                    </div>
                    {staffLoading ? (
                      <div className="px-4 py-2 text-sm text-gray-400">{t("loading", "Loading...")}</div>
                    ) : staffOptions.length === 0 ? (
                      <div className="px-4 py-2 text-sm text-gray-400">{t("no_data", "No data")}</div>
                    ) : (
                      staffOptions.map(staff => (
                        <SelectItem key={staff.user_id} value={String(staff.user_id)}>
                          {staff.full_name} {staff.phone_number ? `(${staff.phone_number})` : ""}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  id="receiver"
                  name="receiver"
                  value={formData.receiver}
                  onChange={handleChange}
                  placeholder={t("transaction.enter_receiver", "Enter receiver")}
                  className={`${errors.receiver ? "border-[#FDA29B]" : ""}`}
                />
              )}
              {errors.receiver && (
                <span className="text-sm text-[#F04438]">{errors.receiver}</span>
              )}
            </div>
          </div>
          
          {/* Payment Amount and Method */}
          <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <Label htmlFor="amount" className="text-sm font-medium text-[#344054] flex items-center">
                {t("transaction.payment_amount", "Payment amount")}
                            <span className="text-[#DC2626] ml-1">*</span>
                        </Label>
                        <InputWithPostfix
                            id="amount"
                            name="amount"
                value={formData.amount}
                            onChange={handleAmountChange}
                            postfix="đ"
                            className={`${errors.amount ? "border-[#FDA29B]" : ""}`}
                        />
                        {errors.amount && (
                <span className="text-sm text-[#F04438]">{errors.amount}</span>
                        )}
                    </div>

                    <div className="space-y-1">
              <Label htmlFor="method" className="text-sm font-medium text-[#344054] flex items-center">
                {t("transaction.payment_method", "Payment method")}
                            <span className="text-[#DC2626] ml-1">*</span>
                        </Label>
                        <Select
                value={formData.method || ""}
                onValueChange={(value) => handleSelectChange("method", value)}
                        >
                <SelectTrigger className={`w-full ${errors.method ? "border-[#FDA29B]" : ""}`}>
                  <SelectValue placeholder={t("transaction.select_payment_method", "Select payment method")} />
                            </SelectTrigger>
                            <SelectContent>
                  {paymentMethods.map((method) => (
                    <SelectItem key={method.id} value={method.id}>
                      {method.name}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
              {errors.method && (
                <span className="text-sm text-[#F04438]">{errors.method}</span>
                        )}
            </div>
                    </div>

                    {/* Note */}
                    <div className="space-y-1">
                        <Label htmlFor="note" className="text-sm font-medium text-[#344054]">
              {t("common.note", "Note")}
                        </Label>
                        <Input
                            id="note"
                            name="note"
                            value={formData.note}
                            onChange={handleChange}
              placeholder={t("common.enter_note", "Enter note")}
                        />
                    </div>

                    <DialogFooter className="pt-4 flex justify-end gap-2">
                        <DialogClose asChild>
                            <Button
                                type="button"
                                variant="outline"
                                className="h-10 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB] rounded-md font-semibold"
                            >
                                {t("common.cancel", "Cancel")}
                            </Button>
                        </DialogClose>
                        <Button
                            type="submit"
                            disabled={loading}
                            className={`h-10 px-4 py-2 bg-[#E67364] hover:bg-[#d66559] text-white font-semibold rounded-md ${
                                loading ? 'opacity-50 cursor-not-allowed' : ''
                            }`}
                        >
                            {loading ? t("common.creating", "Creating...") : t("common.create", "Create")}
                        </Button>
                    </DialogFooter>
                </form>

            </DialogContent>
        </Dialog>
    );
} 