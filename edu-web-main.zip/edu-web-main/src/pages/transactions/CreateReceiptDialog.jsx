import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { format } from "date-fns";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import { Textarea } from "@/components/ui/textarea";
import { PrefilledInput } from "@/components/ui/prefilled-input";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { createFinancialLog, FinancialLogType, PaymentMethod } from "@/api/services/financial_logs";
import { useAuth } from "@/contexts/auth.hooks";

export function CreateReceiptDialog({ open, onOpenChange, onSuccess, order, isEdit = false }) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  
  // Form state
  const [formData, setFormData] = useState({
    code: t("common.auto_generated", "Tự động tạo bởi hệ thống"),
    date: format(new Date(), "yyyy-MM-dd"),
    time: format(new Date(), "HH:mm:ss"),
    creator: user?.full_name || "Admin",
    amount: order?.finalAmount ?? order?.final_amount ?? "",
    payment_method: "",
    note: ""
  });

  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      const now = new Date();
      
      setFormData({
        code: t("common.auto_generated", "Tự động tạo bởi hệ thống"), // Prefilled text
        date: format(now, "yyyy-MM-dd"),
        time: format(now, "HH:mm:ss"),
        creator: user?.full_name || "Admin",
        amount: order?.finalAmount ?? order?.final_amount ?? "",
        payment_method: "",
        note: ""
      });
      setErrors({});
    }
  }, [open, user?.full_name, order?.finalAmount, order?.final_amount, t]);

  // Clean mapping for payment methods (enum value -> i18n key)
  const paymentMethodOptions = [
    { value: PaymentMethod.CASH, i18nKey: "transaction.payment_method_cash", defaultLabel: "Tiền mặt" },
    { value: PaymentMethod.BANK_TRANSFER, i18nKey: "transaction.payment_method_bank_transfer", defaultLabel: "Chuyển khoản" },
  ];
  const paymentMethods = paymentMethodOptions.map(opt => ({
    id: opt.value,
    name: t(opt.i18nKey, opt.defaultLabel)
  }));

  // Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };

  // Handle amount input change
  const handleAmountChange = (e) => {
    const raw = e.target.value;
    setFormData(prev => ({ ...prev, amount: raw }));
    if (errors.amount) {
      setErrors(prev => ({ ...prev, amount: null }));
    }
  };

  // Handle select changes
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };

  // Date and Time are disabled, so no change handlers needed

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors({});
    
    // Validate form
    const errors = {};
    if (!formData.amount) {
      errors.amount = t("validation.required_receipt_amount", "Vui lòng nhập giá trị phiếu thu");
    }
    if (!formData.payment_method) {
      errors.payment_method = t("validation.required_receipt_payment_method", "Vui lòng chọn phương thức thanh toán");
    }
    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
    
    setLoading(true);
    try {
      // Prepare receipt data
      const receiptData = {
        type: FinancialLogType.RECEIPT,
        amount: formData.amount,
        payment_method: formData.payment_method, // now always enum value
        note: formData.note,
        ...(order?.id && { order_id: order.id })
      };
      const response = await createFinancialLog(receiptData);
      if (response.success) {
        showSuccessToast(t("success.receipt_created_success", "Lập phiếu thu thành công"));
        onOpenChange(false);
        if (onSuccess) {
          onSuccess(response.data);
        }
      } else {
        showErrorToast(
          t("error.receipt_creation_error", "Lỗi khi lập phiếu thu"),
          response.error || t("error.receipt_creation_error", "Lỗi khi lập phiếu thu")
        );
      }
    } catch (error) {
      showErrorToast(
        t("error.receipt_creation_error", "Lỗi khi lập phiếu thu"),
        error
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="sm:max-w-[500px] p-6"
        style={{ 
          boxShadow: "0px 4px 6px -4px rgba(0, 0, 0, 0.1), 0px 10px 15px -3px rgba(0, 0, 0, 0.1)"
        }}
      >
        <DialogHeader className="space-y-1">
          <DialogTitle className="text-lg font-semibold text-[#020617]">
            {t("transaction.create_new_receipt", "Lập phiếu thu mới")}
          </DialogTitle>
          <DialogDescription className="text-[#64748B] text-sm">
            {t("transaction.create_new_receipt_description", "Nhập thông tin chi tiết để lập phiếu thu mới")}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Receipt Code */}
          <div className="space-y-1">
            <Label className="text-sm font-medium text-[#020617]">
              {t("transaction.receipt_code", "Mã phiếu thu")}
            </Label>
            <PrefilledInput
              value={formData.code}
            />
          </div>
          
          {/* Date and Time Row */}
          {isEdit && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label className="text-sm font-medium text-[#020617]">
                  {t("transaction.payment_date", "Ngày lập")}
                </Label>
                <PrefilledInput
                  value={format(new Date(formData.date), "dd/MM/yyyy")}
                />
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-medium text-[#020617]">
                  {t("transaction.payment_time", "Giờ")}
                </Label>
                <PrefilledInput
                  value={formData.time}
                />
              </div>
            </div>
          )}
          {/* Creator */}
          {isEdit && (
            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#020617]">
                {t("transaction.creator", "Người lập phiếu")}
              </Label>
              <PrefilledInput
                value={formData.creator}
              />
            </div>
          )}
          
          {/* Amount and Payment Method Row */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#020617] flex items-center">
                {t("transaction.receipt_value", "Giá trị phiếu thu")}
                <span className="text-[#DC2626] ml-1">*</span>
              </Label>
              <InputWithPostfix
                name="amount"
                value={formData.amount || ""}
                onChange={handleAmountChange}
                postfix="đ"
                className={`${errors.amount ? "border-[#FDA29B]" : ""}`}
                placeholder="200,000"
              />
              {errors.amount && (
                <span className="text-sm text-[#F04438]">{errors.amount}</span>
              )}
            </div>
            
            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#020617] flex items-center">
                {t("transaction.payment_method", "Phương thức thanh toán")}
                <span className="text-[#DC2626] ml-1">*</span>
              </Label>
              <Select
                value={formData.payment_method}
                onValueChange={(value) => handleSelectChange("payment_method", value)}
              >
                <SelectTrigger className={`w-full ${errors.payment_method ? "border-[#FDA29B]" : ""}`}>
                  <SelectValue placeholder={t("transaction.select_payment_method", "Chọn phương thức")} />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map((method) => (
                    <SelectItem key={method.id} value={method.id}>
                      {method.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.payment_method && (
                <span className="text-sm text-[#F04438]">{errors.payment_method}</span>
              )}
            </div>
          </div>
          
          {/* Note */}
          <div className="space-y-1">
            <Label className="text-sm font-medium text-[#020617]">
              {t("common.note", "Ghi chú")}
            </Label>
            <Textarea
              name="note"
              value={formData.note}
              onChange={handleChange}
              placeholder={t("common.enter_note", "Nhập ghi chú")}
              className="min-h-[80px] resize-none"
            />
          </div>
          
          <DialogFooter className="pt-4 flex justify-end gap-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              className="h-10 px-4 py-2 border-[#E4E4E7] text-[#09090B] hover:text-[#09090B] hover:bg-[#F9FAFB] rounded-md font-semibold"
            >
              {t("common.cancel", "Hủy bỏ")}
            </Button>
            <Button 
              type="submit" 
              disabled={loading}
              className={`h-10 px-4 py-2 bg-[#E67364] hover:bg-[#d66559] text-white font-semibold rounded-md ${
                loading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {loading ? t("common.creating", "Đang tạo...") : t("common.create", "Thêm mới")}
            </Button>
          </DialogFooter>
        </form>
        
      </DialogContent>
    </Dialog>
  );
} 