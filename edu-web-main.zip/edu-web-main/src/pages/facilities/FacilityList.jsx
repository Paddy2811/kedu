import { useEffect, useState, useCallback } from "react";
import { Button } from "../../components/ui/button";
import { Plus } from "lucide-react";
import { FacilityDialog } from "./FacilityDialog";
import { facilityApi } from "../../api/services/facility";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { useTranslation } from "react-i18next";
import { provinces } from "../../data/vietnam-provinces";
import { MasterListLayout } from '@/components/layout/master-list-layout';

// Utility functions for location data
const getProvinceName = (code) => {
  const province = provinces.find(p => p.code === code);
  return province ? province.name : code;
};

const getDistrictName = (provinceCode, districtCode) => {
  const province = provinces.find(p => p.code === provinceCode);
  if (!province) return districtCode;
  const district = province.districts.find(d => d.code === districtCode);
  return district ? district.name : districtCode;
};

export default function FacilityList() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(0);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedFacilityId, setSelectedFacilityId] = useState(null);
  const [error, setError] = useState(null);

  const { t } = useTranslation();
  useBreadcrumb(t('facility.facility_list'), '/facilities');

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await facilityApi.getAll({
        page: currentPage,
        pagesize: pageSize,
        keyword: search,
      });
      
      if (result.success && result.items) {
        setData(result.items);
        setTotal(result.total || 0);
        setTotalPages(Math.ceil((result.total || 0) / pageSize));
      } else {
        setError(result.error || t('errors.load_facility_list'));
        setData([]);
        setTotal(0);
        setTotalPages(0);
      }
    } catch {
      setError(t('errors.load_facility_list'));
      setData([]);
      setTotal(0);
      setTotalPages(0);
    } finally {
      setLoading(false);
    }
  }, [currentPage, pageSize, search, t]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (search.length === 0 || search.length > 3) {
        fetchData();
      }
    }, 400);
    return () => clearTimeout(timeout);
  }, [fetchData, search.length]);

  // Handle edit facility
  const handleEditFacility = useCallback((id) => {
    setSelectedFacilityId(id);
    setEditDialogOpen(true);
  }, []);

  // Handle page change
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  // Define columns for DataTable
  const columns = [
    {
      key: 'name',
      header: t('facility.facility'),
      width: '200px',
      cellRenderer: (facility) => (
        <div className="flex flex-col">
          <div className="text-sm font-medium text-[#020617]">{facility.name || "Cơ sở Thái Hà"}</div>
          <div className="text-xs font-medium text-[#64748B]">{facility.code || "CS00001"}</div>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex flex-col gap-1">
          <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-3 w-16 bg-gray-200 rounded animate-pulse"></div>
        </div>
      )
    },
    {
      key: 'address',
      header: t('personal.address'),
      cellRenderer: (facility) => (
        <div className="text-sm text-[#020617]">{facility.address || "Tầng 9, Toà nhà Hoa Cương, Số 18 ngõ 11 Thái Hà"}</div>
      ),
      skeletonWidth: 'w-[200px]'
    },
    {
      key: 'district',
      header: t('facility.district'),
      width: '200px',
      cellRenderer: (facility) => (
        <div className="text-sm text-[#020617]">{getDistrictName(facility.city, facility.district) || "Quận/Huyện"}</div>
      ),
      skeletonWidth: 'w-[150px]'
    },
    {
      key: 'city',
      header: t('facility.province'),
      width: '200px',
      cellRenderer: (facility) => (
        <div className="text-sm text-[#020617]">{getProvinceName(facility.city) || "Tỉnh/Thành phố"}</div>
      ),
      skeletonWidth: 'w-[150px]'
    },
    {
      key: 'actions',
      header: '',
      width: '110px',
      align: 'right',
      cellRenderer: (facility) => (
        <Button
          variant="link"
          className="text-brand hover:text-brand/90 p-0 h-auto font-medium"
          onClick={() => handleEditFacility(facility.id)}
        >
          {t('common.edit')}
        </Button>
      ),
      skeletonWidth: 'w-[60px]'
    }
  ];

  return (
    <>
      <MasterListLayout
        title={t('facility.facility_list')}
        searchPlaceholder={t('facility.search_facility_placeholder')}
        searchValue={search}
        onSearchChange={(value) => {
          setSearch(value);
          if (currentPage !== 1) setCurrentPage(1);
        }}
        columns={columns}
        data={data}
        loading={loading}
        error={error}
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
        totalItems={total}
        itemsLabel={t('facility.total_facilities')}
        emptyTitle={t('no_facilities', 'Chưa có cơ sở nào')}
        emptySubtitle={t('no_facilities_subtitle', 'Khi có cơ sở, chúng sẽ xuất hiện tại đây.')}
        emptyButtonText={t('common.addNew', 'Thêm mới')}
        onEmptyAction={() => setCreateDialogOpen(true)}
        emptyButtonIcon={<Plus className="w-4 h-4" />}
        showAddButton={true}
        addButtonText={t('common.addNew')}
        onAddClick={() => setCreateDialogOpen(true)}
      />
      
      <FacilityDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onSuccess={() => {
          setCreateDialogOpen(false);
          setTimeout(() => fetchData(), 0);
        }}
        mode="create"
      />

      <FacilityDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        facilityId={selectedFacilityId}
        mode="edit"
        onSuccess={() => {
          setEditDialogOpen(false);
          setSelectedFacilityId(null);
          setTimeout(() => fetchData(), 0);
        }}
      />
    </>
  );
}
