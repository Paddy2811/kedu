import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogClose,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Combobox } from "@/components/ui/combobox";
import { PrefilledInput } from "@/components/ui/prefilled-input";
import { provinces, getDistricts, getWards } from "@/data/vietnam-provinces";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { useTranslation } from "react-i18next";
import { facilityApi } from "@/api/services/facility";

const generateNextFacilityCode = () => {
  try {
    const lastCode = localStorage.getItem('lastFacilityCode');
    if (lastCode && new RegExp(`^CC\\d{3}$`).test(lastCode)) {
      const nextNumber = parseInt(lastCode.slice(2), 10) + 1;
      return `CC${nextNumber.toString().padStart(3, '0')}`;
    }
  } catch (error) {
    console.error('Error reading last facility code from localStorage', error);
  }
  return 'CC001';
};
const saveNewFacilityCode = (code) => {
  try {
    const used = JSON.parse(localStorage.getItem('usedFacilityCodes') || '[]');
    if (!used.includes(code)) {
      used.push(code);
      localStorage.setItem('usedFacilityCodes', JSON.stringify(used));
    }
    localStorage.setItem('lastFacilityCode', code);
  } catch (error) {
    console.error('Error saving facility code to localStorage', error);
  }
};
const validateFacilityData = (data, t) => {
  const errors = {};
      if (!data.name || data.name.trim() === '') {
      errors.name = t('validation.required_facility_name');
    }
    if (!data.address || data.address.trim() === '') {
      errors.address = t('validation.required_facility_address');
    }
    if (!data.province || data.province.trim() === '') {
      errors.province = t('validation.required_facility_province');
    }
    if (!data.district || data.district.trim() === '') {
      errors.district = t('validation.required_facility_district');
    }
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export function FacilityDialog({ open, onOpenChange, onSuccess, mode = 'create', facility, facilityId }) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    address: "",
    province: "",
    district: "",
    ward: "",
  });
  const [districts, setDistricts] = useState([]);
  const [wards, setWards] = useState([]);

  // Using Combobox, no explicit search state required

  // const [provinceSearch, setProvinceSearch] = useState("");
  // const [districtSearch, setDistrictSearch] = useState("");
  // const [wardSearch, setWardSearch] = useState("");

  // const provinceSearchRef = useRef(null);
  // const districtSearchRef = useRef(null);
  // const wardSearchRef = useRef(null);

  // Fetch facility data for edit mode if facilityId provided
  useEffect(() => {
    if (open && mode === 'edit' && facilityId) {
      setFetchLoading(true);
      facilityApi.getById(facilityId).then(result => {
        if (result.success && result.data) {
          const facilityData = result.data;
          // Map name to code for province, district, ward
          const provinceObj = provinces.find(p => p.code === facilityData.city || p.name === facilityData.city || p.name === facilityData.province);
          let provinceCode = provinceObj ? provinceObj.code : "";
          let districtsList = provinceCode ? getDistricts(provinceCode) : [];
          let districtCode = "";
          if (provinceCode) {
            const districtObj = districtsList.find(d => d.code === facilityData.district || d.name === facilityData.district);
            districtCode = districtObj ? districtObj.code : "";
          }
          let wardsList = (provinceCode && districtCode) ? getWards(provinceCode, districtCode) : [];
          let wardCode = "";
          if (provinceCode && districtCode) {
            const wardObj = wardsList.find(w => w.code === facilityData.ward || w.name === facilityData.ward);
            wardCode = wardObj ? wardObj.code : "";
          }
          setFormData({
            name: facilityData.name || "",
            code: facilityData.code || "",
            address: facilityData.address || "",
            province: provinceCode,
            district: districtCode,
            ward: wardCode,
          });
          setDistricts(districtsList);
          setWards(wardsList);
        } else {
          showErrorToast(result.error || t('errors.load_facility_list'));
          onOpenChange(false);
        }
      }).catch((err) => {
        console.error(err);
        showErrorToast(t('errors.load_facility_list'));
        onOpenChange(false);
      }).finally(() => setFetchLoading(false));
    } else if (open && mode === 'edit' && facility) {
      // Map district/ward name to code if needed
      let districtCode = facility.district || "";
      let wardCode = facility.ward || "";
      const provinceObj = provinces.find(p => p.code === facility.city || p.name === facility.city);
      if (provinceObj) {
        const districtObj = provinceObj.districts.find(d => d.code === facility.district || d.name === facility.district);
        if (districtObj) {
          districtCode = districtObj.code;
          const wardObj = districtObj.wards.find(w => w.code === facility.ward || w.name === facility.ward);
          if (wardObj) {
            wardCode = wardObj.code;
          }
        }
      }
      setFormData({
        name: facility.name || "",
        code: facility.code || "",
        address: facility.address || "",
        province: facility.city || "",
        district: districtCode,
        ward: wardCode
      });
      setDistricts(facility.city ? getDistricts(facility.city) : []);
      setWards(facility.city && districtCode ? getWards(facility.city, districtCode) : []);
    } else if (open && mode === 'create') {
      // Lấy code từ API
      (async () => {
        setFetchLoading(true);
        try {
          const res = await facilityApi.getInitInfo();
          setFormData({
            name: "",
            code: res.success && res.data?.code ? res.data.code : generateNextFacilityCode(),
            address: "",
            province: "",
            district: "",
            ward: ""
          });
        } catch {
          setFormData({
            name: "",
            code: generateNextFacilityCode(),
            address: "",
            province: "",
            district: "",
            ward: ""
          });
        } finally {
          setFetchLoading(false);
        }
      })();
      setDistricts([]);
      setWards([]);
    }
    setErrors({});
  }, [open, mode, facility, facilityId, onOpenChange, t]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
    if (name === 'province') {
      setFormData(prev => ({ ...prev, district: '', ward: '' }));
      setDistricts(getDistricts(value));
      setWards([]);
    }
    if (name === 'district') {
      setFormData(prev => ({ ...prev, ward: '' }));
      setWards(getWards(formData.province, value));
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});
    const validation = validateFacilityData(formData, t);
    if (!validation.isValid) {
      setErrors(validation.errors);
      showErrorToast(t('validation.required_fields'));
      setLoading(false);
      return;
    }
    // Always map province, district, ward to code before submit
    let provinceCode = formData.province;
    let districtCode = formData.district;
    let wardCode = formData.ward;
    const provinceObj = provinces.find(p => p.code === provinceCode || p.name === provinceCode);
    if (provinceObj) {
      provinceCode = provinceObj.code;
      const districtObj = provinceObj.districts.find(d => d.code === districtCode || d.name === districtCode);
      if (districtObj) {
        districtCode = districtObj.code;
        const wardObj = districtObj.wards.find(w => w.code === wardCode || w.name === wardCode);
        if (wardObj) {
          wardCode = wardObj.code;
        }
      }
    }
    const facilityData = {
      name: formData.name.trim(),
      code: formData.code.trim(),
      address: formData.address.trim(),
      city: provinceCode,
      district: districtCode,
      ward: wardCode,
    };
    let result;
    try {
      if (mode === 'edit' && (facilityId || facility?.id)) {
        result = await facilityApi.updateFacility(facilityId || facility.id, facilityData);
      } else {
        result = await facilityApi.createFacility(facilityData);
      }
      if (result.success) {
        if (mode === 'edit') {
          showSuccessToast(t('success.updateFacility'));
        } else {
          showSuccessToast(t('success.createFacility'));
          saveNewFacilityCode(facilityData.code);
        }
        onOpenChange(false);
        if (onSuccess) onSuccess();
      } else {
        if (mode === 'edit') {
          showErrorToast(result.error || t('errors.update_facility'));
        } else {
          showErrorToast(result.error || t('errors.create_facility'));
        }
      }
    } catch (err) {
      console.error(err);
      showErrorToast(t('errors.create_facility'));
    } finally {
      setLoading(false);
    }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[650px] p-6 gap-5">
        <DialogHeader className="space-y-1 p-0">
          <DialogTitle className="text-lg font-semibold text-[#020617]">
            {mode === 'edit' ? t('facility.edit_facility') : t('facility.create_facility')}
          </DialogTitle>
          <DialogDescription className="text-[#64748B] text-sm">
            {mode === 'edit' ? t('facility.facility_edit_description') : t('facility.facility_create_description')}
          </DialogDescription>
        </DialogHeader>
        {fetchLoading ? (
          <div className="flex flex-col space-y-4 py-4">
            <div className="h-5 bg-gray-200 rounded w-1/3 animate-pulse"></div>
            <div className="h-10 bg-gray-200 rounded w-full animate-pulse"></div>
            <div className="h-5 bg-gray-200 rounded w-1/3 animate-pulse"></div>
            <div className="h-10 bg-gray-200 rounded w-full animate-pulse"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="h-20 bg-gray-200 rounded w-full animate-pulse"></div>
              <div className="h-20 bg-gray-200 rounded w-full animate-pulse"></div>
              <div className="h-20 bg-gray-200 rounded w-full animate-pulse"></div>
            </div>
            <div className="h-5 bg-gray-200 rounded w-1/3 animate-pulse"></div>
            <div className="h-10 bg-gray-200 rounded w-full animate-pulse"></div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1">
              <Label htmlFor="name" className="text-sm font-medium text-[#344054]">
                {t('facility.facility_name')} <span className="text-brand">*</span>
              </Label>
              <Input
                id="name"
                name="name"
                placeholder={t('facility.enter_facility_name_placeholder')}
                value={formData.name}
                onChange={handleChange}
                className={`h-9 px-3 py-2 bg-white ${errors.name ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FEE4E2]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.name && (
                <span className="text-sm text-[#F04438]">{errors.name}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="code" className="text-sm font-medium text-[#344054]">
                {t('facility.facility_code')}
              </Label>
              <PrefilledInput
                id="code"
                name="code"
                value={formData.code}
              />
              {errors.code && (
                <span className="text-sm text-[#F04438]">{errors.code}</span>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* City */}
              <div className="space-y-1">
                <Label htmlFor="province" className="text-sm font-medium text-[#344054]">
                  {t('facility.province')}
                </Label>
                <Combobox
                  options={provinces.map(p=>({ value: p.code, label: p.name }))}
                  value={formData.province}
                  onChange={(value)=>handleSelectChange('province', value)}
                  placeholder={t('facility.select_province_placeholder')}
                  className={`h-9 px-3 py-2 bg-white ${errors.province ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FEE4E2]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
                />
                {errors.province && (
                  <span className="text-sm text-[#F04438]">{errors.province}</span>
                )}
              </div>
              {/* District */}
              <div className="space-y-1">
                <Label htmlFor="district" className="text-sm font-medium text-[#344054]">
                  {t('facility.district')}
                </Label>
                <Combobox
                  options={districts.map(d=>({ value:d.code, label:d.name }))}
                  value={formData.district}
                  onChange={(value)=>handleSelectChange('district', value)}
                  placeholder={t('facility.select_district_placeholder')}
                  disabled={!formData.province}
                  className={`h-9 px-3 py-2 ${!formData.province ? "bg-[#FAFAFA] text-[#A1A1AA]" : "bg-white"} ${errors.district ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FEE4E2]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
                />
              </div>
              {/* Ward */}
              <div className="space-y-1">
                <Label htmlFor="ward" className="text-sm font-medium text-[#344054]">
                  {t('facility.ward')}
                </Label>
                <Combobox
                  options={wards.map(w=>({ value:w.code, label:w.name }))}
                  value={formData.ward}
                  onChange={(value)=>handleSelectChange('ward', value)}
                  placeholder={t('facility.select_ward_placeholder')}
                  disabled={!formData.district}
                  className={`h-9 px-3 py-2 ${!formData.district ? "bg-[#FAFAFA] text-[#A1A1AA]" : "bg-white"}`}
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="address" className="text-sm font-medium text-[#344054]">
                {t('personal.address')}
              </Label>
              <Input
                id="address"
                name="address"
                placeholder={t('facility.enter_address_placeholder')}
                value={formData.address}
                onChange={handleChange}
                className={`h-9 px-3 py-2 bg-white ${errors.address ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FEE4E2]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.address && (
                <span className="text-sm text-[#F04438]">{errors.address}</span>
              )}
            </div>
            <DialogFooter className="pt-4 flex justify-end gap-2">
              <DialogClose asChild>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="h-10 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB] rounded-md font-semibold"
                >
                  {t('common.cancel')}
                </Button>
              </DialogClose>
              <Button 
                type="submit" 
                disabled={loading}
                className={`h-10 px-4 py-2 bg-brand hover:bg-brand/90 text-white font-semibold rounded-md ${
                  loading ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                {loading ? t('common.loading') : (mode === 'edit' ? t('common.save') : t('common.addNew'))}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
} 