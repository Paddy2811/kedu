import React from "react";
import { useTranslation } from "react-i18next";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export function DeleteCourseDialog({ 
  open, 
  onOpenChange, 
  onConfirm, 
  courseName,
  loading = false 
}) {
  const { t } = useTranslation();

  const handleConfirm = () => {
    onConfirm();
  };

  const handleCancel = () => {
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold text-[#0F172A]">
            {t("course.delete_confirm_title", "Bạn có chắc chắn muốn xoá khoá học?")}
          </DialogTitle>
          <DialogDescription className="text-[#64748B] mt-2">
            {t("course.delete_confirm_description", "Các dữ liệu liên quan đến khoá học sẽ bị xoá. Hành động này không thể hoàn tác")}
          </DialogDescription>
        </DialogHeader>

        {courseName && (
          <div className="py-4">
            <div className="bg-[#FEF2F2] border border-[#FECACA] rounded-lg p-3">
              <p className="text-sm text-[#991B1B]">
                <span className="font-medium">{t("course.course_name", "Tên khóa học")}:</span> {courseName}
              </p>
            </div>
          </div>
        )}

        <DialogFooter className="flex justify-end gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={handleCancel}
            disabled={loading}
            className="h-9 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB]"
          >
            {t("course.delete_cancel", "Để sau")}
          </Button>
          <Button
            type="button"
            variant="destructive"
            onClick={handleConfirm}
            disabled={loading}
            className="h-9 px-4 py-2 bg-[#DC2626] hover:bg-[#B91C1C] text-white"
          >
            {loading ? t("common.processing", "Đang xử lý...") : t("course.delete_confirm", "Chắc chắn")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 