import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogClose,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PrefilledInput } from "@/components/ui/prefilled-input";
import { courseApi, CourseLevel, CourseLevelText, CourseStatus } from "@/api/services/course";
import { subjectApi } from "@/api/services/subject";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { ERROR_MESSAGES } from "@/data/constants";
import { useTranslation } from "react-i18next";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

// Simplified validation for the reduced form fields
const validateSimpleCourseData = (data, t) => {
  const errors = {};
  if (!data.name || data.name.trim() === '') {
    errors.name = t('validation.required_course_name');
  }
  if (!data.subject_id || data.subject_id.trim() === '') {
    errors.subject = t('validation.required_subject');
  }
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export function CourseDialog({ open, onOpenChange, onSuccess, mode = 'create', course, courseId }) {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    subject_id: "",
    level: "",
  });
  const [subjectOptions, setSubjectOptions] = useState([]);

  // Fetch course data for edit mode if courseId provided
  useEffect(() => {
    if (open) {
      // Fetch select options
      const fetchOptions = async () => {
        setFetchLoading(true);
        try {
          const subjectsRes = await subjectApi.getAll();
          setSubjectOptions(subjectsRes.items || []);

          // If edit mode, fetch course data
          if (mode === 'edit' && courseId) {
            const res = await courseApi.getCourseById(courseId);
            if (res.success && res.data) {
              const c = res.data;
              setFormData({
                name: c.name || "",
                code: c.code || "",
                subject_id: c.subject_id ? String(c.subject_id) : "",
                level: c.level || "",
              });
            } else {
              showErrorToast(res.error || t('errors.load_course_detail'));
              onOpenChange(false);
            }
          } else if (mode === 'edit' && course) {
            setFormData({
              name: course.name || "",
              code: course.code || "",
              subject_id: course.subject_id ? String(course.subject_id) : "",
              level: course.level || "",
            });
          } else {
            // Create mode - initialize with defaults
            setFormData({
              name: "",
              code: "",
              subject_id: "",
              level: "",
            });
          }
        } catch (error) {
          console.error(error);
          showErrorToast(t('errors.load_select_data'));
          onOpenChange(false);
        } finally {
          setFetchLoading(false);
        }
      };
      fetchOptions();
    }
    setErrors({});
  }, [open, mode, course, courseId, onOpenChange, t]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: null }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    const validation = validateSimpleCourseData(formData, t);
    if (!validation.isValid) {
      setErrors(validation.errors);
      showErrorToast(t('errors.required_fields'));
      setLoading(false);
      return;
    }

    try {
      // Prepare API data to match backend
      const apiData = {
        name: formData.name,
        subject_id: formData.subject_id ? Number(formData.subject_id) : undefined,
        level: formData.level,
        status: CourseStatus.ACTIVE,
      };
      
      let result;
      if (mode === 'edit' && (courseId || course?.id)) {
        result = await courseApi.updateCourse(courseId || course.id, apiData);
      } else {
        result = await courseApi.createCourse(apiData);
      }
      
      if (result.success) {
        if (mode === 'edit') {
          showSuccessToast(t('success.updateCourse'));
        } else {
          showSuccessToast(t('success.createCourse'));
        }
        onOpenChange(false);
        if (onSuccess) onSuccess();
      } else {
        if (mode === 'edit') {
          showErrorToast(result.error || t('errors.update_course'));
        } else {
          showErrorToast(result.error || t('errors.create_course'));
        }
      }
    } catch (err) {
      console.error(err);
      showErrorToast(err?.response?.data?.message || err.message || ERROR_MESSAGES.GENERIC_ERROR);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[650px] p-6 gap-5">
        <DialogHeader className="space-y-1 p-0">
          <DialogTitle className="text-lg font-semibold text-[#020617]">
            {mode === 'edit' ? t('course.edit_course', 'Chỉnh sửa khoá học') : t('course.create_course', 'Tạo khoá học')}
          </DialogTitle>
          <DialogDescription className="text-[#64748B] text-sm">
            {mode === 'edit' ? t('course.edit_description', 'Cập nhật thông tin khoá học') : t('course.create_description', 'Nhập thông tin để tạo khoá học mới')}
          </DialogDescription>
        </DialogHeader>
        {fetchLoading ? (
          <div className="flex flex-col space-y-4 py-4">
            <div className="h-5 bg-gray-200 rounded w-1/3 animate-pulse"></div>
            <div className="h-10 bg-gray-200 rounded w-full animate-pulse"></div>
            <div className="h-5 bg-gray-200 rounded w-1/3 animate-pulse"></div>
            <div className="h-10 bg-gray-200 rounded w-full animate-pulse"></div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <Label htmlFor="code" className="text-sm font-medium text-[#344054]">
                {t('course.course_code', 'Mã khoá học')}
              </Label>
              <Input
                id="code"
                name="code"
                placeholder={t('course.enter_course_code_placeholder', 'Nhập mã khoá học')}
                value={formData.code}
                onChange={handleChange}
                className="h-9 px-3 py-2 bg-white"
                autoComplete="off"
              />
              <span className="text-xs text-muted-foreground">
                {t('course.course_code_hint', 'Mã khoá học phải là duy nhất.')}
              </span>
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="name" className="text-sm font-medium text-[#344054]">
                {t('course.course_name')} <span className="text-red-500">*</span>
              </Label>
              <Input
                id="name"
                name="name"
                placeholder={t('course.enter_course_name_placeholder', 'Nhập tên khoá học')}
                value={formData.name}
                onChange={handleChange}
                className="h-9 px-3 py-2 bg-white"
              />
              {errors.name && (
                <span className="text-sm text-[#F04438]">{errors.name}</span>
              )}
            </div>

            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#344054]">
                {t('subject.subject')} <span className="text-red-500">*</span>
              </Label>
              <Select 
                value={formData.subject_id} 
                onValueChange={(v)=>handleChange({target:{name:'subject_id',value:v}})}
              >
                <SelectTrigger className="w-full h-9 px-3 py-2 bg-white" id="subject_id">
                  <SelectValue placeholder={t('subject.select_subject_placeholder', 'Chọn môn học')} />
                </SelectTrigger>
                <SelectContent className="max-h-60 overflow-y-auto">
                  {subjectOptions.map(opt=> (
                    <SelectItem key={opt.id} value={String(opt.id)}>{opt.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.subject && (
                <span className="text-sm text-[#F04438]">{errors.subject}</span>
              )}
            </div>

            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#344054]">
                {t('subject.level')}
              </Label>
              <Select 
                value={formData.level} 
                onValueChange={(v)=>handleChange({target:{name:'level',value:v}})}
              >
                <SelectTrigger className="w-full h-9 px-3 py-2 bg-white" id="level">
                  <SelectValue placeholder={t('subject.select_level_placeholder', 'Chọn trình độ')} />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(CourseLevel).map(key => (
                    <SelectItem key={key} value={CourseLevel[key]}>{CourseLevelText[CourseLevel[key]]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <DialogFooter className="pt-4 flex justify-end gap-2">
              <DialogClose asChild>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="h-10 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB] rounded-md font-semibold"
                >
                  {t('common.cancel', 'Huỷ')}
                </Button>
              </DialogClose>
              <Button 
                type="submit" 
                disabled={loading}
                className="h-10 px-4 py-2 bg-[#E67364] hover:bg-[#E67364]/90 text-white font-semibold rounded-md"
              >
                {loading ? t('common.loading', 'Đang xử lý...') : (mode === 'edit' ? t('common.save', 'Lưu') : t('common.addNew', 'Thêm mới'))}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
} 