import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { MoreVertical, Plus } from "lucide-react";
import { Button } from "../../components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { toast } from "sonner";
import { courseApi, CourseLevelText } from "@/api/services/course";
import { useTranslation } from "react-i18next";
import { CourseDialog } from "./CourseDialog";
import { DeleteCourseDialog } from "./DeleteCourseDialog";
import { MasterListLayout } from '@/components/layout/master-list-layout';

const SEARCH_MIN_CHARS = 1;

export default function CourseList() {
  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState([]);
  const [totalCourses, setTotalCourses] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [keyword, setKeyword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const pageSize = 10;
  const { t } = useTranslation();
  
  // Dialog state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState('create');
  const [selectedCourse, setSelectedCourse] = useState(null);
  
  // Delete dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  useBreadcrumb(t('course.course_list'), '/courses');

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        page: currentPage,
        pagesize: pageSize,
        keyword: keyword.trim() || undefined,
      };
      const res = await courseApi.getCourses(params);
      if (res.success) {
        setCourses(res.data.items);
        setTotalCourses(res.data.total);
        setTotalPages(Math.ceil(res.data.total / pageSize));
        console.log('Fetched courses:', res.data.items);
      } else {
        setError(res.error || t('errors.load_course_list'));
        setCourses([]);
        setTotalCourses(0);
        setTotalPages(1);
      }
    } catch (err) {
      console.error(err);
      setError(t('errors.load_course_list'));
      setCourses([]);
      setTotalCourses(0);
      setTotalPages(1);
    } finally {
      setLoading(false);
    }
  }, [currentPage, keyword, pageSize, t]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (keyword.length === 0 || keyword.length >= SEARCH_MIN_CHARS) {
        fetchData();
      }
    }, 400);
    return () => clearTimeout(timeout);
  }, [keyword, currentPage, fetchData]);

  const handleDelete = (course) => {
    setCourseToDelete(course);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!courseToDelete) return;
    
    setDeleteLoading(true);
    try {
      console.log("Deleting course:", courseToDelete.id);
      // Add your API call here
      // await courseApi.deleteCourse(courseToDelete.id);
      // Refresh the course list
      fetchData();
      toast.success(t('success.deleteCourse'));
      setDeleteDialogOpen(false);
      setCourseToDelete(null);
    } catch (err) {
      console.error(err);
      toast.error(t('errors.delete_course'));
    } finally {
      setDeleteLoading(false);
    }
  };
  
  const handleOpenCreateDialog = () => {
    setSelectedCourse(null);
    setDialogMode('create');
    setDialogOpen(true);
  };
  
  const handleOpenEditDialog = (course) => {
    setSelectedCourse(course);
    setDialogMode('edit');
    setDialogOpen(true);
  };
  
  const handleDialogSuccess = () => {
    fetchData();
  };

  // Define table columns
  const columns = [
    {
      key: 'name',
      header: t('course.course'),
      width: '300px',
      cellRenderer: (course) => (
        <div className="flex flex-col">
          <span className="text-[#020617] font-medium">{course.name}</span>
          <span className="text-[#64748B] text-sm">{course.code}</span>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex flex-col gap-2">
          <div className="h-5 bg-[#F1F5F9] rounded w-48 animate-pulse"></div>
          <div className="h-4 bg-[#F1F5F9] rounded w-24 animate-pulse"></div>
        </div>
      )
    },
    {
      key: 'subject_name',
      header: t('subject.subject'),
      width: '200px',
      cellRenderer: (course) => <span className="text-[#020617]">{course.subject_name}</span>,
      skeletonWidth: 'w-[120px]'
    },
    {
      key: 'level',
      header: t('subject.level'),
      width: '150px',
      cellRenderer: (course) => (
        <span className="text-[#020617]">{CourseLevelText[course.level] || course.level || '-'}</span>
      ),
      skeletonWidth: 'w-[100px]'
    },
    {
      key: 'class_count',
      header: t('course.total_classes'),
      width: '150px',
      align: 'center',
      cellRenderer: (course) => (
        <span className="text-[#020617]">{course.class_count || '0'} {t('class.classes').toLowerCase()}</span>
      ),
      skeletonWidth: 'w-[80px]'
    },
    {
      key: 'actions',
      header: '',
      width: '120px',
      align: 'right',
      cellRenderer: (course) => (
        <div className="flex items-center justify-end gap-3">
          <Button
            variant="link"
            className="text-brand hover:text-brand/90 p-0 h-auto font-medium"
            onClick={() => navigate(`/courses/${course.id}`)}
          >
            {t('common.detail')}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="h-9 w-9 p-0 hover:bg-[#F1F5F9]"
              >
                <MoreVertical className="w-4 h-4 text-brand" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleOpenEditDialog(course)}>
                {t('common.edit')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleDelete(course)}>
                {t('common.delete')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex items-center gap-3 justify-end">
          <div className="h-9 bg-[#F1F5F9] rounded w-16 animate-pulse"></div>
          <div className="h-9 bg-[#F1F5F9] rounded-full w-9 animate-pulse"></div>
        </div>
      )
    }
  ];

  return (
    <>
      <MasterListLayout
        title={t('course.course_list')}
        searchPlaceholder={t('course.search_course_placeholder')}
        searchValue={keyword}
        onSearchChange={setKeyword}
        columns={columns}
        data={courses}
        loading={loading}
        error={error}
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
        totalItems={totalCourses}
        itemsLabel={t('course.courses').toLowerCase()}
        emptyTitle={t('no_courses', 'Chưa có khóa học nào')}
        emptySubtitle={t('no_courses_subtitle', 'Khi có khóa học, chúng sẽ xuất hiện tại đây.')}
        emptyButtonText={t('common.addNew', 'Thêm mới')}
        onEmptyAction={handleOpenCreateDialog}
        emptyButtonIcon={<Plus className="w-4 h-4" />}
        showAddButton={true}
        addButtonText={t('common.addNew')}
        onAddClick={handleOpenCreateDialog}
      />
      
      {/* Course Dialog */}
      <CourseDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        mode={dialogMode}
        course={selectedCourse}
        courseId={selectedCourse?.id}
        onSuccess={handleDialogSuccess}
      />

      {/* Delete Course Dialog */}
      <DeleteCourseDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={handleConfirmDelete}
        courseName={courseToDelete?.name}
        loading={deleteLoading}
      />
    </>
  );
}