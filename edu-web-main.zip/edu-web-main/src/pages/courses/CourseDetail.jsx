import { useEffect, useState, useCallback } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { Pencil, BookOpen, MapPin, Calendar, Users2, ChevronRight, Plus } from "lucide-react";
import { toast } from 'sonner';

// Components
import MainLayout from "../../components/layout/main-layout";
import { PageContainer } from "@/components/page-container";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PlaceholderText } from "@/components/ui/placeholder-text";
import { EmptyState } from "@/components/ui/empty-state";
import { InfoCard } from "@/components/ui/info-card";
import { CourseDialog } from "./CourseDialog";

// Hooks and utils
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { formatDateDMY } from "@/lib/utils";
import { CourseLevelText } from "@/api/services/course";

// API
import { courseApi } from "@/api/services/course";
import { classApi, getClassStatusBadgeProps } from "@/api/services/class";

// Component to display course information fields
const InfoField = ({ label, value }) => (
  <div>
    <span className="text-[13px] text-[#64748B]">{label}</span>
    <p className="text-[13px] text-[#0F172A] mt-1">{value}</p>
  </div>
);

// Component for the course header section
const CourseHeader = ({ course, openEditDialog, t }) => (
  <div className="flex flex-col gap-5">
    <div className="flex flex-row justify-between items-start w-full">
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <h1 className="text-[18px] font-semibold text-[#020617]">
            <span>{course.name}</span>
            <span> - </span>
            <span className="text-[#71717A] font-medium">{course.code}</span>
          </h1>
        </div>
      </div>
      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={openEditDialog}
        >
          <Pencil className="w-4 h-4" />
          {t('common.edit')}
        </Button>
      </div>
    </div>

    {/* Subject and Level Info */}
    <div className="flex">
      <div className="flex flex-col gap-1 w-auto pr-9">
        <span className="text-sm font-medium text-[#64748B]">{t('subject.subject')}</span>
        <span className="text-sm text-[#020617]">{course.subject_name}</span>
      </div>
      <div className="flex flex-col gap-1 w-auto">
        <span className="text-sm font-medium text-[#64748B]">{t('subject.level')}</span>
        <span className="text-sm text-[#020617]">{CourseLevelText[course.level] || course.level || '-'}</span>
      </div>
    </div>
  </div>
);

// Component for the course info tab content
const CourseInfoTab = ({ course, t }) => (
  <div className="space-y-4">
    <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
      <div className="flex items-center gap-2 mb-4">
        <BookOpen className="w-4 h-4 text-[#0F172A]" />
        <h3 className="text-[15px] font-medium text-[#0F172A]">
          {t('course_detail.course_information')}
        </h3>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <InfoField label={t('subject.subject')} value={course.subject_name || t('registration.no_code')} />
        <InfoField label={t('subject.level')} value={CourseLevelText[course.level] || course.level || t('registration.no_code')} />
        <InfoField 
          label={t('student.student_count')} 
          value={`${course.current_student_count || 0}/${course.max_student_count || 0} ${t('student.students_plural').toLowerCase()}`} 
        />
        <InfoField 
          label={t('course_detail.total_sessions_label')} 
          value={`${course.session_count || 0} ${t('schedule.session_count_unit')}`} 
        />
        <InfoField label={t('course_detail.duration_per_session')} value={course.duration_per_session || t('registration.no_code')} />
        <InfoField label={t('course_detail.opening_date')} value={course.opening_date || t('registration.no_code')} />
        <InfoField label={t('course_detail.facility_address')} value={course.facility_name || t('registration.no_code')} className="col-span-3" />
      </div>
    </div>
  </div>
);

// Class Card component
const ClassCard = ({ classItem, t }) => {
  const statusProps = getClassStatusBadgeProps(classItem.status);
  
  return (
    <div className="border border-[#E2E8F0] rounded-lg p-4 flex flex-col gap-2">
      <div className="flex justify-between items-center">
        <h3 className="text-base font-medium text-[#020617]">{classItem.code}</h3>
        <Badge className={statusProps.className}>{statusProps.label}</Badge>
      </div>
      
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-[#71717A]" />
          <span className="text-sm text-[#64748B]">{classItem.facility_name || t('registration.no_code')}</span>
        </div>
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-[#64748B]" />
          <span className="text-sm text-[#64748B]">{classItem.opening_date || t('registration.no_code')}</span>
        </div>
        <div className="flex items-center gap-2">
          <Users2 className="w-4 h-4 text-[#64748B]" />
          <span className="text-sm text-[#64748B]">
            {(classItem.current_student_count ?? t('registration.no_code')) + "/" + (classItem.max_student_count ?? t('registration.no_code'))} {t('student.students_plural').toLowerCase()}
          </span>
        </div>
      </div>
      
      <div className="flex justify-end mt-2">
        <Button variant="link" className="text-brand p-0 h-auto" asChild>
          <Link to={`/classes/${classItem.id}`}>
            {t('common.detail')}
          </Link>
        </Button>
      </div>
    </div>
  );
};

// Component for classes tab content
const ClassesTab = ({ course, t, navigate }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalPages, setTotalPages] = useState(0);
  const itemsPerPage = 9;
  
  // Fetch classes data from API
  useEffect(() => {
    const fetchClasses = async () => {
      if (!course?.id) return;
      
      setLoading(true);
      try {
        const res = await classApi.getClasses({
          course_id: course.id,
          page: currentPage,
          pagesize: itemsPerPage
        });
        
        if (res.success) {
          setClasses(res.data.items || []);
          setTotalPages(Math.ceil(res.data.total / itemsPerPage));
        } else {
          console.error('Failed to fetch classes:', res.error);
          setClasses([]);
        }
      } catch (error) {
        console.error('Error fetching classes:', error);
        setClasses([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchClasses();
  }, [course?.id, currentPage]);
  
  if (loading) {
    return (
      <div className="w-full rounded-xl bg-white p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-[15px] font-medium text-[#020617]">{t('class.classes')}</h3>
          <Button variant="outline" disabled>
            <Plus className="w-4 h-4 mr-2" />
            {t('course_detail.add_class')}
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {[...Array(3)].map((_, index) => (
            <div key={index} className="border border-[#E2E8F0] rounded-lg p-4 flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-6 w-24" />
              </div>
              <div className="flex flex-col gap-1 mt-2">
                <div className="flex items-center gap-2">
                  <Skeleton className="h-4 w-4" />
                  <Skeleton className="h-4 w-24" />
                </div>
      <div className="flex items-center gap-2">
                  <Skeleton className="h-4 w-4" />
                  <Skeleton className="h-4 w-20" />
                </div>
              </div>
              <div className="flex justify-end mt-2">
                <Skeleton className="h-8 w-16" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="w-full rounded-xl bg-white p-4">
      {classes.length > 0 ? (
        <>
          {/* Header with Add Class button - only shown when there are classes */}
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-[15px] font-medium text-[#020617]">{t('class.classes')}</h3>
            <Button 
              variant="outline"
              asChild
            >
              <Link to={`/classes/create?courseId=${course.id}`}>
                <Plus className="w-4 h-4 mr-2" />
                {t('course_detail.add_class')}
              </Link>
            </Button>
          </div>
          
          {/* Classes grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {classes.map((classItem) => {
              const statusProps = getClassStatusBadgeProps(classItem.status);
              return (
                <InfoCard
                  key={classItem.id}
                  title={classItem.code}
                  status={{
                    variant: "outline",
                    className: statusProps.className,
                    label: statusProps.children
                  }}
                  infoItems={[
                    {
                      icon: <MapPin className="w-4 h-4 text-[#71717A]" />,
                      label: classItem.facility_name || course.facility_name || ''
                    },
                    {
                      icon: <Calendar className="w-4 h-4 text-[#64748B]" />,
                      label: classItem.opening_date ? formatDateDMY(classItem.opening_date) : ''
                    },
                    {
                      icon: <Users2 className="w-4 h-4 text-[#64748B]" />,
                      label: `${classItem.current_student_count || 0}/${classItem.max_student_count || 0} ${t('student.student_count_unit').toLowerCase()}`
                    }
                  ]}
                  detailText={t('common.detail')}
                  detailLink={`/classes/${classItem.id}`}
                  clickable={true}
                />
              );
            })}
          </div>
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-end">
              <div className="flex items-center gap-1">
                {Array.from({ length: totalPages }).map((_, index) => {
                  const pageNumber = index + 1;
                  return (
                    <Button
                      key={pageNumber}
                      variant={currentPage === pageNumber ? "outline" : "ghost"}
                      className={`h-10 w-10 rounded-md p-0 ${currentPage === pageNumber ? 'border-[#E67364] text-[#020617]' : ''}`}
                      onClick={() => setCurrentPage(pageNumber)}
                    >
                      {pageNumber}
                    </Button>
                  );
                })}
              </div>
            </div>
          )}
        </>
      ) : (
        <EmptyState
          title={t('course_detail.no_classes_in_course')}
          subtitle={t('course_detail.create_first_class')}
          buttonText={t('course_detail.add_class')}
          buttonIcon={<Plus className="w-4 h-4" />}
          onButtonClick={() => navigate(`/classes/create?courseId=${course.id}`)}
          noBorder
        />
      )}
    </div>
);
};

// Loading skeleton for the course detail
const CourseDetailSkeleton = () => (
  <div className="space-y-4">
    <div className="rounded-xl bg-white border border-[#E2E8F0] p-6">
      <div className="flex flex-col gap-5">
        <div className="flex flex-row justify-between items-start w-full">
          <div className="flex flex-col gap-2">
            <Skeleton className="h-7 w-64" />
            <Skeleton className="h-5 w-32" />
          </div>
          <div className="flex gap-3">
            <Skeleton className="h-9 w-28" />
          </div>
        </div>
        <div className="flex gap-9 mt-4">
          <div className="flex flex-col gap-1">
            <Skeleton className="h-5 w-20" />
            <Skeleton className="h-6 w-32" />
          </div>
          <div className="flex flex-col gap-1">
            <Skeleton className="h-5 w-20" />
            <Skeleton className="h-6 w-32" />
          </div>
        </div>
      </div>
    </div>

    <Skeleton className="w-full h-[44px] rounded-lg" />
    
    <div className="mt-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[...Array(3)].map((_, index) => (
          <div key={index} className="border border-[#E2E8F0] rounded-lg p-4 flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <Skeleton className="h-6 w-32" />
              <Skeleton className="h-6 w-24" />
            </div>
            <div className="flex flex-col gap-1 mt-2">
              <div className="flex items-center gap-2">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-24" />
              </div>
              <div className="flex items-center gap-2">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-20" />
              </div>
            </div>
            <div className="flex justify-end mt-2">
              <Skeleton className="h-8 w-16" />
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

export default function CourseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("classes");
  const { t } = useTranslation();
  
  // Dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  
  // Set breadcrumbs
  useBreadcrumb(t('course.course_list'), '/courses');
  useBreadcrumb(t('course.course_detail'));

  // Fetch course data - memoized to prevent re-creation
  const fetchCourse = useCallback(async () => {
    if (!id) return;
    
      setLoading(true);
      try {
        const res = await courseApi.getCourseById(id);
        if (res.success && res.data) {
        // Map data inline to avoid dependency issues
        const mappedData = {
          id: res.data.id,
          code: res.data.code,
          name: res.data.name,
          subject_name: res.data.subject_name || '',
          subject_id: res.data.subject_id,
          level: res.data.level,
          facility_name: res.data.facility_name || '',
          facility_id: res.data.facility_id,
          max_student_count: res.data.max_student_count || 0,
          current_student_count: res.data.current_student_count || 0,
          session_count: res.data.session_count || 0,
          completed_sessions: res.data.completed_sessions || 0,
          duration_per_session: res.data.duration_per_session ? `${res.data.duration_per_session} ${t('schedule.minute_unit')} ${t('finance.per_session_suffix')}` : '',
          opening_date: res.data.opening_date ? formatDateDMY(res.data.opening_date) : '',
          teacher_id: res.data.teacher_id,
          teacher_full_name: res.data.teacher_full_name,
          teacher_initials: res.data.teacher_full_name ? res.data.teacher_full_name.split(' ').map(w=>w[0]).join('').toUpperCase() : '',
          price_per_session: res.data.price_per_session ? `${res.data.price_per_session.toLocaleString('vi-VN')}đ` : '',
          status: res.data.status || '',
          sessions: res.data.sessions || [],
        };
        setCourse(mappedData);
        } else {
          setCourse(null);
        toast.error(res.error || t('errors.load_course_detail'));
        }
      } catch (e) {
        setCourse(null);
      toast.error(e?.response?.data?.message || e.message || t('errors.load_course_detail'));
      } finally {
        setLoading(false);
      }
  }, [id, t]); // depend on id and t

  // Only fetch when id changes
  useEffect(() => {
    fetchCourse();
  }, [id, fetchCourse]); // depend on id and fetchCourse
  
  const handleOpenEditDialog = () => {
    setEditDialogOpen(true);
    };
    
  const handleEditSuccess = () => {
    fetchCourse();
  };

  // Render content based on loading state
  const renderContent = () => {
    if (loading) {
      return <CourseDetailSkeleton />;
    }

    if (!course) {
      return (
        <div className="w-full rounded-xl border border-[#E2E8F0] bg-white p-6 text-sm text-[#8B9AA2]">
          {t('course.not_found_course')}
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <div className="rounded-xl bg-white border border-[#E2E8F0] p-6">
          <CourseHeader course={course} openEditDialog={handleOpenEditDialog} t={t} />
        </div>

        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="bg-[#F8FAFC] p-1 h-auto rounded-lg mb-4 border border-[#E2E8F0]">
            <TabsTrigger
              value="classes"
              className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
            >
              {t('class.classes')}
            </TabsTrigger>
            <TabsTrigger
              value="info"
              className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
            >
              {t('registration.info')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="classes" className="border border-[#E2E8F0] rounded-xl">
            <ClassesTab course={course} t={t} navigate={navigate} />
          </TabsContent>

          <TabsContent value="info">
            <CourseInfoTab course={course} t={t} />
          </TabsContent>
        </Tabs>
        
        {/* Course Edit Dialog */}
        <CourseDialog
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          mode="edit"
          course={course}
          courseId={id}
          onSuccess={handleEditSuccess}
        />
      </div>
    );
  };

  return (
    <MainLayout>
      <PageContainer title={t('course.course_detail')}>
        {renderContent()}
      </PageContainer>
    </MainLayout>
  );
}
