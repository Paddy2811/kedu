import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { ChevronRight } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ATTENDANCE_STATUSES, attendanceUtils, attendanceApi } from "@/api/services/attendance";

export default function EditAttendanceDialog({ 
  open, 
  onOpenChange, 
  student, 
  currentStatus,
  attendanceId,
  onConfirm 
}) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [selectedStatus, setSelectedStatus] = useState(currentStatus || "");
  const [absenceReason, setAbsenceReason] = useState("");
  const [description, setDescription] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Define status options using constants from attendance service
  const statusOptions = [
    { value: ATTENDANCE_STATUSES.PRESENT, label: t("attendance.attendance_status.PRESENT") },
    { value: ATTENDANCE_STATUSES.EXCUSED, label: t("attendance.attendance_status.EXCUSED") },
    { value: ATTENDANCE_STATUSES.ABSENT, label: t("attendance.attendance_status.ABSENT") },
    { value: ATTENDANCE_STATUSES.NOT_CHECKED, label: t("attendance.attendance_status.NOT_CHECKED") }
  ];

  // Define absence reason options as a memoized array
  const absenceReasonOptions = useMemo(() => [
    { value: "sick", label: t("attendance.reasons.sick") },
    { value: "family_matter", label: t("attendance.reasons.family_matter") },
    { value: "transportation", label: t("attendance.reasons.transportation") },
    { value: "appointment", label: t("attendance.reasons.appointment") },
    { value: "other", label: t("attendance.reasons.other") }
  ], [t]);

  const handleConfirm = async () => {
    if (!selectedStatus) {
      toast({
        variant: 'destructive',
        description: t("attendance.attendance_edit.select_status_error")
      });
      return;
    }

    // If status is excused, require a reason
    if (selectedStatus === ATTENDANCE_STATUSES.EXCUSED && !absenceReason) {
      toast({
        variant: 'destructive',
        description: t("attendance.attendance_edit.select_reason_error")
      });
      return;
    }

    // If reason is "other", require a description
    if (absenceReason === "other" && !description) {
      toast({
        variant: 'destructive',
        description: t("attendance.attendance_edit.enter_description_error")
      });
      return;
    }

    setIsLoading(true);

    try {
      // Prepare note based on status and reason
      let note = null;
      if (selectedStatus === ATTENDANCE_STATUSES.EXCUSED) {
        if (absenceReason === "other") {
          note = description;
        } else {
          note = t(`attendance.reasons.${absenceReason}`);
        }
      }

      // Call API to update attendance
      const response = await attendanceApi.updateAttendance(attendanceId, {
        status: selectedStatus,
        note: note
      });

      if (response.success) {
        toast({
          description: t("attendance.attendance_edit.success", {
            name: student?.student_full_name,
            status: t(`attendance.attendance_status.${selectedStatus}`)
          })
        });

        // Call the onConfirm callback to refresh parent component
    onConfirm(
      student?.id, 
      selectedStatus, 
          selectedStatus === ATTENDANCE_STATUSES.EXCUSED ? absenceReason : null,
      absenceReason === "other" ? description : null
    );
    
    // Close the dialog
    onOpenChange(false);
      } else {
        toast({
          variant: 'destructive',
          description: response.error || t("common.error_occurred")
        });
      }
    } catch {
      toast({
        variant: 'destructive',
        description: t("common.error_occurred")
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDialogChange = (isOpen) => {
    if (!isOpen) {
      // Reset state when dialog is closed
      setSelectedStatus(currentStatus || "");
      setAbsenceReason("");
      setDescription("");
    }
    onOpenChange(isOpen);
  };

  // Get the current status label
  const getCurrentStatusLabel = () => {
    const statusOption = statusOptions.find(option => option.value === currentStatus);
    return statusOption ? statusOption.label : t("attendance.attendance_status.NOT_CHECKED");
  };

  // Get background color for status using attendance service
  const getStatusBgColor = (status) => {
    const config = attendanceUtils.getStatusBadgeConfig(status, t);
    return config.className;
  };

  return (
    <Dialog open={open} onOpenChange={handleDialogChange}>
      <DialogContent className="sm:max-w-[600px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">{t("attendance.attendance_edit.title")}</DialogTitle>
          <DialogDescription>
            {t("attendance.attendance_edit.description", { 
              name: student?.student_full_name, 
              code: student?.student_code 
            })}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex justify-center items-center gap-5 w-full my-4">
          {/* Current Status */}
          <div className={`px-4 py-2 rounded-md ${getStatusBgColor(currentStatus)}`}>
            {getCurrentStatusLabel()}
          </div>
          
          {/* Arrow */}
          <ChevronRight className="w-6 h-6 text-gray-400" />
          
          {/* New Status Select */}
          <Select 
            value={selectedStatus} 
            onValueChange={setSelectedStatus}
          >
            <SelectTrigger className="w-[250px] bg-[#EDEDED] border-[#EDEDED]">
              <SelectValue placeholder={t("attendance.attendance_edit.select_status")} />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map(option => {
                const config = attendanceUtils.getStatusBadgeConfig(option.value, t);
                return (
                <SelectItem 
                  key={option.value} 
                  value={option.value}
                    className={config.className}
                >
                  {option.label}
                </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>
        
        {/* Reason Select - Only show if excused is selected */}
        {selectedStatus === ATTENDANCE_STATUSES.EXCUSED && (
          <div className="mt-6">
            <Label htmlFor="absence-reason" className="text-[#64748B] font-medium mb-2 block">
              {t("attendance.attendance_edit.absence_reason")} <span className="text-red-500">*</span>
            </Label>
            <Select 
              value={absenceReason} 
              onValueChange={setAbsenceReason}
            >
              <SelectTrigger id="absence-reason" className="w-full bg-white border-[#E4E4E7]">
                <SelectValue placeholder={t("attendance.attendance_edit.select_reason")} />
              </SelectTrigger>
              <SelectContent>
                {absenceReasonOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {/* Description Text Area - Only show if "other" is selected as reason */}
            {absenceReason === "other" && (
              <div className="mt-4">
                <Label htmlFor="description" className="text-[#64748B] font-medium mb-2 block">
                  {t("attendance.attendance_edit.description_label")} <span className="text-red-500">*</span>
                </Label>
                <Textarea 
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t("attendance.attendance_edit.description_placeholder")}
                  className="border-[#E4E4E7] w-full resize-none"
                />
              </div>
            )}
          </div>
        )}
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
            {t("common.cancel")}
          </Button>
          <Button 
            className="bg-[#E67364] hover:bg-[#E67364]/90 text-white"
            onClick={handleConfirm}
            disabled={isLoading}
          >
            {isLoading ? t("common.saving") : t("confirm")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 