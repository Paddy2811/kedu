import { useState, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { format } from "date-fns";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function AbsenceDialog({ 
  open, 
  onOpenChange, 
  student, 
  sessionInfo, 
  currentDate,
  onConfirm 
}) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [absenceReason, setAbsenceReason] = useState("");
  const [hasReason, setHasReason] = useState(false);
  const [description, setDescription] = useState("");

  // Define absence reason options as a memoized array
  const absenceReasonOptions = useMemo(() => [
    { value: "sick", label: t("absence_dialog.reasons.sick", "Sick") },
    { value: "family_matter", label: t("absence_dialog.reasons.family_matter", "Family matter") },
    { value: "transportation", label: t("absence_dialog.reasons.transportation", "Transportation issue") },
    { value: "appointment", label: t("absence_dialog.reasons.appointment", "Medical appointment") },
    { value: "other", label: t("absence_dialog.reasons.other", "Other") }
  ], [t]);

  const handleConfirmAbsence = () => {
    // Show success toast
    toast({
      title: t("attendance.attendance_success_absent", "Student marked absent", { 
        name: student?.name 
      }),
      description: t("attendance.attendance_success_absent_description", "Student has been marked as absent", { 
        name: student?.name 
      }),
    });
    
    // Call the onConfirm callback with the selected reason and description if reason is "other"
    const reasonDetail = absenceReason === "other" ? description : null;
    onConfirm(student?.id, hasReason ? absenceReason : null, hasReason, reasonDetail);
    
    // Reset state
    setAbsenceReason("");
    setHasReason(false);
    setDescription("");
  };

  const handleDialogChange = (isOpen) => {
    if (!isOpen) {
      // Reset state when dialog is closed
      setAbsenceReason("");
      setHasReason(false);
      setDescription("");
    }
    onOpenChange(isOpen);
  };

  const isOtherSelected = absenceReason === "other";
  const isConfirmDisabled = hasReason && (!absenceReason || (isOtherSelected && !description));

  return (
    <Dialog open={open} onOpenChange={handleDialogChange}>
      <DialogContent className="sm:max-w-[550px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">{t("absence_dialog.title", "Mark Absence")}</DialogTitle>
          <DialogDescription>
            {t("absence_dialog.description", "Please provide absence information for this student")}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-3 my-4">
          {/* Student Info */}
          <div className="flex justify-between items-center">
            <div className="w-[120px] text-[#64748B] font-medium">{t("student.student_name", "Student name")}</div>
            <div className="text-[#0973DC] font-medium">
              {student?.name || t("absence_dialog.default_student_name", "Student Name")}
            </div>
          </div>
          
          {/* Session Info */}
          <div className="flex justify-between items-center">
            <div className="w-[120px] text-[#64748B] font-medium">{t("schedule.session", "Session")}</div>
            <div className="text-[#020617] font-medium">
              {sessionInfo ? `${sessionInfo.class} - ${sessionInfo.session}` : t("absence_dialog.default_session", "BF12 - Session 9/36")}
            </div>
          </div>
          
          {/* Time Info */}
          <div className="flex justify-between items-center">
            <div className="w-[120px] text-[#64748B] font-medium">{t("session_info.time", "Time")}</div>
            <div className="text-[#020617] font-medium">
              {sessionInfo ? sessionInfo.time : t("absence_dialog.default_time", "16:00")} - {currentDate ? format(currentDate, "dd/MM/yyyy") : t("absence_dialog.default_date", "22/06/2026")}
            </div>
          </div>
          
          {/* Has Reason Toggle */}
          <div className="flex items-center justify-between mt-6 mb-2">
            <Label htmlFor="has-reason" className="text-[#64748B] font-medium">
              {t("absence_dialog.has_reason", "Has reason for absence")}
            </Label>
            <Switch 
              id="has-reason" 
              checked={hasReason} 
              onCheckedChange={setHasReason} 
            />
          </div>
          
          {/* Reason Select */}
          <div className="mt-4">
            <Select 
              value={absenceReason} 
              onValueChange={setAbsenceReason}
              disabled={!hasReason}
            >
              <SelectTrigger className={`w-full border-[#E4E4E7] ${!hasReason ? 'opacity-50 cursor-not-allowed' : ''}`}>
                <SelectValue placeholder={t("absence_dialog.select_reason", "Select absence reason")} />
              </SelectTrigger>
              <SelectContent>
                {absenceReasonOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Description Text Area (only shown when "other" is selected) */}
          {hasReason && isOtherSelected && (
            <div className="mt-4">
              <Label htmlFor="description" className="text-[#64748B] font-medium mb-2 block">
                {t("absence_dialog.description_label", "Description")} <span className="text-red-500">*</span>
              </Label>
              <Textarea 
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={t("absence_dialog.description_placeholder", "Please provide details about the absence reason")}
                className="border-[#E4E4E7] w-full resize-none"
              />
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t("common.cancel", "Cancel")}
          </Button>
          <Button 
            className="bg-[#E67364] hover:bg-[#E67364]/90 text-white"
            onClick={handleConfirmAbsence}
            disabled={isConfirmDisabled}
          >
            {t("common.confirm", "Confirm")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 