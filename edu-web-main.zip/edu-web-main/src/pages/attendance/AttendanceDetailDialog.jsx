import { useState, useEffect, useCallback } from "react";
import { useTranslation } from "react-i18next";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { attendanceUtils, attendanceApi } from "@/api/services/attendance";
import { X, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { formatTimeHHMM, formatDateDMY } from "@/lib/utils";

export default function AttendanceDetailDialog({ 
  open, 
  onOpenChange, 
  student, 
  onEdit
}) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [attendanceDetail, setAttendanceDetail] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchAttendanceDetail = useCallback(async () => {
    if (!student?.attendance_id) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await attendanceApi.getAttendanceDetail(student.attendance_id);
      
      if (response.success) {
        setAttendanceDetail(response.data);
      } else {
        setError(response.error);
        toast({
          variant: 'destructive',
          description: response.error || t("common.error_occurred")
        });
      }
    } catch {
      setError(t("common.error_occurred"));
      toast({
        variant: 'destructive',
        description: t("common.error_occurred")
      });
    } finally {
      setIsLoading(false);
    }
  }, [student?.attendance_id, t, toast]);

  // Fetch attendance detail when dialog opens
  useEffect(() => {
    if (open && student?.attendance_id) {
      fetchAttendanceDetail();
    }
  }, [open, student?.attendance_id, fetchAttendanceDetail]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!open) {
      setAttendanceDetail(null);
      setError(null);
    }
  }, [open]);

  // Get status badge for attendance (using service)
  const getStatusBadge = (status) => {
    const config = attendanceUtils.getStatusBadgeConfig(status, t);
    return <Badge className={config.className}>{config.text}</Badge>;
  };

  // Handle edit button click
  const handleEdit = () => {
    onEdit(student?.id);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">{t("attendance_detail.title")}</DialogTitle>
          <DialogDescription>
            {t("attendance_detail.description")}
          </DialogDescription>
        </DialogHeader>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="w-6 h-6 text-[#E67364] animate-spin" />
            <span className="ml-2 text-[#71717A]">{t("common.loading")}</span>
          </div>
        ) : error ? (
          <div className="flex justify-center items-center py-8">
            <div className="text-center">
              <div className="text-red-500 mb-2">{error}</div>
              <Button variant="outline" onClick={fetchAttendanceDetail}>
                {t("common.retry")}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3 my-4">
            {/* Student Info */}
            <div className="flex justify-between items-center">
              <div className="w-[120px] text-[#64748B] font-medium">{t("student.student_name")}</div>
              <div className="text-[#0973DC] font-medium">
              {attendanceDetail?.student_code || student?.student_code} - 
                {attendanceDetail?.student_full_name || student?.student_full_name}
              </div>
            </div>
            
            {/* Session Info */}
            <div className="flex justify-between items-center">
              <div className="w-[120px] text-[#64748B] font-medium">{t("schedule.session")}</div>
              <div className="text-[#020617] font-medium">
                {attendanceDetail?.session_name || '---'}
              </div>
            </div>
            
            {/* Time Info */}
            <div className="flex justify-between items-center">
              <div className="w-[120px] text-[#64748B] font-medium">{t("session_info.time")}</div>
              <div className="text-[#020617] font-medium">
                {attendanceDetail?.session_start_time ? formatTimeHHMM(attendanceDetail.session_start_time) : '---'} - {attendanceDetail?.session_study_date ? formatDateDMY(attendanceDetail.session_study_date) : '---'}
              </div>
            </div>
            
            {/* Marked By */}
            <div className="flex justify-between items-center">
              <div className="w-[120px] text-[#64748B] font-medium">{t("attendance_detail.marked_by")}</div>
              <div className="text-[#0973DC] font-medium">
                {attendanceDetail?.checked_by_full_name || '---'}
              </div>
            </div>
            
            {/* Status */}
            <div className="flex justify-between items-center">
              <div className="w-[120px] text-[#64748B] font-medium">{t("common.status")}</div>
              <div>
                {getStatusBadge(attendanceDetail?.status)}
              </div>
            </div>
            
            {/* Absence Reason - only show if excused with note */}
            {attendanceDetail?.status === "EXCUSED" && attendanceDetail?.note && (
              <div className="flex justify-between items-center">
                <div className="w-[120px] text-[#64748B] font-medium">{t("attendance_detail.absence_reason")}</div>
                <div className="text-[#020617] font-medium">
                  {attendanceDetail.note}
                </div>
              </div>
            )}
          </div>
        )}
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t("common.cancel")}
          </Button>
          <Button 
            className="bg-[#E67364] hover:bg-[#E67364]/90 text-white"
            onClick={handleEdit}
          >
            {t("common.edit")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 