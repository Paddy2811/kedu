import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "react-router-dom";
import { PageContainer } from "@/components/page-container";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState } from "@/components/ui/empty-state";
import { format } from "date-fns";
import { CalendarIcon, Search, AlertCircle, Clock, Check, Pencil, Info, ChevronLeft, ChevronRight, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { facilityApi } from "@/api/services/facility";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ATTENDANCE_STATUSES } from "@/api/services/attendance";
import MainLayout from "@/components/layout/main-layout";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Pagination } from "@/components/ui/pagination";
import { Skeleton } from "@/components/ui/skeleton";
import AbsenceDialog from "./AbsenceDialog";
import AttendanceDetailDialog from "./AttendanceDetailDialog";
import EditAttendanceDialog from "./EditAttendanceDialog";
import { toast } from "sonner";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { getInitials, toDateInputValue, formatTimeHHMM } from "@/lib/utils";
import { sessionApi } from "@/api/services/session";
import { attendanceApi, attendanceUtils } from "@/api/services/attendance";





export default function AttendanceCheck() {
  const { t } = useTranslation();
  const location = useLocation();
  
  // Set breadcrumb for this page
  useBreadcrumb(t("attendance.attendance"), "/attendance");
  
  // State management
  const [date, setDate] = useState(new Date());
  const [facilities, setFacilities] = useState([]);
  const [selectedFacility, setSelectedFacility] = useState("");
  const [selectedSession, setSelectedSession] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAttendanceList, setShowAttendanceList] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [classes, setClasses] = useState([]);
  const [classesLoading, setClassesLoading] = useState(false);
  const [classesError, setClassesError] = useState("");
  
  // Attendance data state
  const [attendanceData, setAttendanceData] = useState([]);
  const [attendanceError, setAttendanceError] = useState("");
  const [sessionInfo, setSessionInfo] = useState(null);

  // Dialog states
  const [absenceDialogOpen, setAbsenceDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  
  // Popover states
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10; // Number of items per page

  // Search debouncing
  const searchTimeoutRef = useRef(null);
  const [isSearching, setIsSearching] = useState(false);

  // Handle navigation state from Home page
  useEffect(() => {
    if (location.state) {
      const { date, facilityId, sessionId, autoCheck } = location.state;
      
      // Set date if provided
      if (date) {
        setDate(new Date(date));
      }
      
      // Set facility if provided
      if (facilityId) {
        setSelectedFacility(facilityId);
      }
      
      // Set session and show attendance list if provided
      if (sessionId) {
        setSelectedSession(sessionId);
        if (autoCheck) {
          setShowAttendanceList(true);
        }
      }
    }
  }, [location.state]);

  // Fetch facilities on component mount
  useEffect(() => {
    const fetchFacilities = async () => {
      try {
        const response = await facilityApi.getAll();
        if (response.success && response.items) {
          setFacilities(response.items);
        }
      } catch (error) {
        console.error("Error fetching facilities:", error);
        toast.error(t("errors.load_facilities"));
      }
    };

    fetchFacilities();
  }, [t]);

  // Fetch attendance data function
  const fetchAttendanceData = useCallback(() => {
    if (selectedSession && showAttendanceList && date) {
      setIsLoading(true);
      setAttendanceError("");
      
      const studyDateStr = toDateInputValue(date);
      
      attendanceApi.getAttendances({
        page: 1,
        pagesize: 10,
        study_date: studyDateStr,
        class_id: parseInt(selectedSession),
        facility_id: parseInt(selectedFacility)
      })
        .then(res => {
          if (res.success) {
            // Lưu session_info từ API response
            if (res.session_info) {
              setSessionInfo(res.session_info);
            }
            
            if (res.data && Array.isArray(res.data)) {
              const studentsFromAPI = attendanceUtils.convertApiDataToUI(res.data);
              setAttendanceData(studentsFromAPI);
            } else {
              setAttendanceData([]);
            }
          } else {
            setAttendanceData([]);
            setSessionInfo(null);
            setAttendanceError(res.error || "Lỗi khi tải danh sách điểm danh");
          }
        })
        .catch(err => {
          setAttendanceData([]);
          setSessionInfo(null);
          setAttendanceError(err.message || "Lỗi khi tải danh sách điểm danh");
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, [selectedSession, showAttendanceList, date, selectedFacility]);

  // Debounced search function
  const debouncedSearch = useCallback((query) => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    searchTimeoutRef.current = setTimeout(() => {
      if (query.length > 0 && selectedSession && showAttendanceList && date) {
        setIsSearching(true);
        setAttendanceError("");
        
        const studyDateStr = toDateInputValue(date);
        
        attendanceApi.getAttendances({
          page: 1,
          pagesize: 10,
          study_date: studyDateStr,
          class_id: parseInt(selectedSession),
          facility_id: parseInt(selectedFacility),
          keyword: query
        })
          .then(res => {
            if (res.success) {
              // Lưu session_info từ API response
              if (res.session_info) {
                setSessionInfo(res.session_info);
              }
              
              if (res.data && Array.isArray(res.data)) {
                const studentsFromAPI = attendanceUtils.convertApiDataToUI(res.data);
                setAttendanceData(studentsFromAPI);
              } else {
                setAttendanceData([]);
              }
            } else {
              setAttendanceData([]);
              setSessionInfo(null);
              setAttendanceError(res.error || "Lỗi khi tìm kiếm");
            }
          })
          .catch(err => {
            setAttendanceData([]);
            setSessionInfo(null);
            setAttendanceError(err.message || "Lỗi khi tìm kiếm");
          })
          .finally(() => {
            setIsSearching(false);
          });
      } else if (query.length === 0 && selectedSession && showAttendanceList && date) {
        // If search is cleared, fetch all data again
        fetchAttendanceData();
      }
    }, 500); // 500ms delay
  }, [selectedSession, showAttendanceList, date, selectedFacility, fetchAttendanceData]);

  // Fetch attendance data when class is selected
  useEffect(() => {
    fetchAttendanceData();
  }, [fetchAttendanceData]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!selectedFacility || !date) {
      setClasses([]);
      return;
    }
    setClassesLoading(true);
    // Format date về yyyy-MM-dd bằng hàm tiện ích chung
    const studyDateStr = toDateInputValue(date);
    sessionApi.getSessionsByFacility({
      facility_id: selectedFacility,
      study_date: studyDateStr,
    })
      .then(res => {
        if (res.success) {
          setClasses(res.items);
          setClassesError("");
        } else {
          setClasses([]);
          setClassesError(res.error || "Lỗi khi tải danh sách lớp học");
        }
      })
      .catch(err => {
        setClasses([]);
        setClassesError(err.message || "Lỗi khi tải danh sách lớp học");
      })
      .finally(() => setClassesLoading(false));
  }, [selectedFacility, date]);

  // Memoized total pages based on attendance data
  const totalPages = useMemo(() => 
    Math.ceil(attendanceData.length / pageSize) || 1
  , [attendanceData, pageSize]);

  // Reset to first page when data changes
  useEffect(() => {
    setCurrentPage(1);
  }, [attendanceData]);

  // Memoized paginated students
  const paginatedStudents = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return attendanceData.slice(startIndex, endIndex);
  }, [attendanceData, currentPage, pageSize]);

  // Memoized attendance stats
  const attendanceStats = useMemo(() => ({
    present: attendanceData.filter(s => s.status === "PRESENT").length,
    absent: attendanceData.filter(s => s.status === "ABSENT").length,
    late: attendanceData.filter(s => s.status === "LATE").length,
    excused: attendanceData.filter(s => s.status === "EXCUSED").length,
    not_checked: attendanceData.filter(s => s.status === "NOT_CHECKED").length
  }), [attendanceData]);

  // Memoized badge configs for stats
  const badgeConfigs = useMemo(() => ({
    present: attendanceUtils.getStatusBadgeConfig("PRESENT", t),
    absent: attendanceUtils.getStatusBadgeConfig("ABSENT", t),
    late: attendanceUtils.getStatusBadgeConfig("LATE", t),
    excused: attendanceUtils.getStatusBadgeConfig("EXCUSED", t)
  }), [t]);

  // Memoized current class info
  const classInfo = useMemo(() => {
    if (!selectedSession) return null;
    return classes.find(c => c.id === parseInt(selectedSession));
  }, [selectedSession, classes]);



  // Handlers
  const handleSessionSelect = useCallback((sessionId) => {
    setSelectedSession(sessionId);
    setShowAttendanceList(true);
    setSessionInfo(null); // Reset session info when changing class
  }, []);

  const handleMarkPresent = useCallback(async (studentId) => {
    if (!selectedSession || !date) return;
    
    const student = attendanceData.find(s => s.id === studentId);
    if (!student) return;
    
    if (!student.attendance_id) {
      toast.error(t("attendance.error.attendance_not_found"));
      return;
    }
    
    try {
      // Use updateAttendance API with attendance_id
      const result = await attendanceApi.updateAttendance(student.attendance_id, {
        status: ATTENDANCE_STATUSES.PRESENT
      });
      
      if (result.success) {
        toast.success(t("attendance.attendance_success_present", { name: student.student_full_name }));
        // Reload attendance data from API to get latest information
        await fetchAttendanceData();
      } else {
        toast.error(result.error || "Lỗi khi cập nhật điểm danh");
      }
    } catch (error) {
      console.error('Error updating attendance:', error);
      toast.error("Lỗi khi cập nhật điểm danh");
    }
  }, [attendanceData, selectedSession, date, selectedFacility, t, fetchAttendanceData]);

  const handleMarkAbsent = useCallback((studentId) => {
    const student = attendanceData.find(s => s.id === studentId);
    if (student) {
      setSelectedStudent(student);
      setAbsenceDialogOpen(true);
    }
  }, [attendanceData]);

  const handleConfirmAbsence = useCallback(async (studentId, reason, hasReason, reasonDetail) => {
    if (!selectedSession || !date) return;
    
    const student = attendanceData.find(s => s.id === studentId);
    if (!student) return;
    
    if (!student.attendance_id) {
      toast.error(t("attendance.error.attendance_not_found"));
      return;
    }
    
    try {
      // Prepare note based on reason
      let note = null;
      if (hasReason) {
        if (reason === "other") {
          note = reasonDetail;
        } else {
          note = t(`attendance.reasons.${reason}`);
        }
      }
      
      // Use updateAttendance API with attendance_id
      const result = await attendanceApi.updateAttendance(student.attendance_id, {
        status: hasReason ? "EXCUSED" : "ABSENT",
        note: note
      });
      
      if (result.success) {
        if (hasReason) {
          toast.warning(t("attendance.attendance_success_excused", { 
            name: student.student_full_name
          }));
        } else {
          showErrorToast(t("attendance.attendance_success_absent", { 
            name: student.student_full_name 
          }));
          toast.error(t("attendance.attendance_success_absent", { 
            name: student.student_full_name 
          }));
        }
        // Reload attendance data from API to get latest information
        await fetchAttendanceData();
      } else {
        toast.error(result.error || "Lỗi khi cập nhật điểm danh");
      }
    } catch (error) {
      console.error('Error updating attendance:', error);
      toast.error("Lỗi khi cập nhật điểm danh");
    }
    
    setAbsenceDialogOpen(false);
    setSelectedStudent(null);
  }, [attendanceData, selectedSession, date, selectedFacility, t, fetchAttendanceData]);

  const handleEditAttendance = useCallback((studentId) => {
    const student = attendanceData.find(s => s.id === studentId);
    if (student) {
      setSelectedStudent(student);
      setEditDialogOpen(true);
      
      if (detailDialogOpen) {
        setDetailDialogOpen(false);
      }
    }
  }, [attendanceData, detailDialogOpen]);

  const handleUpdateAttendance = useCallback(async (studentId, newStatus, reason, reasonDetail) => {
    // API call is now handled in EditAttendanceDialog
    // Just refresh the attendance data to get the latest state
    if (selectedSession && date) {
      await fetchAttendanceData();
    }
  }, [selectedSession, date, fetchAttendanceData]);

  const handleAttendanceInfo = useCallback((studentId) => {
    const student = attendanceData.find(s => s.id === studentId);
    if (student) {
      setSelectedStudent(student);
      setDetailDialogOpen(true);
    }
  }, [attendanceData]);

  // Helper function for status badges (using service)
  const getStatusBadge = useCallback((status) => {
    const config = attendanceUtils.getStatusBadgeConfig(status, t);
    return <Badge className={config.className}>{config.text}</Badge>;
  }, [t]);

  // Render session badge with appropriate color (using service)
  const renderSessionBadge = useCallback((sessionObj) => {
    const config = attendanceUtils.getSessionBadgeConfig(sessionObj);
    return (
      <div className={config.className}>
        {config.code}
      </div>
    );
  }, []);

  // Render loading skeleton for student rows
  const renderSkeletonRows = () => {
    return Array(5).fill(0).map((_, index) => (
      <TableRow key={`skeleton-${index}`} className="hover:bg-[#F8FAFC] border-b border-[#E2E8F0] last:border-0">
        <TableCell className="px-6 py-4">
          <div className="flex items-center gap-3">
            <Skeleton className="h-8 w-8 rounded-lg" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-20" />
            </div>
          </div>
        </TableCell>
        <TableCell className="px-6 py-4">
          <Skeleton className="h-4 w-24" />
        </TableCell>
        <TableCell className="px-6 py-4 text-center">
          <div className="flex justify-center -space-x-1">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-8 w-8 rounded-full" />
            ))}
          </div>
        </TableCell>
        <TableCell className="px-6 py-4 text-center">
          <Skeleton className="h-6 w-24 mx-auto" />
        </TableCell>
        <TableCell className="px-6 py-4">
          <div className="flex justify-center items-center gap-3">
            <Skeleton className="h-10 w-10 rounded" />
            <Skeleton className="h-10 w-10 rounded" />
          </div>
        </TableCell>
      </TableRow>
    ));
  };

  return (
    <MainLayout>
      <PageContainer
        title={t("attendance.attendance")}
        description={t("attendance.attendance_description")}
      >
        <div className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4">
                      {/* Date Picker */}
          <div className="w-[250px]">
            <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal bg-white border-[#E4E4E7] h-9"
                >
                  <CalendarIcon className="mr-2 h-4 w-4 text-[#64748B]" />
                  {date ? format(date, "dd/MM/yyyy") : <span>{t("attendance.pick_a_date")}</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={(selectedDate) => {
                    if (selectedDate) {
                      setDate(selectedDate);
                      setDatePickerOpen(false); // Close the popover after selection
                    }
                  }}
                  initialFocus
                  disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                />
              </PopoverContent>
            </Popover>
          </div>

            {/* Facility Select */}
            <div className="w-[250px]">
              <Select value={selectedFacility} onValueChange={setSelectedFacility}>
                <SelectTrigger className="h-9 bg-white border-[#E4E4E7]">
                  <SelectValue placeholder={t("attendance.select_facility")} />
                </SelectTrigger>
                <SelectContent>
                  {facilities.map((facility) => (
                    <SelectItem key={facility.id} value={String(facility.id)}>
                      {facility.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Class Select */}
            <div className="w-[250px]">
              <Select 
                value={selectedSession} 
                onValueChange={handleSessionSelect} 
                disabled={!selectedFacility || !date}
              >
                <SelectTrigger className="h-9 bg-white border-[#E4E4E7]">
                  <SelectValue placeholder={t("attendance.select_class")} />
                </SelectTrigger>
                <SelectContent>
                  {classesLoading ? (
                    <div className="px-4 py-2 text-sm text-gray-400">{t("loading", "Đang tải...")}</div>
                  ) : classesError ? (
                    <div className="px-4 py-2 text-sm text-red-500">{classesError}</div>
                  ) : classes.length === 0 ? (
                    <div className="px-4 py-2 text-sm text-gray-400">{t("no_data", "Không có dữ liệu")}</div>
                  ) : (
                    classes.map((classItem) => (
                      <SelectItem key={classItem.id} value={classItem.id}>
                        {classItem.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Attendance Section */}
          <div className="bg-white rounded-lg">
            {!showAttendanceList ? (
              <div className="flex items-center justify-center border border-[#E2E8F0] rounded-lg">
                <EmptyState
                  className="w-full"
                  title={t("attendance.no_class_selected")}
                  subtitle={t("attendance.select_class_info_to_start_attendance")}
                  noBorder={true}
                />
              </div>
            ) : (
              <>
                {/* Header with session info and stats */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[#020617] font-semibold text-lg">
                          {classInfo?.name}
                        </span>
                        <span className="text-[#71717A]">-</span>
                        <span className="text-[#71717A] font-medium text-lg">
                          {sessionInfo?.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-[#64748B]">
                        <Clock className="w-4 h-4" />
                        <span>
                          {formatTimeHHMM(sessionInfo?.start_time)} - {formatTimeHHMM(sessionInfo?.end_time)}
                        </span>
                      </div>
                    </div>
                    {!isLoading && (
                    <div className="flex gap-2 flex-wrap">
                      <Badge className={badgeConfigs.present.className}>
                        {badgeConfigs.present.text}: {attendanceStats.present}
                      </Badge>
                      <Badge className={badgeConfigs.absent.className}>
                        {badgeConfigs.absent.text}: {attendanceStats.absent}
                      </Badge>
                      <Badge className={badgeConfigs.late.className}>
                        {badgeConfigs.late.text}: {attendanceStats.late}
                      </Badge>
                      <Badge className={badgeConfigs.excused.className}>
                        {badgeConfigs.excused.text}: {attendanceStats.excused}
                      </Badge>
                    </div>
                    )}
                    {isLoading && (
                      <div className="flex gap-2 flex-wrap">
                        <Skeleton className="h-6 w-24" />
                        <Skeleton className="h-6 w-32" />
                        <Skeleton className="h-6 w-28" />
                      </div>
                    )}
                  </div>

                  {/* Search and Filter */}
                  <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center gap-2">
                      <div className="relative w-[600px]">
                        <Input 
                          placeholder={t("student.search_student_placeholder", "Search by name, email, or phone number")}
                          value={searchQuery}
                          onChange={(e) => {
                            const value = e.target.value;
                            setSearchQuery(value);
                            debouncedSearch(value);
                          }}
                          className="pl-10"
                          disabled={isLoading}
                        />
                        {isSearching ? (
                          <Loader2 className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#64748B] w-4 h-4 animate-spin" />
                        ) : (
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#64748B] w-4 h-4" />
                        )}
                      </div>
                      <Button variant="outline" disabled={isLoading}>{t("common.search")}</Button>
                    </div>
                  </div>
                  
                </div>

                {/* Alert for unchecked students */}
                {!isLoading && attendanceStats.not_checked > 0 && (
                  <div className="flex items-center gap-2 p-3 bg-[#FFFCF0] border border-[#DC7609] rounded-md text-[#020617] mb-4">
                    <AlertCircle className="w-4 h-4 text-[#DC7609]" />
                    <span>
                      {t("attendance.students_not_checked", { 
                        count: attendanceStats.not_checked, 
                        total: attendanceData.length 
                      })}
                    </span>
                  </div>
                )}

                {/* Alert for attendance loading error */}
                {attendanceError && (
                  <div className="flex items-center gap-2 p-3 bg-[#FFF0F0] border border-[#E60000] rounded-md text-[#020617] mb-4">
                    <AlertCircle className="w-4 h-4 text-[#E60000]" />
                    <span>{attendanceError}</span>
                  </div>
                )}

                {/* Students Table */}
                <div className="w-full overflow-x-auto">
                  <div className="w-full border border-[#E2E8F0] rounded-xl bg-white overflow-hidden min-w-full">
                    <Table className="flex-1">
                      <TableHeader className="bg-[#F8F8F8] border-b border-[#E2E8F0]">
                        <TableRow className="hover:bg-transparent">
                          <TableHead className="w-[300px] font-medium text-[13px] text-[#64748B] px-6 py-3 whitespace-nowrap">{t("student.student_name")}</TableHead>
                          <TableHead className="w-[150px] font-medium text-[13px] text-[#64748B] px-6 py-3 whitespace-nowrap">{t("personal.phone")}</TableHead>
                          <TableHead className="w-[180px] font-medium text-[13px] text-center text-[#64748B] px-6 py-3 whitespace-nowrap">{t("attendance.attended_sessions")}</TableHead>
                          <TableHead className="w-[150px] font-medium text-[13px] text-center text-[#64748B] px-6 py-3 whitespace-nowrap">{t("common.status")}</TableHead>
                          <TableHead className="w-[120px] font-medium text-[13px] text-center text-[#64748B] px-6 py-3 whitespace-nowrap">{t("attendance.actions")}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoading ? (
                          renderSkeletonRows()
                        ) : paginatedStudents.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-8 text-sm text-[#64748B]">
                              {t("common.no_data")}
                            </TableCell>
                          </TableRow>
                        ) : (
                          paginatedStudents.map((student) => (
                            <TableRow key={student.id} className="hover:bg-[#F8FAFC] border-b border-[#E2E8F0] last:border-0">
                              <TableCell className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                  <Avatar className="h-8 w-8 rounded-lg">
                                    <AvatarImage src={student.avatar} alt={student.student_full_name} />
                                    <AvatarFallback className="rounded-lg bg-muted text-muted-foreground">
                                      {getInitials(student.student_full_name)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <div className="text-[#0973DC] font-medium">{student.student_full_name}</div>
                                    <div className="text-[#64748B] text-xs font-medium">{student.student_code}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="px-6 py-4 text-[#020617] whitespace-nowrap">
                                {student.student_phone_number}
                              </TableCell>
                              <TableCell className="px-6 py-4 text-center whitespace-nowrap">
                                <div className="flex justify-center -space-x-1">
                                  {student.sessions && student.sessions.length > 0 ? (
                                    student.sessions.slice(0,5).map(session => (
                                      <div key={session.id} className="flex flex-col items-center">
                                        {renderSessionBadge(session)}
                                      </div>
                                    ))
                                  ) : (
                                    <span className="text-[#64748B] text-xs">-</span>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell className="px-6 py-4 text-center whitespace-nowrap">
                                {getStatusBadge(student.status)}
                              </TableCell>
                              <TableCell className="px-6 py-4 whitespace-nowrap">
                                <div className="flex justify-center items-center gap-3">
                                  {student.status === ATTENDANCE_STATUSES.NOT_CHECKED ? (
                                    <>
                                      <Button 
                                        size="icon" 
                                        variant="outline" 
                                        className="w-10 h-10 p-2.5"
                                        onClick={() => handleMarkAbsent(student.id)}
                                      >
                                        <X className="w-5 h-5" />
                                      </Button>
                                      <Button 
                                        size="icon" 
                                        className="w-10 h-10 p-2.5 bg-brand hover:bg-brand-hover"
                                        onClick={() => handleMarkPresent(student.id)}
                                      >
                                        <Check className="w-5 h-5 text-white" />
                                      </Button>
                                    </>
                                  ) : (
                                    <>
                                      <Button 
                                        size="icon" 
                                        variant="outline" 
                                        className="w-10 h-10 p-2.5"
                                        onClick={() => handleEditAttendance(student.id)}
                                      >
                                        <Pencil className="w-5 h-5" />
                                      </Button>
                                      <Button 
                                        size="icon" 
                                        variant="outline" 
                                        className="w-10 h-10 p-2.5"
                                        onClick={() => handleAttendanceInfo(student.id)}
                                      >
                                        <Info className="w-5 h-5" />
                                      </Button>
                                    </>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                {/* Pagination */}
                {!isLoading && (
                <div className="p-4">
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                  />
                </div>
                )}
                
                {/* Loading indicator for the whole section */}
                {isLoading && (
                  <div className="flex justify-center items-center p-4">
                    <Loader2 className="w-6 h-6 text-[#E67364] animate-spin" />
                    <span className="ml-2 text-[#71717A]">{t("student.loading_students", "Loading students...")}</span>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </PageContainer>

      {/* Dialogs */}
      <AbsenceDialog
        open={absenceDialogOpen}
        onOpenChange={setAbsenceDialogOpen}
        student={selectedStudent}
        classInfo={classInfo}
        currentDate={date}
        onConfirm={handleConfirmAbsence}
      />

      <AttendanceDetailDialog
        open={detailDialogOpen}
        onOpenChange={setDetailDialogOpen}
        student={selectedStudent}
        onEdit={handleEditAttendance}
      />

      <EditAttendanceDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        student={selectedStudent}
        currentStatus={selectedStudent?.status}
        attendanceId={selectedStudent?.attendance_id}
        onConfirm={handleUpdateAttendance}
      />
    </MainLayout>
  );
} 