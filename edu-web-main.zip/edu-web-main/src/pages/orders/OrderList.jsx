import React, { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { useTranslation } from "react-i18next";
import { useToast } from '@/components/ui/use-toast';
import { MasterListLayout } from '@/components/layout/master-list-layout';
import { orderApi, OrderStatus, PaymentStatus } from '@/api/services/order';
import ErrorBoundary from '@/components/ErrorBoundary';
import { format } from 'date-fns';

const SEARCH_MIN_CHARS = 1;
const SEARCH_DEBOUNCE_MS = 400;


// Wrap the actual component implementation to prevent re-renders
function OrderListContent() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [orders, setOrders] = useState([]);
  const [totalOrders, setTotalOrders] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchInput, setSearchInput] = useState("");
  
  // Use ref instead of state for timeout to avoid dependency issues
  const searchTimeoutRef = useRef(null);
  
  // Use this ref to prevent infinite rendering loops
  const renderCount = useRef(0);

  useBreadcrumb(t("order_list", "Danh sách đơn hàng"), "/orders");

  // Debounced search
  useEffect(() => {
    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
    searchTimeoutRef.current = setTimeout(() => {
      setSearchTerm(searchInput);
      setCurrentPage(1);
    }, SEARCH_DEBOUNCE_MS);
    
    return () => {
      if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
    };
  }, [searchInput]); // Remove searchTimeout from dependencies

  // Safety mechanism to prevent infinite renders
  useEffect(() => {
    renderCount.current += 1;
    if (renderCount.current > 25) {
      console.warn("OrderList: Too many renders detected, preventing further updates");
      return;
    }
    
    let ignore = false;
    async function fetchOrders() {
      setLoading(true);
      setError(null);
      try {
        const params = {
          page: currentPage,
          pagesize: pageSize,
          keyword: searchTerm.length >= SEARCH_MIN_CHARS ? searchTerm : undefined,
        };
        const result = await orderApi.getOrders(params);
        if (!ignore) {
          if (result.success) {
            setOrders(result.data?.items || []);
            setTotalOrders(result.data?.total || 0);
          } else {
            setOrders([]);
            setTotalOrders(0);
            setError(result.error || t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'));
            toast({
              variant: "destructive",
              title: t('error', 'Lỗi'),
              description: result.error || t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'),
            });
          }
        }
      } catch {
        if (!ignore) {
          setOrders([]);
          setTotalOrders(0);
          setError(t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'));
          toast({
            variant: "destructive",
            title: t('error', 'Lỗi'),
            description: t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'),
          });
        }
      } finally {
        if (!ignore) setLoading(false);
      }
    }
    fetchOrders();
    return () => { ignore = true; };
  }, [currentPage, pageSize, searchTerm, t, toast]);

  const totalPages = Math.ceil(totalOrders / pageSize);

  // Use useCallback for stable function references
  const handlePageChange = useCallback((page) => {
    setCurrentPage(page);
  }, []);

  const handleViewDetail = useCallback((orderId) => {
    navigate(`/orders/${orderId}`);
  }, [navigate]);

  const handleEmptyAction = useCallback(() => {
    navigate('/enrollment/register');
  }, [navigate]);

  // Format currency - make it stable
  const formatCurrency = useCallback((amount) => {
    return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
  }, []);

  // Format date to dd/MM/yyyy HH:mm
  const formatDateTime = useCallback((dateString) => {
    if (!dateString) return '';
    try {
      let date;
      if (dateString.includes('T')) {
        if (!dateString.endsWith('Z') && !dateString.includes('+') && !dateString.includes('-', 10)) {
          date = new Date(dateString + 'Z');
        } else {
          date = new Date(dateString);
        }
      } else {
        date = new Date(dateString);
      }
      if (isNaN(date.getTime())) return dateString;
      return format(date, 'dd/MM/yyyy HH:mm');
    } catch {
      return dateString;
    }
  }, []);

  // Badge helpers - make them stable with useCallback
  const getOrderStatusBadge = useCallback((status) => {
    switch ((status || '').toUpperCase()) {
      case OrderStatus.CONFIRMED:
        return <Badge variant="outline" className="bg-[#ECFDF2] border-none text-[#008A2E] font-semibold">{t('order.order_status_confirmed', 'Đã xác nhận')}</Badge>;
      case OrderStatus.PENDING:
        return <Badge variant="outline" className="bg-[#F0F8FF] border-none text-[#0973DC] font-semibold">{t('order.order_status_pending', 'Chờ xác nhận')}</Badge>;
      case OrderStatus.CANCELLED:
        return <Badge variant="outline" className="bg-[#F1F5F9] border-none text-[#71717A] font-semibold">{t('order.order_status_cancelled', 'Đã huỷ')}</Badge>;
      default:
        return <Badge>{(status || '').toUpperCase()}</Badge>;
    }
  }, [t]);
  
  const getPaymentStatusBadge = useCallback((status) => {
    switch ((status || '').toUpperCase()) {
      case PaymentStatus.PAID:
        return <Badge variant="outline" className="bg-[#ECFDF2] border-none text-[#008A2E] font-semibold">{t('order.payment_status_paid', 'Đã thanh toán')}</Badge>;
      case PaymentStatus.PARTIAL:
        return <Badge variant="outline" className="bg-[#FFFCF0] border-none text-[#DC7609] font-semibold">{t('order.payment_status_partial', 'Thanh toán 1 phần')}</Badge>;
      case PaymentStatus.UNPAID:
        return <Badge variant="outline" className="bg-[#F0F8FF] border-none text-[#0973DC] font-semibold">{t('order.payment_status_unpaid', 'Chờ thanh toán')}</Badge>;
      default:
        return <Badge>{(status || '').toUpperCase()}</Badge>;
    }
  }, [t]);

  // Define table columns - memoize with stable cellRenderer functions
  const columns = React.useMemo(() => [
    {
      key: 'order_code',
      header: t('order_code', 'Mã đơn hàng'),
      width: '120px',
      skeletonWidth: 'w-[80px]'
    },
    {
      key: 'created_at',
      header: t('created_at', 'Thời gian tạo'),
      width: '150px',
      skeletonWidth: 'w-[120px]',
      cellRenderer: (order) => formatDateTime(order.created_at),
    },
    {
      key: 'buyer_name',
      header: t('buyer_name', 'Tên khách hàng'),
      width: '200px',
      skeletonWidth: 'w-[150px]'
    },
    {
      key: 'final_amount',
      header: t('total_amount', 'Tổng tiền'),
      width: '150px',
      cellRenderer: (order) => formatCurrency(order.final_amount),
      skeletonWidth: 'w-[100px]'
    },
    {
      key: 'status',
      header: t('order_status', 'Trạng thái đơn'),
      width: '140px',
      cellRenderer: (order) => getOrderStatusBadge(order.status),
      skeletonRenderer: () => <Badge variant="outline" className="bg-gray-100 border-none">Loading...</Badge>
    },
    {
      key: 'payment_status',
      header: t('payment_status', 'Thanh toán'),
      width: '140px',
      cellRenderer: (order) => getPaymentStatusBadge(order.payment_status),
      skeletonRenderer: () => <Badge variant="outline" className="bg-gray-100 border-none">Loading...</Badge>
    },
    {
      key: 'actions',
      header: '',
      width: '100px',
      align: 'right',
      cellRenderer: (order) => (
        <Button
          variant="link"
          className="text-brand hover:text-brand/90 p-0 h-auto text-[14px] font-medium"
          onClick={() => handleViewDetail(order.id)}
        >
          {t('common.detail', 'Chi tiết')}
        </Button>
      ),
      skeletonWidth: 'w-[60px]'
    }
  ], [t, formatCurrency, getOrderStatusBadge, getPaymentStatusBadge, handleViewDetail, formatDateTime]); // Include stable function dependencies

  return (
    <MasterListLayout
      title={t("order_list", "Danh sách đơn hàng")}
      searchPlaceholder={t('search_order_placeholder', 'Tìm theo mã đơn hàng')}
      searchValue={searchInput}
      onSearchChange={setSearchInput}
      columns={columns}
      data={orders}
      loading={loading}
      error={error}
      currentPage={currentPage}
      totalPages={totalPages}
      onPageChange={handlePageChange}
      totalItems={totalOrders}
      itemsLabel={t('total_orders', 'hoá đơn')}
      emptyTitle={t('order_empty_title', 'Chưa có đơn hàng nào')}
      emptySubtitle={t('order_empty_subtitle', 'Khi có đơn hàng, chúng sẽ xuất hiện tại đây.')}
      emptyButtonText={t('create_order', 'Tạo đơn hàng')}
      onEmptyAction={handleEmptyAction}
      emptyButtonIcon={<Plus className="w-4 h-4" />}
      showAddButton={false}
    />
  );
}

// Main exported component wrapped with ErrorBoundary
export default function OrderList() {
  return (
    <ErrorBoundary>
      <OrderListContent />
    </ErrorBoundary>
  );
}