import React, { useEffect, useState } from "react";
import MainLayout from "../../components/layout/main-layout";
import { PageContainer } from "@/components/page-container";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDateTime, formatDateDMY, formatCurrency } from "@/lib/utils";
import { PlaceholderText } from "@/components/ui/placeholder-text";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { useTranslation } from "react-i18next";
import { InfoCard } from "@/components/ui/info-card";
import { Tag, BadgeCheck, User, Package, Mail, Phone, MapPin, ChevronDown } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CreateReceiptDialog } from "../transactions/CreateReceiptDialog";
import { useParams } from "react-router-dom";
import { orderApi, OrderStatus, PaymentStatus } from '@/api/services/order';
import { memoApi } from '@/api/services/memo';
import { Pagination } from '@/components/ui/pagination';
import { showSuccessToast, showErrorToast } from '@/utils/toast';
import { DataTable } from "@/components/ui/data-table";

export default function OrderDetail() {
  const { t } = useTranslation();
  const { id } = useParams();
  const [tab, setTab] = useState("info");
  const [receiptDialogOpen, setReceiptDialogOpen] = useState(false);
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState(null);
  const [historyPage, setHistoryPage] = useState(1);
  const [historyTotal, setHistoryTotal] = useState(0);
  const HISTORY_PAGE_SIZE = 10;

  // Set breadcrumbs
  useBreadcrumb(t("order_list", "Danh sách đơn hàng"), "/orders");
  useBreadcrumb(t("order_detail", "Chi tiết đơn hàng"));

  useEffect(() => {
    let ignore = false;
    async function fetchOrder() {
      setLoading(true);
      setError(null);
      const result = await orderApi.getOrderDetail(id);
      if (!ignore) {
        if (result.success) {
          setOrder(result.data);
        } else {
          setOrder(null);
          setError(result.error || t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'));
        }
        setLoading(false);
      }
    }
    if (id) fetchOrder();
    return () => { ignore = true; };
  }, [id, t]);

  // Fetch memos when tab is 'history' and order.id is available
  useEffect(() => {
    if (tab === 'history' && order?.id) {
      let ignore = false;
      async function fetchHistory() {
        setHistoryLoading(true);
        setHistoryError(null);
        const result = await memoApi.getMemos({
          ref_type: 'ORDER',
          ref_id: order.id,
          page: historyPage,
          page_size: HISTORY_PAGE_SIZE,
        });
        if (!ignore) {
          if (result.success) {
            setHistory(result.data?.items || []);
            setHistoryTotal(result.data?.total || 0);
          } else {
            setHistory([]);
            setHistoryTotal(0);
            setHistoryError(result.error || t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'));
          }
          setHistoryLoading(false);
        }
      }
      fetchHistory();
      return () => { ignore = true; };
    }
  }, [tab, order?.id, historyPage, t]);

  // Handler for confirming the order
  const handleConfirmOrder = async () => {
    if (!order?.id) return;
    const result = await orderApi.confirmOrder(order.id);
    if (result.success) {
      showSuccessToast(t('order.confirm_success', 'Xác nhận đơn hàng thành công'));
      // Refresh order detail
      const refreshed = await orderApi.getOrderDetail(order.id);
      if (refreshed.success) setOrder(refreshed.data);
    } else {
      showErrorToast(t('order.confirm_error', 'Có lỗi khi xác nhận đơn hàng'), result.error);
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <PageContainer>
          <Skeleton className="h-10 w-1/3 mb-4" />
          <Skeleton className="h-96 w-full" />
        </PageContainer>
      </MainLayout>
    );
  }

  if (error) {
    return (
      <MainLayout>
        <PageContainer>
          <div className="text-red-500 font-semibold text-center py-10">{error}</div>
        </PageContainer>
      </MainLayout>
    );
  }

  if (!order) return null;

  // Tính tổng số lượng sản phẩm trong đơn hàng
  const totalQuantity = order.order_items?.reduce((sum, item) => sum + (Number(item.quantity) || 1), 0);

  // Prepare product data with index for DataTable
  const productData = order.order_items.map((item, idx) => ({ ...item, index: idx + 1 }));

  // Product table columns for DataTable
  const productColumns = [
    {
      key: 'index',
      header: t('registration.stt', 'STT'),
      width: '50px',
      cellRenderer: (item) => item.index,
      align: 'center',
      skeletonWidth: 'w-[30px]'
    },
    {
      key: 'item_name',
      header: t('product.product_name', 'Sản phẩm'),
      width: 'auto',
      cellRenderer: (item) => (
        <div className="flex flex-col justify-center">
          <span className="text-sm font-medium text-[#0973DC]">{item.item_name}</span>
          {item.item_type && (
            <span className="text-xs text-[#71717A] mt-1">{item.item_type}</span>
          )}
        </div>
      ),
      skeletonWidth: 'w-[120px]'
    },
    {
      key: 'quantity',
      header: t('quantity', 'Số lượng'),
      width: '100px',
      align: 'center',
      cellRenderer: (item) => item.quantity,
      skeletonWidth: 'w-[60px]'
    },
    {
      key: 'item_price',
      header: t('finance.price', 'Giá tiền'),
      width: '120px',
      cellRenderer: (item) => (
        <div className="flex flex-col justify-center">
          <span className="text-sm">{formatCurrency(item.item_price)}</span>
          {Number(item.final_discount) > 0 && (
            <span className="text-xs text-[#16A34A]">
              (-{formatCurrency(item.final_discount)})
            </span>
          )}
        </div>
      ),
      skeletonWidth: 'w-[80px]'
    },
    {
      key: 'final_price',
      header: t('common.total', 'Thành tiền'),
      width: '120px',
      cellRenderer: (item) => (
        <span className="text-sm font-medium">{formatCurrency(item.final_price)}</span>
      ),
      skeletonWidth: 'w-[80px]'
    }
  ];

  return (
    <MainLayout>
      <PageContainer>  
        {/* Header: Order code, status, created date, actions */}
        <div className="flex justify-between w-full">
          {/* Left column: Order code, status badges, and date */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3">
              <span className="text-lg font-semibold text-[#020617]">
                {t("order_code", "Mã đơn hàng")}: <span className="font-semibold">{order.order_code}</span>
              </span>
              <Badge
                variant="outline"
                className={
                  order.status === OrderStatus.CONFIRMED
                    ? "bg-[#ECFDF2] border-none text-[#008A2E] font-semibold"
                    : order.status === OrderStatus.PENDING
                    ? "bg-[#F0F8FF] border-none text-[#0973DC] font-semibold"
                    : order.status === OrderStatus.CANCELLED
                    ? "bg-[#F1F5F9] border-none text-[#71717A] font-semibold"
                    : "font-semibold"
                }
              >
                {t(`order.order_status_${order.status?.toLowerCase()}`, order.status)}
              </Badge>
              <Badge variant="outline" className="bg-[#F0F8FF] border-none text-[#0973DC] font-semibold text-xs h-6 px-2.5">
                {t(`order.payment_status_${order.payment_status?.toLowerCase()}`, order.payment_status)}
              </Badge>
            </div>
            <div className="text-sm text-[#71717A]">
              {t("order_created_at", "Đặt hàng ngày")} {formatDateDMY(order.created_at)}
            </div>
          </div>
          
          {/* Right column: Action buttons */}
          <div className="flex gap-3">
            {order.status === OrderStatus.PENDING && (
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center border border-[#E5E5E5] rounded-md px-4 py-2 h-9 text-[#0A0A0A] text-sm font-medium">
                  {t("order.actions", "Actions")}
                  <ChevronDown className="ml-2 h-4 w-4" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={handleConfirmOrder}>{t("order.action_confirm", "Confirm order")}</DropdownMenuItem>
                  <DropdownMenuItem>{t("order.action_cancel", "Cancel order")}</DropdownMenuItem>
                  <DropdownMenuItem>{t("order.action_print", "Print order")}</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
            {order.status === OrderStatus.CONFIRMED && order.payment_status !== PaymentStatus.PAID && (
              <Button 
                className="bg-[#E67364] hover:bg-[#E67364]/90 text-white h-9 px-4"
                onClick={() => setReceiptDialogOpen(true)}
              >
                {t("order.action_pay", "Pay")}
              </Button>
            )}
          </div>
        </div>

        {/* Tabs: Info, History */}
        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="bg-[#F8FAFC] p-1 h-auto rounded-lg mb-4 border border-[#E2E8F0]">
            <TabsTrigger value="info" className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md">
              {t("tab_info", "Thông tin")}
            </TabsTrigger>
            <TabsTrigger value="history" className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md">
              {t("tab_order_history", "Lịch sử đơn hàng")}
            </TabsTrigger>
          </TabsList>

          {/* Tab: Info */}
          <TabsContent value="info" className="w-full flex flex-col lg:flex-row gap-6">
            {/* Left: Product list, Payment summary */}
            <div className="flex-1 flex flex-col gap-6">
              {/* Product List */}
              <div className="w-full border border-[#E2E8F0] rounded-xl bg-white overflow-hidden p-4">
                <h3 className="text-base font-medium text-[#18181B] mb-4">
                  {t("product.product_list", "Danh sách sản phẩm")}
                </h3>
                <DataTable
                  columns={productColumns}
                  data={productData}
                  loading={false}
                  className="mt-4"
                  emptyTitle={t('no_data', 'Không có dữ liệu')}
                />
              </div>

              {/* Payment Summary */}
              <div className="rounded-xl border border-[#E2E8F0] bg-white p-4 flex flex-col">
                <div className="flex items-center gap-2 mb-4">
                  <h3 className="text-base font-medium text-[#18181B]">
                    {t("payment", "Thanh toán")}
                  </h3>
                  <Badge variant="outline" className="bg-[#F0F8FF] border-none text-[#0973DC] font-semibold text-xs">
                    {t("payment_status_unpaid", "Chờ thanh toán")}
                  </Badge>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#71717A]">{t("subtotal", "Tạm tính")} ({totalQuantity} {t('product.prduct_name', 'sản phẩm')})</span>
                    <span className="text-sm">{formatCurrency(order.total_amount)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#71717A]">{t("promotion", "Ưu đãi")}</span>
                    <span className="text-sm text-[#16A34A]">-{formatCurrency(order.final_discount)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#71717A]">{t("custom_discount", "Giảm giá tuỳ chỉnh")}</span>
                    <span className="text-sm text-[#16A34A]">
                      {order.discount_type
                        ? (order.discount_type === 'PERCENT'
                            ? `-${order.discount_value}%`
                            : `-${formatCurrency(order.discount_value)}`)
                        : `-0${t('finance.short_currency', 'đ')}`}
                    </span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm font-semibold text-[#09090B]">{t("common.total", "TỔNG TIỀN")}</span>
                    <span className="text-sm font-semibold text-[#09090B]">{formatCurrency(order.final_amount)}</span>
                  </div>
                </div>
                <div className="border-t border-[#E2E8F0] my-4" />
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-normal text-[#09090B]">{t("need_to_pay", "Khách cần trả")}</span>
                    <span className="text-sm">{formatCurrency(order.final_amount)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-normal text-[#09090B]">{t("paid", "Khách đã trả")}</span>
                    <span className="text-sm">{formatCurrency(order.paid_amount)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Customer & creator info */}
            <div className="w-full lg:w-[350px] flex flex-col gap-6">
              {/* Order Confirmation */}
              <div className="rounded-xl border border-[#E2E8F0] bg-white p-4 flex flex-col gap-4">
                <h3 className="text-base font-semibold text-[#18181B]">
                  {t("order_confirmation", "Xác nhận đơn hàng")}
                </h3>
                <div className="flex flex-col gap-2">
                  {order.status !== OrderStatus.PENDING ? (
                    <>
                      <div className="flex items-center gap-2">
                        <User size={16} className="text-[#09090B]" />
                        <span className="text-sm font-medium text-[#0973DC]">{order.confirmed_by_full_name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <BadgeCheck size={16} className="text-[#09090B]" />
                        <span className="text-sm text-[#09090B]">{t("confirmed_at", "Xác nhận vào lúc")} {formatDateTime(order.confirmed_at)}</span>
                      </div>
                    </>
                  ) : (
                    <span className="text-sm text-[#F04438] font-medium">{t('order.not_confirmed', 'Chưa xác nhận')}</span>
                  )}
                </div>
              </div>
              
              {/* Customer Info - Updated to match Figma design */}
              <div className="rounded-xl border border-[#E2E8F0] bg-white p-4 flex flex-col gap-4">
                {/* Customer Name & Order Count */}
                <div className="flex flex-col gap-4">
                  <h3 className="text-base font-semibold text-[#18181B]">
                      {t("customer", "Khách hàng")}
                  </h3>
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <User size={16} className="text-[#09090B]" />
                      <span className="text-sm font-medium text-[#0973DC]">{order.buyer_name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Package size={16} className="text-[#09090B]" />
                      <span className="text-sm text-[#09090B]">{t("ordered_count", "Đã đặt:")}{' '}
                        <span className="font-medium">{order.order_count} {t("orders", "đơn hàng")}</span>
                      </span>
                    </div>
                  </div>
                </div>
                
                <Separator className="bg-[#E2E8F0]" />
                
                {/* Contact Information */}
                <div className="flex flex-col gap-3">
                  <h3 className="text-base font-semibold text-[#18181B]">
                    {t("personal.contact_info", "Thông tin liên hệ")}
                  </h3>
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-2">
                      <Mail size={16} className="text-[#09090B] shrink-0" />
                      <span className="text-sm text-[#09090B]">{order.buyer_email || '-'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone size={16} className="text-[#09090B] shrink-0" />
                      <span className="text-sm text-[#09090B]">{order.buyer_phone || '-'}</span>
                    </div>
                    <div className="flex gap-2">
                      <MapPin size={16} className="text-[#09090B] shrink-0 mt-[3px]" />
                      <span className="text-sm text-[#09090B]">{order.buyer_address || '-'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Creator Information - Added as separate box based on Figma design */}
              <div className="rounded-xl border border-[#E2E8F0] bg-white p-4 flex flex-col gap-4">
                <h3 className="text-base font-semibold text-[#18181B]">
                  {t("creator", "Người tạo")}
                </h3>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <User size={16} className="text-[#09090B]" />
                    <span className="text-sm font-medium text-[#0973DC]">{order.created_by_full_name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag size={16} className="text-[#09090B]" />
                    <span className="text-sm text-[#09090B]">
                      {t("created_at", "Đã tạo vào lúc")} {formatDateTime(order.created_at)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Tab: Order History */}
          <TabsContent value="history" className="w-full">
            <div className="w-full border border-[#E2E8F0] rounded-xl bg-white overflow-hidden">
              {/* Table Header */}
              <div className="bg-[#F8F8F8] flex border-b border-[#E2E8F0]">
                <div className="py-3 px-4 text-[#64748B] font-medium text-sm w-[150px]">
                  {t('time', "Thời gian")}
                </div>
                <div className="py-3 px-4 text-[#64748B] font-medium text-sm w-[200px]">
                  {t('operator', "Người thao tác")}
                </div>
                <div className="py-3 px-4 text-[#64748B] font-medium text-sm w-[150px]">
                  {t('function', "Chức năng")}
                </div>
                <div className="py-3 px-4 text-[#64748B] font-medium text-sm flex-1">
                  {t('content', "Nội dung")}
                </div>
              </div>
              {/* Table Body */}
              <div className="flex flex-col min-h-[120px]">
                {historyLoading ? (
                  <div className="flex justify-center items-center py-8 w-full">
                    <span className="text-gray-400 text-sm">{t('loading', 'Đang tải...')}</span>
                  </div>
                ) : historyError ? (
                  <div className="flex justify-center items-center py-8 w-full">
                    <span className="text-red-500 text-sm">{historyError}</span>
                  </div>
                ) : history.length === 0 ? (
                  <div className="flex justify-center items-center py-8 w-full">
                    <span className="text-gray-400 text-sm">{t('no_data', 'Không có dữ liệu')}</span>
                  </div>
                ) : (
                  history.map((memo) => (
                    <div key={memo.id} className="flex border-b border-[#E2E8F0] last:border-b-0">
                      <div className="py-4 px-4 w-[150px]">
                        <span className="text-sm text-[#020617]">{formatDateTime(memo.created_at)}</span>
                      </div>
                      <div className="py-4 px-4 w-[200px]">
                        <span className="text-sm font-medium text-[#0973DC]">{memo.created_by_full_name || '-'}</span>
                      </div>
                      <div className="py-4 px-4 w-[150px]">
                        <span className="text-sm text-[#020617]">{memo.title || '-'}</span>
                      </div>
                      <div className="py-4 px-4 flex-1">
                        <span className="text-sm text-[#020617]">{memo.content || '-'}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
              {historyTotal > HISTORY_PAGE_SIZE && (
                <Pagination
                  currentPage={historyPage}
                  totalPages={Math.ceil(historyTotal / HISTORY_PAGE_SIZE)}
                  onPageChange={setHistoryPage}
                  className="p-4"
                />
              )}
            </div>
          </TabsContent>
        </Tabs>
        
        {/* Create Order Payment Dialog */}
        <CreateReceiptDialog 
          open={receiptDialogOpen} 
          onOpenChange={setReceiptDialogOpen}
          order={order}
          onSuccess={(receiptData) => {
            console.log("Receipt created:", receiptData);
            // Refresh order data to update payment status
            if (order?.id) {
              orderApi.getOrderDetail(order.id).then(result => {
                if (result.success) {
                  setOrder(result.data);
                }
              });
            }
          }}
        />
      </PageContainer>
    </MainLayout>
  );
} 