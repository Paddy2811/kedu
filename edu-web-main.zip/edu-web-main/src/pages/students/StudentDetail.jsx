import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import MainLayout from "../../components/layout/main-layout";
import { Button } from "../../components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../../components/ui/tabs";
import { PencilLine, Copy, CheckCircle, CircleUser, NotebookTabs, NotepadText, Building2, Users2, BookText, UserRound } from "lucide-react";
import { Skeleton } from "../../components/ui/skeleton";
import { studentApi } from "../../api";
import { Pagination } from "../../components/ui/pagination";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { PageContainer } from "@/components/page-container";
import { PlaceholderText } from "@/components/ui/placeholder-text";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { useTranslation } from "react-i18next";
import { formatDateDMY } from "@/lib/utils";
import { getFullAddress } from "@/utils/address";
import { InfoCard } from "@/components/ui/info-card";

// import { getInitials } from "@/lib/utils";

// Helper function to get class status display text
const getClassStatusText = (status) => {
  switch (status) {
    case 'ACTIVE':
      return 'Đang diễn ra';
    case 'PENDING':
      return 'Chờ khai giảng';
    case 'COMPLETED':
      return 'Đã kết thúc';
    case 'CANCELLED':
      return 'Đã hủy';
    default:
      return status;
  }
};

export default function StudentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("classes");
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [student, setStudent] = useState(null);
  const [enrolledClasses, setEnrolledClasses] = useState([]);
  const [classesLoading, setClassesLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalClasses, setTotalClasses] = useState(0);
  const itemsPerPage = 10;

  const { t } = useTranslation();

  useEffect(() => {
    async function fetchStudentDetail() {
      try {
        setIsLoading(true);
        const result = await studentApi.getStudentById(id);
        if (result.success) {
          setStudent(result.data);
        } else {
          throw new Error(result.error || t('errors.generic'));
        }
      } catch (err) {
        setStudent(null);
        showErrorToast(err.message || t('errors.generic'));
      } finally {
        setIsLoading(false);
      }
    }
    fetchStudentDetail();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    async function fetchEnrolledClasses() {
      if (!id) return;
      
      try {
        setClassesLoading(true);
        const result = await studentApi.getEnrolledClasses(id, {
          page: currentPage,
          pagesize: itemsPerPage
        });
        
        if (result.success) {
          setEnrolledClasses(result.data.items);
          setTotalPages(result.data.totalPages);
          setTotalClasses(result.data.total);
        } else {
          showErrorToast(result.error || t('errors.load_class_list'));
        }
      } catch (err) {
        showErrorToast(err.message || t('errors.load_class_list'));
      } finally {
        setClassesLoading(false);
      }
    }
    
    fetchEnrolledClasses();
  }, [id, currentPage, itemsPerPage, t]);

  const handleCopyToClipboard = async (text, type) => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'phone') {
        setCopiedPhone(true);
        setTimeout(() => setCopiedPhone(false), 2000);
        showSuccessToast(t('success.copy_phone_success'));
      } else if (type === 'email') {
        setCopiedEmail(true);
        setTimeout(() => setCopiedEmail(false), 2000);
        showSuccessToast(t('success.copy_email_success'));
      }
    } catch (error) {
      showErrorToast(t('error.copy_error'));
      console.error('Copy to clipboard error:', error);
    }
  };

  useBreadcrumb("Học viên", "/students");
  useBreadcrumb("Chi tiết học viên");

  return (
    <MainLayout>
      <PageContainer title="Chi tiết học viên">
        <div className="">
          {/* Profile Card */}
          <div className="w-full rounded-xl border border-[#E2E8F0] bg-white mb-4">
            <div className="p-6 flex justify-between">
              {isLoading ? (
                <>
                  <div className="flex items-center gap-3">
                    <Skeleton className="w-10 h-10 rounded-lg" />
                    <div className="flex flex-col gap-2">
                      <Skeleton className="w-32 h-5" />
                      <div className="flex gap-8">
                        <div className="flex flex-col gap-1">
                          <Skeleton className="w-20 h-4" />
                          <Skeleton className="w-16 h-4" />
                        </div>
                        <div className="flex flex-col gap-1">
                          <Skeleton className="w-20 h-4" />
                          <Skeleton className="w-24 h-4" />
                        </div>
                        <div className="flex flex-col gap-1">
                          <Skeleton className="w-20 h-4" />
                          <Skeleton className="w-32 h-4" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <Skeleton className="w-[100px] h-9" />
                </>
              ) : (
                <>
                  <div className="flex gap-5">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                        <UserRound size={24} className="text-muted-foreground"/>
                    </div>
                    <div className="flex flex-col">
                      <h2 className="text-[18px] font-semibold text-[#0F172A] mb-2"><PlaceholderText value={student?.full_name} /></h2>
                      <div className="flex gap-8">
                        <div className="flex flex-col">
                          <span className="text-[13px] text-[#64748B]">{t('personal.student_code')}</span>
                          <PlaceholderText value={student?.user_code} className="text-[13px] text-[#0F172A]" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[13px] text-[#64748B]">{t('personal.phone')}</span>
                          <div className="flex items-center gap-1">
                            <PlaceholderText value={student?.phone_number} className="text-[13px] text-[#0973DC]" />
                            <button 
                              onClick={() => handleCopyToClipboard(student?.phone_number, 'phone')}
                              className="p-0.5 hover:bg-[#F8FAFC] rounded"
                            >
                              {copiedPhone ? (
                                <CheckCircle className="w-3.5 h-3.5 text-[#008A2E]" />
                              ) : (
                                <Copy className="w-3.5 h-3.5 text-[#64748B]" />
                              )}
                            </button>
                          </div>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[13px] text-[#64748B]">{t('personal.email')}</span>
                          <div className="flex items-center gap-1">
                            <PlaceholderText value={student?.email} className="text-[13px] text-[#0973DC]" />
                            <button 
                              onClick={() => handleCopyToClipboard(student?.email, 'email')}
                              className="p-0.5 hover:bg-[#F8FAFC] rounded"
                            >
                              {copiedEmail ? (
                                <CheckCircle className="w-3.5 h-3.5 text-[#008A2E]" />
                              ) : (
                                <Copy className="w-3.5 h-3.5 text-[#64748B]" />
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Button 
                    onClick={() => navigate(`/students/${id}/edit`)}
                    variant="outline" 
                  >
                    <PencilLine className="w-4 h-4 mr-2" />
                    Chỉnh sửa
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="bg-[#F8FAFC] p-1 h-auto rounded-lg mb-4 border border-[#E2E8F0]">
              <TabsTrigger 
                value="classes"
                className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
              >
                {t('class.classes')}
              </TabsTrigger>
              <TabsTrigger 
                value="general"
                className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
              >
                {t('personal.personal_info')}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="classes" className="border border-[#E2E8F0] rounded-xl">
              <div className="p-4">
                {classesLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="w-full h-[120px] rounded-xl" />
                    <Skeleton className="w-full h-[120px] rounded-xl" />
                    <Skeleton className="w-full h-[120px] rounded-xl" />
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between mb-4">
                      <p className="text-[13px] text-[#64748B]">Tổng: {totalClasses} lớp học</p>
                    </div>
                    {enrolledClasses.length > 0 ? (
                      <>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                          {enrolledClasses.map((classItem) => (
                            <InfoCard
                              key={classItem.class_id}
                              title={classItem.class_name}
                              status={{
                                className: "bg-[#F0FDF4] text-[#008A2E] border-transparent",
                                label: getClassStatusText(classItem.class_status)
                              }}
                              infoItems={[
                                {
                                  icon: <Building2 className="w-4 h-4 text-[#64748B]" />,
                                  label: classItem.facility_name
                                },
                                {
                                  icon: <BookText className="w-4 h-4 text-[#64748B]" />,
                                  label: classItem.subject_name
                                },
                                {
                                  icon: <Users2 className="w-4 h-4 text-[#64748B]" />,
                                  label: `${classItem.current_student_count}/${classItem.max_student_count}`
                                }
                              ]}
                              detailLink={`/classes/${classItem.class_id}`}
                              detailText={t('common.detail')}
                              clickable={true}
                            />
                          ))}
                        </div>
                        
                        {totalPages > 1 && (
                          <Pagination
                            currentPage={currentPage}
                            totalPages={totalPages}
                            onPageChange={setCurrentPage}
                            className="px-1"
                          />
                        )}
                      </>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-[#64748B] text-sm">Chưa có lớp học nào được đăng ký</p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </TabsContent>

            <TabsContent value="general">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="w-full h-[120px] rounded-xl" />
                  <Skeleton className="w-full h-[180px] rounded-xl" />
                  <Skeleton className="w-full h-[100px] rounded-xl" />
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Personal Information */}
                  <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
                    <div className="flex items-center gap-2 mb-4">
                      <CircleUser className="w-4 h-4 text-[#0F172A]" />
                      <h3 className="text-[15px] font-medium text-[#0F172A]">{t('personal.personal_info')}</h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      <div>
                        <span className="text-[13px] text-[#64748B]">{t('personal.student_code')}</span>
                        <div className="text-[13px] text-[#0F172A] mt-1">
                            <PlaceholderText value={student?.user_code} />
                        </div>
                      </div>
                      <div>
                        <span className="text-[13px] text-[#64748B]">{t('personal.gender')}</span>
                        <div className="text-[13px] text-[#0F172A] mt-1">
                            <PlaceholderText value={student?.gender ? (student.gender === 'male' ? 'Nam' : 'Nữ') : ''} />
                        </div>
                      </div>
                      <div>
                        <span className="text-[13px] text-[#64748B]">{t('personal.dob')}</span>
                        <div className="text-[13px] text-[#0F172A] mt-1">
                            <PlaceholderText value={formatDateDMY(student?.dob)} />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Contact Information */}
                  <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
                    <div className="flex items-center gap-2 mb-4">
                      <NotebookTabs className="w-4 h-4 text-[#0F172A]" />
                      <h3 className="text-[15px] font-medium text-[#0F172A]">{t('personal.contact_info')}</h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      <div>
                        <span className="text-[13px] text-[#64748B]">{t('personal.phone_student')}</span>
                        <div className="flex items-center gap-1 mt-1">
                            <div className="text-[13px] text-[#0973DC]">
                                <PlaceholderText value={student?.phone_number} />
                            </div>
                          <button 
                            onClick={() => handleCopyToClipboard(student?.phone_number, 'phone')}
                            className="p-0.5 hover:bg-[#F8FAFC] rounded"
                          >
                            {copiedPhone ? (
                              <CheckCircle className="w-3.5 h-3.5 text-[#008A2E]" />
                            ) : (
                              <Copy className="w-3.5 h-3.5 text-[#64748B]" />
                            )}
                          </button>
                        </div>
                      </div>
                      <div>
                        <span className="text-[13px] text-[#64748B]">{t('personal.email')}</span>
                        <div className="flex items-center gap-1 mt-1">
                            <div className="text-[13px] text-[#0973DC]">
                                <PlaceholderText value={student?.email} />
                            </div>
                          <button 
                            onClick={() => handleCopyToClipboard(student?.email, 'email')}
                            className="p-0.5 hover:bg-[#F8FAFC] rounded"
                          >
                            {copiedEmail ? (
                              <CheckCircle className="w-3.5 h-3.5 text-[#008A2E]" />
                            ) : (
                              <Copy className="w-3.5 h-3.5 text-[#64748B]" />
                            )}
                          </button>
                        </div>
                      </div>
                      <div>
                        <span className="text-[13px] text-[#64748B]">{t('personal.emergency_contact')}</span>
                        <div className="text-[13px] text-[#0F172A] mt-1">
                            <PlaceholderText value={student?.emergency_contact ? `${student.emergency_contact}${student?.emergency_relationship ? ` (${student.emergency_relationship})` : ''}` : ''} />
                        </div>
                      </div>
                      <div className="col-span-3">
                        <span className="text-[13px] text-[#64748B]">{t('personal.address')}</span>
                        <div className="text-[13px] text-[#0F172A] mt-1">
                            <PlaceholderText value={getFullAddress(student?.address, student?.city, student?.district, student?.ward)} />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Notes & Comments */}
                  <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
                    <div className="flex items-center gap-2 mb-4">
                      <NotepadText className="w-4 h-4 text-[#0F172A]" />
                      <h3 className="text-[15px] font-medium text-[#0F172A]">{t('personal.notes_comments')}</h3>
                    </div>
                    <div className="flex items-center gap-1 mt-1">
                        <PlaceholderText value={student?.note} />
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </PageContainer>
    </MainLayout>
  );
} 