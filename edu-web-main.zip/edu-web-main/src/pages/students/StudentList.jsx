import React, { useState, useEffect, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { Plus, MoreVertical } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "../../components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../../components/ui/dropdown-menu";
import { showErrorToast, showSuccessToast, TOAST_MESSAGES } from '../../utils/toast';
import { studentApi } from "../../api";
import { useTranslation } from 'react-i18next';
import { MasterListLayout } from '@/components/layout/master-list-layout';

const SEARCH_MIN_CHARS = 1;
const SEARCH_DEBOUNCE_MS = 300;

export default function StudentList() {
  const [students, setStudents] = useState([]);
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [keyword, setKeyword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [totalPages, setTotalPages] = useState(0);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const { t } = useTranslation();

  useBreadcrumb(t('student.student_list'), '/students');

  // Fetch students data
  const fetchStudents = useCallback(async (searchKeyword = '') => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await studentApi.getStudents({
        page: currentPage,
        pagesize: pageSize,
        keyword: searchKeyword,
      });
      
      if (result.success) {
        setStudents(result.data.items || []);
        setTotalItems(result.data.total || 0);
        setTotalPages(Math.ceil((result.data.total || 0) / pageSize));
      } else {
        setError(result.error || TOAST_MESSAGES.LOAD_ERROR);
        setStudents([]);
        setTotalItems(0);
        setTotalPages(0);
      }
    } catch {
      setError(TOAST_MESSAGES.LOAD_ERROR);
      setStudents([]);
      setTotalItems(0);
      setTotalPages(0);
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, pageSize]);

  // Use effect for fetching data with debounce for search
  useEffect(() => {
    const timeout = setTimeout(() => {
      if (keyword.length === 0 || keyword.length >= SEARCH_MIN_CHARS) {
        fetchStudents(keyword);
      }
    }, SEARCH_DEBOUNCE_MS);
    
    return () => clearTimeout(timeout);
  }, [currentPage, pageSize, keyword, fetchStudents]);

  // Handle student deletion
  const handleDeleteStudent = async (studentId) => {
    try {
      const result = await studentApi.deleteStudent(studentId);
      if (result.success) {
        showSuccessToast(t('student_deleted_success', TOAST_MESSAGES.DELETE_SUCCESS));
        fetchStudents(keyword); // Refresh the list
      } else {
        throw new Error(result.error || TOAST_MESSAGES.DELETE_ERROR);
      }
    } catch (error) {
      showErrorToast(t('student_deleted_error', TOAST_MESSAGES.DELETE_ERROR), error);
    }
  };

  // Handle page change
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  // Define columns for DataTable
  const columns = [
    {
      key: 'full_name',
      header: t('student.student'),
      width: '300px',
      cellRenderer: (student) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={student.avatar} alt={student.full_name} />
            <AvatarFallback className="bg-muted text-muted-foreground text-[12px] font-semibold">
              {student.full_name?.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="text-[14px] font-medium text-[#020617]">{student.full_name}</div>
            <div className="text-[12px] font-medium text-[#64748B] mt-0.5">{student.user_code}</div>
          </div>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-gray-200 animate-pulse"></div>
          <div className="space-y-2">
            <div className="h-4 w-[180px] bg-gray-200 rounded animate-pulse"></div>
            <div className="h-3 w-[100px] bg-gray-200 rounded animate-pulse"></div>
          </div>
        </div>
      )
    },
    {
      key: 'phone_number',
      header: t('personal.phone'),
      width: '140px',
      align: 'center',
      cellRenderer: (student) => (
        <span className="text-[14px] text-[#020617]">{student.phone_number}</span>
      ),
      skeletonWidth: 'w-[100px]'
    },
    {
      key: 'email',
      header: t('personal.email'),
      width: '175px',
      cellRenderer: (student) => (
        <span className="text-[14px] text-[#020617]">{student.email}</span>
      ),
      skeletonWidth: 'w-[150px]'
    },
    {
      key: 'total_enrolled_classes',
      header: t('class.classes'),
      width: '120px',
      cellRenderer: (student) => (
        <span className="text-[14px] text-[#020617]">{student.total_enrolled_classes || 0} {t('class.classes').toLowerCase()}</span>
      ),
      skeletonWidth: 'w-[80px]'
    },
    {
      key: 'actions',
      header: '',
      width: '109px',
      align: 'right',
      cellRenderer: (student) => (
        <div className="flex items-center justify-end gap-3">
          <Button
            variant="link"
            className="text-brand hover:text-brand/90 p-0 h-auto font-medium"
            onClick={() => navigate(`/students/${student.user_id}`)}
          >
            {t('common.detail')}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7 hover:bg-[#F8FAFC]">
                <MoreVertical className="h-4 w-4 text-brand" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[160px]">
              <DropdownMenuItem asChild className="py-2 text-[13px] text-[#0F172A] hover:text-brand cursor-pointer">
                <Link to={`/students/${student.user_id}/edit`}>{t('common.edit')}</Link>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="py-2 text-[13px] text-[#0F172A] hover:text-brand cursor-pointer"
                onClick={() => handleDeleteStudent(student.user_id)}
              >
                {t('common.delete')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex items-center justify-end gap-3">
          <div className="h-4 w-[50px] bg-gray-200 rounded animate-pulse"></div>
          <div className="h-7 w-7 bg-gray-200 rounded-md animate-pulse"></div>
        </div>
      )
    }
  ];

  return (
    <MasterListLayout
      title={t("student.student_list", "Danh sách học viên")}
      searchPlaceholder={t('student.search_student_placeholder')}
      searchValue={keyword}
      onSearchChange={(value) => {
        setKeyword(value);
        if (currentPage !== 1) setCurrentPage(1);
      }}
      columns={columns}
      data={students}
      loading={isLoading}
      error={error}
      currentPage={currentPage}
      totalPages={totalPages}
      onPageChange={handlePageChange}
      totalItems={totalItems}
      itemsLabel={t('student.students').toLowerCase()}
      emptyTitle={t('no_students', 'Chưa có học viên nào')}
      emptySubtitle={t('no_students_subtitle', 'Khi có học viên, họ sẽ xuất hiện tại đây.')}
      emptyButtonText={t('common.addNew', 'Thêm mới')}
      onEmptyAction={() => navigate('/students/create')}
      emptyButtonIcon={<Plus className="w-4 h-4" />}
      showAddButton={true}
      addButtonText={t('common.addNew')}
      onAddClick={() => navigate('/students/create')}
    />
  );
}
