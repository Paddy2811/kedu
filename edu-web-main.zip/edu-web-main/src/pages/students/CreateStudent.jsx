import { useState, useEffect } from "react";
import { useNavigate, Link, useParams } from "react-router-dom";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import MainLayout from "../../components/layout/main-layout";
import { ChevronRight } from "lucide-react";
import { provinces, getDistricts, getWards } from "../../data/vietnam-provinces";
import { GENDER_OPTIONS } from "../../data/constants";
import { studentApi } from "../../api/services/student";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { PageContainer } from "@/components/page-container";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { ERROR_MESSAGES } from "@/data/constants";
import { useTranslation } from "react-i18next";
import { Combobox } from "@/components/ui/combobox";
import { DatePicker } from "@/components/ui/date-picker";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export default function CreateStudent() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = Boolean(id);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone_number: "",
    dob: "",
    gender: "",
    city: "",
    district: "",
    ward: "",
    address: "",
    note: "",
  });

  // State for districts and wards based on selected province/district
  const [districts, setDistricts] = useState([]);
  const [wards, setWards] = useState([]);

  const { t } = useTranslation();

  // Fetch student data if editing
  useEffect(() => {
    if (isEditing) {
      const fetchStudentData = async () => {
        setLoading(true);
        try {
          const result = await studentApi.getStudentById(id);
          if (result.success && result.data) {
            const studentData = result.data;
            setFormData({
              full_name: studentData.full_name || "",
              email: studentData.email || "",
              phone_number: studentData.phone_number || "",
              dob: studentData.dob || "",
              gender: studentData.gender || "",
              city: studentData.city || "",
              district: studentData.district || "",
              ward: studentData.ward || "",
              address: studentData.address || "",
              note: studentData.note || "",
            });

            // Set districts and wards if city/district is selected
            if (studentData.city) {
              setDistricts(getDistricts(studentData.city));
              if (studentData.district) {
                setWards(getWards(studentData.city, studentData.district));
              }
            }
          } else {
            showErrorToast(ERROR_MESSAGES.LOAD_STUDENT_ERROR);
            navigate("/students");
          }
        } catch (error) {
          console.error('Error fetching student:', error);
          showErrorToast(ERROR_MESSAGES.LOAD_STUDENT_ERROR);
          navigate("/students");
        } finally {
          setLoading(false);
        }
      };

      fetchStudentData();
    }
  }, [id, isEditing, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Reset dependent fields when province/district changes
    if (name === 'city') {
      setFormData(prev => ({
        ...prev,
        district: '',
        ward: '',
        [name]: value
      }));
      setDistricts(getDistricts(value));
      setWards([]);
    } else if (name === 'district') {
      setFormData(prev => ({
        ...prev,
        ward: '',
        [name]: value
      }));
      setWards(getWards(formData.city, value));
    }

    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: null
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate form data
      const validation = studentApi.validateStudentData(formData);
      if (!validation.isValid) {
        setErrors(validation.errors);
        showErrorToast("Vui lòng điền đầy đủ thông tin bắt buộc");
        setLoading(false);
        return;
      }

      // Prepare data for API
      const studentData = {
        full_name: formData.full_name?.trim(),
        phone_number: formData.phone_number?.trim(),
        email: formData.email?.trim() || null,
        dob: formData.dob || null,
        gender: formData.gender || null,
        city: formData.city || null,
        district: formData.district || null,
        ward: formData.ward || null,
        address: formData.address?.trim() || null,
        note: formData.note?.trim() || null,
      };

      let result;
      if (isEditing) {
        result = await studentApi.updateStudent(id, studentData);
      } else {
        result = await studentApi.createStudent(studentData);
      }
      
      console.log('API response:', result); // Debug log
      
      if (result.success) {
        showSuccessToast(`${isEditing ? "Cập nhật" : "Thêm"} học viên thành công!`);
        navigate(isEditing ? `/students/${id}` : "/students");
      } else {
        console.error('API error:', result.error); // Debug log
        showErrorToast(result.error || `Có lỗi xảy ra khi ${isEditing ? "cập nhật" : "thêm"} học viên`);
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      showErrorToast(`Có lỗi xảy ra khi ${isEditing ? "cập nhật" : "thêm"} học viên`);
    } finally {
      setLoading(false);
    }
  };

  useBreadcrumb("Học viên", "/students");
  useBreadcrumb(isEditing ? "Cập nhật học viên" : "Tạo học viên mới");

  return (
    <MainLayout>
      <PageContainer title={isEditing ? "Cập nhật học viên" : "Tạo học viên mới"}>
        <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-xl text-sm">
          {/* Row 1: Họ và tên, Số điện thoại, Email */}
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label htmlFor="full_name" className="text-sm font-medium text-[#344054]">
                {t('personal.full_name')} <span className="text-brand">*</span>
              </Label>
              <Input
                id="full_name"
                name="full_name"
                placeholder={t('personal.enter_full_name_placeholder')}
                value={formData.full_name}
                onChange={handleInputChange}
                className={`h-9 px-3 py-2 bg-white ${errors.full_name ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FDA29B]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.full_name && (
                <span className="text-sm text-[#F04438]">{errors.full_name}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="phone_number" className="text-sm font-medium text-[#344054]">
                {t('personal.phone_number')} <span className="text-brand">*</span>
              </Label>
              <Input
                id="phone_number"
                name="phone_number"
                placeholder={t('personal.enter_phone_placeholder')}
                value={formData.phone_number}
                onChange={handleInputChange}
                disabled={isEditing}
                className={`h-9 px-3 py-2 ${isEditing ? "bg-[#F5F5F5] text-[#71717A]" : "bg-white"} ${errors.phone_number ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FDA29B]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.phone_number && (
                <span className="text-sm text-[#F04438]">{errors.phone_number}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="email" className="text-sm font-medium text-[#344054]">
                Email
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder={t('personal.enter_email_placeholder')}
                value={formData.email}
                onChange={handleInputChange}
                className={`h-9 px-3 py-2 bg-white ${errors.email ? "border-[#FDA29B] focus:border-[#FDA29B] focus:ring-[#FDA29B]" : "border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"}`}
              />
              {errors.email && (
                <span className="text-sm text-[#F04438]">{errors.email}</span>
              )}
            </div>
          </div>

          {/* Row 2: Ngày sinh, Giới tính */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="dob" className="text-sm font-medium text-[#344054]">
                {t('personal.dob')}
              </Label>
              <DatePicker
                value={formData.dob}
                onChange={(v)=>handleInputChange({target:{name:'dob', value:v}})}
                placeholder={t('personal.select_dob_placeholder')}
                className={`h-9 ${errors.dob ? "border-[#FDA29B]" : "border-[#E4E4E7]"}`}
              />
              {errors.dob && (
                <span className="text-sm text-[#F04438]">{errors.dob}</span>
              )}
            </div>
            <div className="space-y-1">
              <Label htmlFor="gender" className="text-sm font-medium text-[#344054]">
                {t('personal.gender')}
              </Label>
              <Select
                value={formData.gender}
                onValueChange={(v)=>handleInputChange({target:{name:'gender', value:v}})}
              >
                <SelectTrigger className="w-full h-9 px-3 py-2 bg-white border border-[#E4E4E7] text-sm text-[#71717A]">
                  <SelectValue placeholder={t('personal.select_gender_placeholder')} />
                </SelectTrigger>
                <SelectContent className="max-h-60 overflow-y-auto">
                  {GENDER_OPTIONS.map(option => (
                    <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Row 4: Tỉnh/Thành phố, Quận/Huyện, Phường/Xã */}
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#344054]">{t('facility.province')}</Label>
              <Combobox
                options={provinces.map(p => ({ value: p.code, label: p.name }))}
                value={formData.city}
                onChange={(value) => handleInputChange({ target: { name: 'city', value } })}
                placeholder={t('facility.select_province_placeholder')}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#344054]">{t('facility.district')}</Label>
              <Combobox
                options={districts.map(d => ({ value: d.code, label: d.name }))}
                value={formData.district}
                onChange={(value) => handleInputChange({ target: { name: 'district', value } })}
                placeholder={t('facility.select_district_placeholder')}
                disabled={!formData.city}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-medium text-[#344054]">{t('facility.ward')}</Label>
              <Combobox
                options={wards.map(w => ({ value: w.code, label: w.name }))}
                value={formData.ward}
                onChange={(value) => handleInputChange({ target: { name: 'ward', value } })}
                placeholder={t('facility.select_ward_placeholder')}
                disabled={!formData.district}
              />
            </div>
          </div>

          {/* Row 5: Địa chỉ cụ thể */}
          <div className="space-y-1">
            <Label htmlFor="address" className="text-sm font-medium text-[#344054]">
              {t('personal.address_specific')}
            </Label>
            <Input
              id="address"
              name="address"
              placeholder={t('facility.enter_address_placeholder')}
              value={formData.address}
              onChange={handleInputChange}
              className="h-9 px-3 py-2 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"
            />
          </div>

          {/* Row 6: Ghi chú */}
          <div className="space-y-1">
            <Label htmlFor="note" className="text-sm font-medium text-[#344054]">
              {t('common.note')}
            </Label>
            <Textarea
              id="note"
              name="note"
              placeholder={t('common.enter_note_placeholder')}
              value={formData.note}
              onChange={handleInputChange}
              className={`resize-none ${errors.note ? 'border-[#FDA29B] focus-visible:border-[#FDA29B] focus-visible:ring-[#FDA29B]' : ''}`}
            />
            {errors.note && (
              <span className="text-sm text-[#F04438]">{errors.note}</span>
            )}
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(isEditing ? `/students/${id}` : "/students")}
              className="h-9 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB]"
            >
              {t('common.cancel')}
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className={`h-9 px-4 py-2 bg-brand hover:bg-brand/90 text-white font-medium ${
                loading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {loading ? t('common.processing') : (isEditing ? t('common.update') : t('common.create'))}
            </Button>
          </div>
        </form>
      </PageContainer>
    </MainLayout>
  );
}