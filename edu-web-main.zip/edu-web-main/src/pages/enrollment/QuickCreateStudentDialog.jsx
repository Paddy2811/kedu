import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { DatePicker } from "@/components/ui/date-picker";
import { studentApi } from "@/api/services/student";
import { showErrorToast, showSuccessToast } from "@/utils/toast";

export default function QuickCreateStudentDialog({ open, onOpenChange, onSuccess }) {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({
    full_name: "",
    phone_number: "",
    email: "",
    dob: "",
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const handleChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: null }));
  };

  const validate = () => {
    const errs = {};
    if (!formData.full_name.trim()) errs.full_name = t("validation.required_student_name") || "Vui lòng nhập họ và tên";
    if (!formData.phone_number.trim()) {
      errs.phone_number = t("validation.required_student_phone") || "Vui lòng nhập số điện thoại";
    } else if (!/^[0-9]{10,15}$/.test(formData.phone_number.trim())) {
      errs.phone_number = t("errors.invalid_phone") || "Số điện thoại không hợp lệ";
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = t("errors.invalid_email") || "Email không hợp lệ";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await studentApi.createStudent({
        full_name: formData.full_name.trim(),
        phone_number: formData.phone_number.trim(),
        email: formData.email.trim() || undefined,
        dob: formData.dob || undefined,
      });
      if (res.success) {
        showSuccessToast(t("success.createStudent") || "Thêm học viên thành công");
        if (onSuccess) onSuccess(res.data);
        onOpenChange(false);
      } else {
        showErrorToast(res.error || t("errors.create_student") || "Có lỗi xảy ra");
      }
    } catch (err) {
      showErrorToast(t("errors.create_student") || "Có lỗi xảy ra", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={val => { if (!loading) onOpenChange(val); }}>
      <DialogContent className="sm:max-w-[500px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">
            {t("student.create_student") || "Thêm học viên mới"}
          </DialogTitle>
          <DialogDescription>
            {t("student.add_student_prompt") || "Nhập thông tin chi tiết để thêm học viên mới"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 my-4">
          {/* Full name */}
          <div className="space-y-1">
            <Label htmlFor="full_name">
              {t("student.student_name") || "Họ tên học viên"} <span className="text-red-600 ml-1">*</span>
            </Label>
            <Input
              id="full_name"
              value={formData.full_name}
              onChange={e => handleChange("full_name", e.target.value)}
              placeholder={t("student.enter_student_full_name_placeholder") || "Nhập họ tên học viên"}
              className="h-10"
            />
            {errors.full_name && <p className="text-red-500 text-sm">{errors.full_name}</p>}
          </div>

          {/* Phone */}
          <div className="space-y-1">
            <Label htmlFor="phone">
              {t("personal.phone_number") || "Số điện thoại"} <span className="text-red-600 ml-1">*</span>
            </Label>
            <Input
              id="phone"
              value={formData.phone_number}
              onChange={e => handleChange("phone_number", e.target.value)}
              placeholder={t("personal.enter_phone_placeholder") || "Nhập số điện thoại"}
              className="h-10"
            />
            {errors.phone_number && <p className="text-red-500 text-sm">{errors.phone_number}</p>}
          </div>

          {/* Email */}
          <div className="space-y-1">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              value={formData.email}
              onChange={e => handleChange("email", e.target.value)}
              placeholder={t("personal.enter_email_placeholder") || "Nhập email"}
              type="email"
              className="h-10"
            />
            {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
          </div>

          {/* DOB */}
          <div className="space-y-1">
            <Label htmlFor="dob">{t("personal.dob") || "Ngày sinh"}</Label>
            <DatePicker
              value={formData.dob}
              onChange={v => handleChange("dob", v)}
              placeholder={t("personal.select_dob_placeholder") || "Chọn ngày sinh"}
              className="h-10"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            {t("common.cancel") || "Huỷ bỏ"}
          </Button>
          <Button onClick={handleSubmit} disabled={loading} className="bg-[#E67364] hover:bg-[#E67364]/90 text-white">
            {t("common.create") || "Thêm mới"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 