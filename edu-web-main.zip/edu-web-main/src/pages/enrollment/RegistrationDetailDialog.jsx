import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { ChevronDown } from "lucide-react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function RegistrationDetailDialog({
  open,
  onOpenChange,
  classData,
  onSave,
}) {
  const { t } = useTranslation();
  
  // State for form values
  const [tuitionFee, setTuitionFee] = useState(classData?.tuition_fee || 0);
  const [discountType, setDiscountType] = useState("AMOUNT"); // "AMOUNT" or "PERCENT"
  const [discountValue, setDiscountValue] = useState(classData?.discount || 0);
  const [discountReason, setDiscountReason] = useState("");
  
  // Calculate total after discount
  const calculateTotal = () => {
    if (!classData) return 0;
    
    const fee = tuitionFee || 0;
    if (discountType === "AMOUNT") {
      return Math.max(0, fee - discountValue);
    } else {
      // Percentage discount
      const discountAmount = (fee * discountValue) / 100;
      return Math.max(0, fee - discountAmount);
    }
  };
  
  // Reset form when class data changes
  useEffect(() => {
    if (classData) {
      setTuitionFee(classData.tuition_fee || 0);
      setDiscountValue(classData.discount || 0);
      setDiscountReason("");
    }
  }, [classData]);
  
  // Handle discount value change with validation (percentage <= 100)
  const handleDiscountValueChange = (e) => {
    let val = Number(e.target.value);
    if (isNaN(val) || val < 0) val = 0;
    setDiscountValue(val);
  };

  const isPercentageInvalid = discountType === 'PERCENT' && discountValue > 100;
  const isAmountInvalid = discountType === 'AMOUNT' && discountValue > tuitionFee;
  
  // Handle save
  const handleSave = () => {
    if (!classData) return;
    if (isAmountInvalid || isPercentageInvalid) return;
    onSave({
      classId: classData.id,
      discount: discountValue,
      discountType,
      discountValue,
      discountReason,
      totalAfterDiscount: calculateTotal(),
    });
    onOpenChange(false);
  };
  
  // Format number with commas
  const formatNumber = (num) => {
    if (num === null || num === undefined) return "";
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };
  
  if (!classData) return null;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">
            {t('registration_detail') || "Chi tiết đăng ký"}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 my-4">
          {/* Class Information */}
          <div className="space-y-1">
            <Label htmlFor="class">{t('class.class') || "Lớp học"}</Label>
            <div className="flex h-10 w-full rounded-md border border-input bg-[#F3F3F3] px-3 py-2 text-sm ring-offset-background flex items-center">
              <span className="text-[#71717A]">
                {classData.name || classData.code || "Unnamed Class"}
              </span>
            </div>
          </div>
          
          {/* Tuition Fee */}
          <div className="space-y-1">
            <Label htmlFor="tuition-fee">
              {t('finance.tuition_fee') || "Học phí"}
              <span className="text-red-600 ml-1">*</span>
            </Label>
            <InputWithPostfix
              id="tuition-fee"
              name="tuition-fee"
              value={formatNumber(tuitionFee)}
              onChange={(e) => {
                const raw = e.target.value.replace(/[^0-9]/g, "");
                const val = raw === "" ? 0 : Number(raw);
                setTuitionFee(val);
              }}
              postfix="đ"
              className="h-10"
            />
          </div>
          
          {/* Discount Section */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Discount Type */}
            <div className="space-y-1 col-span-1">
              <Label htmlFor="discount-type">
                {t('registration.enrollment.discount') || 'Giảm giá'} <span className="text-red-600">*</span>
              </Label>
              <Select
                value={discountType}
                onValueChange={(val) => {
                  setDiscountType(val);
                  setDiscountValue(0);
                }}
              >
                <SelectTrigger className="w-full h-10">
                  <SelectValue placeholder={t('select_discount_type') || 'Chọn loại giảm giá'}>
                    {discountType === 'AMOUNT'
                      ? t('discount_by_amount') || 'Theo số tiền'
                      : t('discount_by_percentage') || 'Theo phần trăm'}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AMOUNT">{t('discount_by_amount') || 'Theo số tiền'}</SelectItem>
                  <SelectItem value="PERCENT">{t('discount_by_percentage') || 'Theo phần trăm'}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Discount Value */}
            <div className="space-y-1 col-span-2">
              <Label htmlFor="discount-value">
                {t('discount_value') || 'Giá trị'} <span className="text-red-600">*</span>
              </Label>
              <div className="flex items-center gap-2 w-full">
                <InputWithPostfix
                  id="discount-value"
                  name="discount-value"
                  type="text"
                  value={
                    discountType === 'AMOUNT'
                      ? formatNumber(discountValue)
                      : discountValue
                  }
                  onChange={(e) => {
                    if (discountType === 'AMOUNT') {
                      const raw = e.target.value.replace(/[^0-9]/g, '');
                      const val = raw === '' ? 0 : Number(raw);
                      setDiscountValue(val);
                    } else {
                      handleDiscountValueChange(e);
                    }
                  }}
                  postfix={discountType === 'AMOUNT' ? 'đ' : '%'}
                  className="flex-1 h-10"
                />
                {discountType === 'PERCENT' && !isPercentageInvalid && discountValue > 0 && (
                  <span className="flex-1 text-sm text-blue-600 whitespace-nowrap">
                    ~ {formatNumber(Math.round((tuitionFee || 0) * discountValue / 100))} đ
                  </span>
                )}
              </div>
              {isPercentageInvalid && (
                <p className="text-red-500 text-sm mt-1">
                  {t('discount_percentage_exceed_error') || 'Giá trị không được lớn hơn 100%'}
                </p>
              )}
              {isAmountInvalid && (
                <p className="text-red-500 text-sm mt-1">
                  {t('discount_amount_exceed_error') || 'Giá trị giảm giá không được lớn hơn học phí'}
                </p>
              )}
            </div>
          </div>
          
          {/* Discount Reason (optional) */}
          <div className="space-y-1">
            <Label htmlFor="discount-reason">
              {t('discount_reason') || 'Lý do giảm giá'}
            </Label>
            <Input
              id="discount-reason"
              placeholder={t('enter_discount_reason') || 'Nhập lý do giảm giá'}
              value={discountReason}
              onChange={(e) => setDiscountReason(e.target.value)}
              className="text-[#71717A] h-10"
            />
          </div>
        </div>
        
        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="h-10"
          >
            {t('common.cancel') || "Huỷ"}
          </Button>
          <Button 
            onClick={handleSave}
            className="bg-[#E67364] hover:bg-[#E67364]/90 text-white h-10"
            disabled={isPercentageInvalid || isAmountInvalid}
          >
            {t('common.save') || "Lưu"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 