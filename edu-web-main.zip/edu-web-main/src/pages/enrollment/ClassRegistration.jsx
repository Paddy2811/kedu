// ClassRegistration page

import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { ArrowLeft, User, Plus, Users2, X, Trash2, PenSquare, Check, ChevronsUpDown, Info, UserRoundPlus, Loader2 } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";

// Components
import MainLayout from "../../components/layout/main-layout";
import { PageContainer } from "@/components/page-container";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { toast } from "sonner";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Import the RegistrationDetailDialog component
import RegistrationDetailDialog from "./RegistrationDetailDialog";
import QuickCreateStudentDialog from "./QuickCreateStudentDialog";
import OrderDiscountDialog from "./OrderDiscountDialog";

// Hooks and context
import { useBreadcrumb } from "@/contexts/breadcrumb-context";

// API
import { classApi } from "@/api/services/class";
import { studentApi } from "@/api/services/student";
import { orderApi } from '@/api/services/order';

// Helper function to highlight matching text
const HighlightMatch = ({ text = "", searchTerm = "" }) => {
  if (!searchTerm.trim()) return <>{text}</>;
  
  const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
  const parts = text.split(regex);
  
  return (
    <>
      {parts.map((part, i) => 
        regex.test(part) ? 
          <span key={i} className="bg-yellow-100">{part}</span> : 
          <span key={i}>{part}</span>
      )}
    </>
  );
};

// Currency formatting helper
const formatCurrency = (amount) => {
  if (amount === null || amount === undefined) return '0đ';
  return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
};

// Initial page loading indicator (only for first load)
const InitialPageLoader = () => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-white bg-opacity-70">
    <div className="flex flex-col items-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-[#E67364]"></div>
      <span className="mt-4 text-[#E67364] font-medium text-lg">Loading...</span>
    </div>
  </div>
);

// Class selection loading component
const ClassSelectionLoader = () => (
  <div className="flex items-center justify-center py-8">
    <div className="flex flex-col items-center gap-3">
      <Loader2 className="h-6 w-6 animate-spin text-[#E67364]" />
      <span className="text-sm text-[#64748B]">Đang tải danh sách lớp học...</span>
    </div>
  </div>
);

export default function ClassRegistration() {
  const navigate = useNavigate();
  const { t } = useTranslation();

  // States
  const [loadingClasses, setLoadingClasses] = useState(false); // Changed: specific loading for classes
  const [loadingStudents, setLoadingStudents] = useState(true); // Keep for initial load
  const [initialPageLoading, setInitialPageLoading] = useState(true); // New: for initial page load
  const [classes, setClasses] = useState([]);
  const [selectedClasses, setSelectedClasses] = useState([]);
  const [classComboOpen, setClassComboOpen] = useState(false);
  const [classSearchValue, setClassSearchValue] = useState("");
  const [classSearchInput, setClassSearchInput] = useState("");
  const [students, setStudents] = useState([]);
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [selectedStudentId, setSelectedStudentId] = useState("");
  const [orderDiscount, setOrderDiscount] = useState(null); // {discountType, discountValue, discountAmount}
  const [orderDiscountDialogOpen, setOrderDiscountDialogOpen] = useState(false);
  
  // Disable class selection if no student selected
  const isClassSelectionDisabled = selectedStudents.length === 0;
  
  // Registration detail dialog state
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [currentEditingClass, setCurrentEditingClass] = useState(null);
  const [createStudentOpen, setCreateStudentOpen] = useState(false);

  // Calculate total fee based on selected classes
  const calculateTotalFee = useCallback(() => {
    return selectedClasses.reduce((total, cls) => {
      const classFee = cls.tuition_fee || 0;
      return total + classFee;
    }, 0);
  }, [selectedClasses]);

  // Calculate total discount for all selected classes
  const calculateTotalClassDiscount = useCallback(() => {
    return selectedClasses.reduce((total, cls) => {
      let discount = 0;
      if (cls.discountType === 'PERCENT') {
        discount = Math.round((cls.tuition_fee || 0) * (cls.discountValue || 0) / 100);
      } else if (cls.discountType === 'AMOUNT') {
        discount = cls.discountValue || 0;
      } else {
        discount = cls.discount || 0;
      }
      return total + discount;
    }, 0);
  }, [selectedClasses]);

  // Helper to get per-class discount amount
  const getClassDiscountAmount = useCallback((cls) => {
    if (cls.discountType === 'PERCENT') {
      return Math.round((cls.tuition_fee || 0) * (cls.discountValue || 0) / 100);
    } else if (cls.discountType === 'AMOUNT') {
      return cls.discountValue || 0;
    }
    return cls.discount || 0;
  }, []);

  const totalFee = calculateTotalFee();
  const totalClassDiscount = calculateTotalClassDiscount();
  const orderDiscountAmount = orderDiscount?.discountAmount || 0;
  const finalPayable = totalFee - totalClassDiscount - orderDiscountAmount;

  // Breadcrumb setup
  useBreadcrumb(t('registration.register_student'), `/register`);

  // Fetch available classes only after student is selected
  useEffect(() => {
    if (!selectedStudentId) {
      setClasses([]);
      setLoadingClasses(false);
      return;
    }
    setLoadingClasses(true);
    const fetchClasses = async () => {
      try {
        const params = {
          page: 1,
          pagesize: 100,
          student_id: selectedStudentId,
        };
        const res = await classApi.getClassesForRegistration(params);
        if (res.success) {
          // Add a fee property to each class for demonstration
          const classesWithFee = (res.data.items || []).map(cls => ({
            ...cls,
            fee: 200000, // Example fee amount
            discount: 0, // Initialize discount to 0
            // Add enrollment info for demonstration
            enrollment: Math.floor(Math.random() * 12), // Random number of students
            max_students: 12, // Maximum class size
          }));
          setClasses(classesWithFee);
        } else {
          toast.error(res.error || t('errors.load_class_list'));
          setClasses([]);
        }
      } catch (error) {
        console.error(error);
        toast.error(t('errors.load_class_list'));
        setClasses([]);
      } finally {
        setLoadingClasses(false);
      }
    };
    fetchClasses();
  }, [selectedStudentId, t]);

  // Fetch students - initial page load
  useEffect(() => {
    const fetchStudents = async () => {
      setLoadingStudents(true);
      setInitialPageLoading(true); // Set initial loading
      try {
        const params = {
          pagesize: 100, // Get a reasonable number of students for the dropdown
        };
        
        const res = await studentApi.getStudents(params);
        if (res.success) {
          setStudents(res.data.items || []);
        } else {
          toast.error(res.error || t('errors.load_students'));
          setStudents([]);
        }
      } catch (error) {
        console.error('Error fetching students:', error);
        toast.error(t('errors.load_students'));
        setStudents([]);
      } finally {
        setLoadingStudents(false);
        setInitialPageLoading(false); // Clear initial loading
      }
    };

    fetchStudents();
  }, [t]);

  // Check if a class is full
  const isClassFull = useCallback((classItem) => {
    return classItem.enrollment >= classItem.max_students;
  }, []);

  // Handle student selection
  const handleStudentChange = useCallback((value) => {
    const student = students.find(s => (s.user_id ?? s.id)?.toString() === value);
    if (!student) return;

    const idKey = student.user_id ?? student.id;

    // If the selected student is already in the list, do nothing
    if (selectedStudents.length > 0 && (selectedStudents[0].user_id ?? selectedStudents[0].id) === idKey) {
      toast.info(t('student.student_already_selected') || "Student already selected");
      return;
    }

    // Replace any existing student with the newly selected one
    setSelectedStudents([student]);
    setSelectedStudentId(idKey.toString());
  }, [students, selectedStudents, t]);
  
  // Remove selected student
  const removeSelectedStudent = useCallback((studentId) => {
    setSelectedStudents(selectedStudents.filter(s => (s.user_id ?? s.id) !== studentId));
    setSelectedStudentId("");
  }, [selectedStudents]);

  // Handle class selection
  const handleClassChange = useCallback((value) => {
    // Find the selected class
    const selectedClass = classes.find(c => c.id?.toString() === value);
    if (!selectedClass) return;
    
    // Check if class is already selected
    if (selectedClasses.some(c => c.id === selectedClass.id)) {
      toast.info(t('class.class_already_selected') || "Class already selected");
      return;
    }
    
    // Check if class is full
    if (isClassFull(selectedClass)) {
      toast.warning(t('class.class_full') || "Class is full");
      return;
    }
    
    // Add the class to selected classes
    setSelectedClasses([...selectedClasses, selectedClass]);
    
    // Clear the current selection
    setClassSearchValue("");
    setClassSearchInput(""); // Clear search input
    setClassComboOpen(false);
  }, [classes, selectedClasses, isClassFull, t]);
  
  // Remove a class from selected classes
  const removeSelectedClass = useCallback((classId) => {
    setSelectedClasses(selectedClasses.filter(c => c.id !== classId));
  }, [selectedClasses]);
  
  // Open registration detail dialog
  const openRegistrationDetail = useCallback((classItem) => {
    setCurrentEditingClass(classItem);
    setDetailDialogOpen(true);
  }, []);
  
  // Handle saving registration details
  const handleSaveRegistrationDetail = useCallback((details) => {
    if (!details || !details.classId) return;
    // Update the selected class with new discount info
    setSelectedClasses(prevClasses => 
      prevClasses.map(cls => 
        cls.id === details.classId 
          ? { 
              ...cls, 
              discount: details.discount,
              discountType: details.discountType,
              discountValue: details.discountValue,
              discountReason: details.discountReason 
            } 
          : cls
      )
    );
    toast.success(t('success.discount_updated') || "Discount updated successfully");
  }, [t]);

  // Navigate to create student page
  const handleCreateStudent = useCallback(() => {
    setCreateStudentOpen(true);
  }, []);

  // Callback when a new student is created successfully
  const handleStudentCreated = useCallback((student) => {
    if (!student) return;
    setStudents(prev => [...prev, student]);
    setSelectedStudents([student]);
    const idKey = student.user_id ?? student.id;
    setSelectedStudentId(idKey?.toString() || "");
  }, []);

  // Handle registration submit
  const handleSubmit = useCallback(async () => {
    if (selectedClasses.length === 0) {
      toast.warning(t('class.select_class_warning') || "Please select at least one class");
      return;
    }

    if (selectedStudents.length === 0) {
      toast.warning(t('student.select_students_warning') || "Please select at least one student");
      return;
    }

    try {
      // Build order payload
      const buyerId = selectedStudents[0]?.user_id ?? selectedStudents[0]?.id;
      const order_items = selectedClasses.map(cls => ({
        item_type: 'CLASS',
        item_id: cls.id,
        buyer_id: buyerId,
        discount_type: cls.discountType,
        discount_value: cls.discountValue || 0,
        discount_reason: cls.discountReason || '',
      }));
      const orderPayload = {
        buyer_id: buyerId,
        order_items,
        discount_type: orderDiscount?.discountType,
        discount_value: orderDiscount?.discountValue || 0,
        discount_reason: orderDiscount?.discountReason || '',
      };
      const res = await orderApi.createOrder(orderPayload);
      if (!res.success) throw new Error(res.error);

      toast.success(t('success.registration_success', { name: selectedStudents[0].full_name || '' }));
      const student = selectedStudents[0];
      const targetId = (student?.user_id ?? student?.id)?.toString();
      if (targetId) {
        navigate(`/students/${targetId}`);
      }
    } catch (err) {
      toast.error(err.message || t('errors.generic'));
    }
  }, [selectedClasses, selectedStudents, orderDiscount, t, navigate]);

  // Go back to home
  const handleBack = useCallback(() => {
    navigate("/");
  }, [navigate]);

  // Filter classes based on search input
  const filteredClasses = useMemo(() => {
    if (!classSearchInput) return classes;
    
    return classes.filter(classItem => {
      const name = (classItem.name || "").toLowerCase();
      const code = (classItem.code || "").toLowerCase();
      const search = classSearchInput.toLowerCase();
      
      return name.includes(search) || code.includes(search);
    });
  }, [classes, classSearchInput]);

  // Clear search input when popover closes
  useEffect(() => {
    if (!classComboOpen) {
      setClassSearchInput("");
    }
  }, [classComboOpen]);

  // Show initial page loader only on first load
  if (initialPageLoading) {
    return <InitialPageLoader />;
  }

  return (
    <MainLayout>
      <PageContainer
        title={
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8" 
              onClick={handleBack}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <span>{t('registration.register_student')}</span>
          </div>
        }
      >
        {/* Main content - 2 column layout */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left column - Student selection and Class selection */}
          <div className="flex-1 flex flex-col gap-6">
            <Card className="border border-[#E2E8F0] p-6">
              {/* Student Selection Section */}
              <div className="mb-8">
                {selectedStudents.length === 0 ? (
                  <>
                    <h3 className="text-[15px] font-medium text-[#0F172A] mb-4">{t('registration.step_1_select_student', 'Bước 1: Chọn học viên')}</h3>
                    <div className="flex gap-2">
                      <Select 
                        value={selectedStudentId}
                        onValueChange={handleStudentChange}
                        disabled={loadingStudents}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder={t('registration.select_student_placeholder')} />
                        </SelectTrigger>
                        <SelectContent>
                          {students.map((student) => {
                            const idKey = student.user_id ?? student.id;
                            if (!idKey) return null;
                            const isSelected = selectedStudents.some(s => (s.user_id ?? s.id) === idKey);
                            return (
                              <SelectItem 
                                key={idKey} 
                                value={idKey.toString()}
                                disabled={isSelected}
                              >
                                {student.full_name || t('student.unnamed_student', 'Unnamed Student')} - {(student.user_code || student.code || t('registration.no_code', '---'))} - {(student.phone_number || student.phone || t('registration.no_phone', '---'))}
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="px-3"
                          onClick={handleCreateStudent}
                          disabled={loadingStudents}
                        >
                          <UserRoundPlus className="h-4 w-4" />
                          {t('student.create_student')}
                        </Button>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-[15px] font-medium text-[#0F172A]">
                        {t('student.selected_students')}
                      </h3>
                      <Badge variant="outline" className="bg-[#FEF3F2] text-[#F04438] border-none">
                        {selectedStudents.length}
                      </Badge>
                    </div>
                    <div className="space-y-2 max-h-[200px] overflow-y-auto">
                      {selectedStudents.map((student) => {
                        const idKey = student.user_id ?? student.id;
                        return (
                        <div key={idKey} className="flex items-center justify-between p-3 border border-[#E2E8F0] rounded-lg">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8 bg-[#FEF3F2] text-[#F04438]">
                              <AvatarFallback className="bg-[#FEF3F2] text-[#F04438]">
                                {student.full_name?.substring(0, 2) || 'S'}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex flex-col">
                              <span className="font-medium">{student.full_name || t('student.unnamed_student', 'Unnamed Student')}</span>
                              <span className="text-xs text-[#64748B]">
                                {(student.user_code || student.code || t('registration.no_code', '---'))} • {(student.phone_number || student.phone || t('registration.no_phone', '---'))}
                              </span>
                            </div>
                          </div>
                          <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full hover:bg-red-50 hover:text-red-500" onClick={() => removeSelectedStudent(idKey)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      )})}
                    </div>
                  </>
                )}
              </div>

              {/* Class Selection Section */}
              <div>
                <h3 className="text-[15px] font-medium text-[#0F172A] mb-4">{t('registration.step_2_select_class', 'Bước 2: Chọn lớp học')}</h3>
                
                <div className="w-full">
                  <Popover open={classComboOpen} onOpenChange={setClassComboOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={classComboOpen}
                        className="w-full justify-between text-muted-foreground font-normal"
                        disabled={loadingClasses || isClassSelectionDisabled}
                      >
                        {classSearchValue
                          ? classes.find((cls) => cls.id?.toString() === classSearchValue)?.name || classSearchValue
                          : t('class.search_class_placeholder') || "Tìm theo tên hoặc mã lớp học"}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start" sideOffset={4}>
                      <Command>
                        <CommandInput 
                          placeholder={t('class.search_class_placeholder') || "Tìm theo tên hoặc mã lớp học"} 
                          className="h-9"
                          value={classSearchInput}
                          onValueChange={setClassSearchInput}
                        />
                        <CommandEmpty>{t('class.no_classes') || "No classes found"}</CommandEmpty>
                        <CommandGroup className="max-h-[300px] overflow-y-auto">
                          {filteredClasses.map((classItem) => {
                            if (!classItem.id) return null;
                            const isSelected = selectedClasses.some(c => c.id === classItem.id);
                            const isFull = isClassFull(classItem);
                            const isRegistered = !!classItem.is_registered;
                            const isDisabled = isSelected || isFull || isRegistered;
                            
                            return (
                              <CommandItem
                                key={classItem.id}
                                value={classItem.id.toString()}
                                onSelect={handleClassChange}
                                disabled={isDisabled}
                                className={cn(
                                  "flex items-center justify-between py-3",
                                  isDisabled && "opacity-70 cursor-not-allowed bg-gray-50"
                                )}
                              >
                                <div className="flex flex-col">
                                  <div className="flex items-center">
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        classSearchValue === classItem.id.toString() ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    <div>
                                      <span className="font-medium">
                                        <HighlightMatch 
                                          text={classItem.name || t('class.unnamed_class', 'Unnamed Class')} 
                                          searchTerm={classSearchInput}
                                        />
                                      </span>
                                      {classItem.code && (
                                        <span className="ml-2 text-xs text-gray-500">
                                          <HighlightMatch 
                                            text={classItem.code} 
                                            searchTerm={classSearchInput}
                                          />
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                  {isDisabled && (
                                    <div className="flex items-center ml-6 mt-1">
                                      <Info className="h-3.5 w-3.5 text-red-500 mr-1" />
                                      <span className="text-xs text-red-500">
                                        {isRegistered
                                          ? t('class.already_registered', 'Đã đăng ký')
                                          : isSelected
                                            ? t('class.class_already_selected_short') || 'Đã chọn'
                                            : t('class.class_full_short') || 'Lớp học đã đầy'}
                                      </span>
                                    </div>
                                  )}
                                </div>
                                <div className="text-sm text-gray-500">
                                  {classItem.current_student_count}/{classItem.max_student_count}
                                </div>
                              </CommandItem>
                            );
                          })}
                        </CommandGroup>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>
                
                {/* Class selection loading state */}
                {loadingClasses && (
                  <ClassSelectionLoader />
                )}
                
                {/* Selected Classes Table */}
                {!loadingClasses && selectedClasses.length > 0 ? (
                  <div className="mt-4 border border-[#E2E8F0] rounded-lg overflow-hidden">
                    {/* Table Header */}
                    <div className="bg-[#F8F8F8] flex border-b border-[#E2E8F0]">
                      <div className="py-3 px-4 text-[#64748B] font-medium text-sm w-[50px]">
                        {t('registration.stt') || "STT"}
                      </div>
                      <div className="py-3 px-4 text-[#64748B] font-medium text-sm flex-1">
                        {t('class.class_name') || "Tên lớp học"}
                      </div>
                      <div className="py-3 px-4 text-[#64748B] font-medium text-sm w-[120px]">
                        {t('finance.tuition_fee') || "Học phí"}
                      </div>
                      <div className="py-3 px-4 text-[#64748B] font-medium text-sm w-[120px]">
                        {t('finance.total_tuition_fee') || "Thành tiền"}
                      </div>
                      <div className="py-3 px-4 text-[#64748B] font-medium text-sm w-[100px]"></div>
                    </div>
                    
                    {/* Table Body */}
                    {selectedClasses.map((classItem, index) => {
                      const discountAmount = getClassDiscountAmount(classItem);
                      const finalFee = (classItem.tuition_fee || 0) - discountAmount;
                      
                      return (
                        <div key={classItem.id} className="flex border-b border-[#E2E8F0] last:border-b-0">
                          <div className="py-4 px-4 w-[50px] flex items-center justify-end">
                            <span className="text-sm font-medium">{index + 1}</span>
                          </div>
                          <div className="py-4 px-4 flex-1 flex items-center">
                            <span className="text-sm font-medium">{classItem.name || classItem.code || t('class.unnamed_class', 'Unnamed Class')}</span>
                          </div>
                          <div className="py-4 px-4 w-[120px] flex flex-col justify-center">
                            <div className="text-sm">{formatCurrency(classItem.tuition_fee)}</div>
                            {(() => {
                              if (discountAmount > 0) {
                                if (classItem.discountType === 'PERCENT') {
                                  return (
                                    <div className="text-xs text-[#16A34A]">
                                      (-{formatCurrency(discountAmount)}{classItem.discountValue ? `, ${classItem.discountValue}%` : ''})
                                    </div>
                                  );
                                } else {
                                  return (
                                    <div className="text-xs text-[#16A34A]">
                                      (-{formatCurrency(discountAmount)})
                                    </div>
                                  );
                                }
                              }
                              return null;
                            })()}
                          </div>
                          <div className="py-4 px-4 w-[120px] flex items-center">
                            <span className="text-sm font-medium">{formatCurrency(finalFee)}</span>
                          </div>
                          <div className="py-4 px-2 w-[100px] flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-9 w-9 rounded-md"
                              onClick={() => openRegistrationDetail(classItem)}
                            >
                              <PenSquare className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-9 w-9 rounded-md"
                              onClick={() => removeSelectedClass(classItem.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : !loadingClasses && (
                  <div className="mt-4">
                    <EmptyState
                      title={t('class.no_class_selected') || 'Bạn chưa chọn lớp học nào'}
                      subtitle={t('class.select_class_prompt') || 'Chọn lớp học ngay để đăng ký học viên vào lớp'}
                    />
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Right column - Registration info */}
          <div className="w-full lg:w-[350px] flex-shrink-0">
            <Card className="border border-[#E2E8F0]">
              <div className="p-4">
                <h3 className="text-[16px] font-semibold text-[#18181B] mb-4">
                  {t('registration.enrollment.registration_info') || "Thông tin đăng ký"}
                </h3>
                
                {/* Fee summary */}
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#71717A]">{t('registration.enrollment.temporary_fee') || "Tạm tính"} ({selectedClasses.length} {t('class.classes') || "khoá học"})</span>
                    <span className="text-sm font-normal">{formatCurrency(totalFee)}</span>
                  </div>
                  {/* Total class discount row */}
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#71717A]">{t('registration.enrollment.discount') || "Khuyến mại lớp học"}</span>
                    <span className="text-sm font-normal text-[#008A2E]">-{formatCurrency(totalClassDiscount)}</span>
                  </div>
                  {/* Custom order discount row (optional) */}
                  {orderDiscount && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-[#71717A]">{t('registration.enrollment.custom_discount') || 'Giảm giá tuỳ chỉnh'}</span>
                      <span className="text-sm font-normal text-[#008A2E]">
                        -{formatCurrency(orderDiscountAmount)}{orderDiscount.discountType === 'PERCENT' ? ` (${orderDiscount.discountValue}%)` : ''}
                      </span>
                    </div>
                  )}
                </div>
                
                {/* Add / Edit discount button */}
                <Button 
                  variant="ghost" 
                  className="w-full flex items-center justify-center gap-2 border border-dashed border-[#E4E4E7] text-sm text-[#2563EB] mb-6 py-2 h-auto"
                  onClick={() => setOrderDiscountDialogOpen(true)}
                  disabled={loadingClasses || selectedClasses.length === 0}
                >
                  {orderDiscount ? (
                    <PenSquare className="w-4 h-4" />
                  ) : (
                    <Plus className="w-4 h-4" />
                  )}
                  {orderDiscount ? (t('registration.enrollment.edit_discount_order') || 'Điều chỉnh khuyến mại') : (t('registration.enrollment.add_discount_order') || 'Thêm khuyến mại')}
                </Button>
                
                {/* Total */}
                <div className="flex justify-between items-center pt-4 border-t border-[#E2E8F0]">
                  <span className="text-sm font-semibold uppercase">{t('finance.total_tuition_fee') || "TỔNG HỌC PHÍ"}</span>
                  <span className="text-base font-semibold text-[#E67364]">{formatCurrency(finalPayable)}</span>
                </div>
                
                {/* Submit button */}
                <Button
                  className="w-full mt-4 bg-[#E67364] hover:bg-[#E67364]/90 text-white font-semibold"
                  disabled={!selectedClasses.length || selectedStudents.length === 0 || loadingClasses}
                  onClick={handleSubmit}
                >
                  {t('registration.confirm_registration') || "Xác nhận đăng ký"}
                </Button>
              </div>
            </Card>
          </div>
        </div>
        
        {/* Quick Create Student Dialog */}
        <QuickCreateStudentDialog
          open={createStudentOpen}
          onOpenChange={setCreateStudentOpen}
          onSuccess={handleStudentCreated}
        />

        {/* Registration Detail Dialog */}
        <RegistrationDetailDialog
          open={detailDialogOpen}
          onOpenChange={setDetailDialogOpen}
          classData={currentEditingClass}
          onSave={handleSaveRegistrationDetail}
        />

        {/* Order Discount Dialog */}
        <OrderDiscountDialog
          open={orderDiscountDialogOpen}
          onOpenChange={setOrderDiscountDialogOpen}
          baseAmount={totalFee}
          initialData={orderDiscount}
          onSave={(data) => setOrderDiscount(data)}
        />
      </PageContainer>
    </MainLayout>
  );
}
