import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import { PrefilledInput } from "@/components/ui/prefilled-input";

export default function OrderDiscountDialog({ open, onOpenChange, baseAmount = 0, initialData = null, onSave }) {
  const { t } = useTranslation();

  const [discountType, setDiscountType] = useState(initialData?.discountType || "AMOUNT");
  const [discountValue, setDiscountValue] = useState(initialData?.discountValue || 0);
  const [discountReason, setDiscountReason] = useState(initialData?.discountReason || "");

  const isPercentage = discountType === "PERCENT";
  const invalidPercentage = isPercentage && discountValue > 100;
  const invalidAmount = !isPercentage && discountValue > baseAmount;

  const getDiscountAmount = () => {
    if (isPercentage) return Math.round((baseAmount * discountValue) / 100);
    return discountValue;
  };

  const handleSave = () => {
    if (invalidPercentage || invalidAmount) return;
    onSave({
      discountType,
      discountValue,
      discountAmount: getDiscountAmount(),
      discountReason,
    });
    onOpenChange(false);
  };

  const formatNumber = (num) => {
    if (num === null || num === undefined) return "";
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  return (
    <Dialog open={open} onOpenChange={val => { onOpenChange(val); }}>
      <DialogContent className="sm:max-w-[600px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">
            {t("registration.order_discount")}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 my-4">
          {/* Base amount */}
          <div className="space-y-1">
            <Label>{t("registration.enrollment.temporary_fee")}</Label>
            <PrefilledInput 
              value={formatNumber(baseAmount)} 
              postfix="đ" 
            />
          </div>

          {/* Discount type & value (1:2 column ratio) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1 col-span-1">
              <Label>{t("registration.enrollment.discount")}</Label>
              <Select value={discountType} onValueChange={(val) => {
                setDiscountType(val);
                setDiscountValue(0);
              }}>
                <SelectTrigger className="w-full h-10 focus:ring-1 focus:ring-brand focus:border-brand">
                  <SelectValue>
                    {discountType === 'AMOUNT'
                      ? t('discount.discount_by_amount')
                      : t('discount.discount_by_percentage')}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AMOUNT">{t("discount.discount_by_amount")}</SelectItem>
                  <SelectItem value="PERCENT">{t("discount.discount_by_percentage")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1 col-span-2">
              <Label>{t("discount.discount_value")}</Label>
              <div className="flex items-center gap-2 w-full">
                <InputWithPostfix
                  type="text"
                  value={isPercentage ? discountValue : formatNumber(discountValue)}
                  postfix={isPercentage ? "%" : "đ"}
                  className="h-10 flex-1"
                  onChange={(e) => {
                    let raw = e.target.value.replace(/[^0-9]/g, "");
                    const val = raw === "" ? 0 : Number(raw);
                    setDiscountValue(val);
                  }}
                />
                {isPercentage && !invalidPercentage && discountValue > 0 && (
                  <span className="text-sm text-blue-600 whitespace-nowrap">~ {formatNumber(getDiscountAmount())} đ</span>
                )}
              </div>
              {invalidPercentage && (
                <p className="text-sm text-red-500 mt-1">
                  {t("discount.discount_percentage_exceed_error")}
                </p>
              )}
              {invalidAmount && (
                <p className="text-sm text-red-500 mt-1">
                  {t('discount.discount_amount_exceed_error')}
                </p>
              )}
            </div>
          </div>

          {/* Discount Reason */}
          <div className="space-y-1">
            <Label htmlFor="discount-reason">
              {t('discount.discount_reason')}
            </Label>
            <Input
              id="discount-reason"
              placeholder={t('discount.enter_discount_reason')}
              value={discountReason}
              onChange={(e) => setDiscountReason(e.target.value)}
              className="text-[#71717A] h-10"
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)} 
            className="h-10 px-8"
          >
            {t("common.cancel")}
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={invalidPercentage || invalidAmount} 
            className="bg-[#E67364] hover:bg-[#E67364]/90 text-white h-10 px-8"
          >
            {t("common.save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 