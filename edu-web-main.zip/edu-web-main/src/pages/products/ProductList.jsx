import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { useTranslation } from "react-i18next";
import { useToast } from '@/components/ui/use-toast';
import { MasterListLayout } from '@/components/layout/master-list-layout';

const SEARCH_MIN_CHARS = 1;
const SEARCH_DEBOUNCE_MS = 400;

export default function ProductList() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [products, setProducts] = useState([]);
  const [totalProducts, setTotalProducts] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useBreadcrumb(t("product.product_list", "Danh sách sản phẩm"), "/products");

  // Mock data for development/demo
  const MOCK_PRODUCTS = useMemo(() => [
    {
      id: 1,
      name: 'Khóa học Toán cho lớp 12',
      code: 'TOAN12',
      type: 'course',
      price: 2000000,
      thumbnail: '/images/logo.png'
    },
    {
      id: 2,
      name: 'Khóa học Tiếng Anh cho lớp 10',
      code: 'ANH10',
      type: 'course',
      price: 1800000,
      thumbnail: '/images/logo.png'
    },
    {
      id: 3,
      name: 'Khóa học Vật Lý cho lớp 11',
      code: 'LY11',
      type: 'course',
      price: 1500000,
      thumbnail: '/images/logo.png'
    },
    {
      id: 4,
      name: 'Khóa học Hóa học cho lớp 12',
      code: 'HOA12',
      type: 'course',
      price: 1700000,
      thumbnail: '/images/logo.png'
    },
    {
      id: 5,
      name: 'Khóa học Văn học cho lớp 9',
      code: 'VAN9',
      type: 'course',
      price: 1600000,
      thumbnail: '/images/logo.png'
    },
  ], []);

  // Always use mock data for now (API not implemented)
  useEffect(() => {
    try {
      setLoading(true);
      setProducts(MOCK_PRODUCTS);
      setTotalProducts(MOCK_PRODUCTS.length);
      setError(null);
    } catch (err) {
      console.error("Error loading products:", err);
      setError(t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'));
      toast({
        variant: "destructive",
        title: t('error', 'Lỗi'),
        description: t('errors.generic', 'Đã xảy ra lỗi khi tải dữ liệu'),
      });
    } finally {
      setLoading(false);
    }
  }, [MOCK_PRODUCTS, t, toast]);

  // Use mock data if API returns no data (for development/demo)
  useEffect(() => {
    if (!loading && products.length === 0 && !error) {
      setProducts(MOCK_PRODUCTS);
      setTotalProducts(MOCK_PRODUCTS.length);
    }
  }, [loading, products, error, MOCK_PRODUCTS]);

  const totalPages = Math.ceil(totalProducts / pageSize);

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleViewDetail = (productId) => {
    navigate(`/products/${productId}`);
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
  };

  // Define table columns
  const columns = [
    {
      key: 'name',
      header: t('product.product_name', 'Tên sản phẩm'),
      cellRenderer: (product) => (
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-md bg-gray-100 overflow-hidden">
            <img 
              src={product.thumbnail || '/images/logo.png'} 
              alt={product.name}
              className="h-full w-full object-cover"
            />
          </div>
          <div>
            <div className="font-medium text-[#18181B]">{product.name}</div>
            <div className="text-xs text-[#71717A]">{product.code}</div>
          </div>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-md bg-gray-200 animate-pulse"></div>
          <div className="space-y-1">
            <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-3 w-16 bg-gray-200 rounded animate-pulse"></div>
          </div>
        </div>
      )
    },
    {
      key: 'type',
      header: t('product.product_type', 'Loại sản phẩm'),
      width: '200px',
      cellRenderer: (product) => (
        <span className="capitalize">{t(`product_type_${product.type}`, product.type)}</span>
      )
    },
    {
      key: 'sessions',
      header: t('sessions', 'Số buổi'),
      width: '100px',
      cellRenderer: () => "16"
    },
    {
      key: 'price',
      header: t('finance.price', 'Giá tiền'),
      width: '150px',
      cellRenderer: (product) => formatCurrency(product.price)
    },
    {
      key: 'actions',
      header: '',
      width: '100px',
      align: 'right',
      cellRenderer: (product) => (
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleViewDetail(product.id)}
          className="text-[#18181B] border-[#E2E8F0] hover:bg-[#F8FAFC] hover:text-[#18181B] hover:border-[#E2E8F0]"
        >
          {t('common.detail', 'Chi tiết')}
        </Button>
      ),
      skeletonWidth: 'w-[80px]'
    }
  ];

  return (
    <MasterListLayout
      title={t("product.product_list", "Danh sách sản phẩm")}
      searchPlaceholder={t('product.search_product_placeholder', 'Tìm kiếm sản phẩm')}
      searchValue={searchTerm}
      onSearchChange={(value) => {
        setSearchTerm(value);
        setCurrentPage(1);
      }}
      columns={columns}
      data={products}
      loading={loading}
      error={error}
      currentPage={currentPage}
      totalPages={totalPages}
      onPageChange={handlePageChange}
      totalItems={totalProducts}
      itemsLabel={t('product.total_products', 'sản phẩm')}
      emptyTitle={t('product_empty_title', 'Chưa có sản phẩm nào')}
      emptySubtitle={t('product_empty_subtitle', 'Khi có sản phẩm, chúng sẽ xuất hiện tại đây.')}
      emptyButtonText={t('product.create_product', 'Tạo sản phẩm')}
      onEmptyAction={() => navigate('/products/create')}
      emptyButtonIcon={<Plus className="w-4 h-4" />}
      showAddButton={true}
      addButtonText={t('product.create_product', 'Tạo sản phẩm')}
      onAddClick={() => navigate('/products/create')}
    />
  );
} 