import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import MainLayout from "@/components/layout/main-layout";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { PageContainer } from "@/components/page-container";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { productApi } from "@/api";
import { useTranslation } from "react-i18next";

export default function CreateNewProduct() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    type: "",
    group: "",
    price: "",
    description: ""
  });

  useBreadcrumb(t("product.create_new_product", "Thêm mới sản phẩm"), "/products/create", [
    { text: t("common.home", "Trang chủ"), href: "/" },
    { text: t("product.product_list", "Danh sách sản phẩm"), href: "/products" },
    { text: t("product.create_new_product", "Thêm mới sản phẩm"), href: "/products/create" }
  ]);

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = t('validation.required_product_name', 'Trường này là bắt buộc');
    }

    if (!formData.type) {
      newErrors.type = t('validation.required_product_type', 'Trường này là bắt buộc');
    }

    if (!formData.group) {
      newErrors.group = t('validation.required_product_group', 'Trường này là bắt buộc');
    }

    if (!formData.price.trim()) {
      newErrors.price = t('validation.required_product_price', 'Trường này là bắt buộc');
    } else if (isNaN(Number(formData.price)) || Number(formData.price) <= 0) {
      newErrors.price = t('validation.invalid_price', 'Giá sản phẩm phải là số dương');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user makes selection
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      const productData = {
        name: formData.name.trim(),
        type: formData.type,
        group: formData.group,
        price: parseFloat(formData.price) || 0,
        description: formData.description.trim()
      };

      const result = await productApi.createProduct(productData);
      
      if (result.success) {
        showSuccessToast(t('product.create_success', 'Tạo sản phẩm thành công'));
        navigate('/products');
      } else {
        showErrorToast(result.error || t('product.create_error', 'Có lỗi xảy ra khi tạo sản phẩm'));
      }
    } catch (error) {
      console.error('Error creating product:', error);
      showErrorToast(t('product.create_error', 'Có lỗi xảy ra khi tạo sản phẩm'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <PageContainer title={t("product.create_new_product", "Thêm mới sản phẩm")}>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Product Type and Code Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="type" className="text-sm font-medium text-[#344054]">
                {t('product.product_type')} <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.type}
                onValueChange={(value) => handleSelectChange('type', value)}
              >
                <SelectTrigger className="h-9 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]">
                  <SelectValue placeholder={t('product.product_type_placeholder', 'Chọn loại sản phẩm')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="goods">{t('product.product_type_goods', 'Hàng hoá')}</SelectItem>
                  <SelectItem value="service">{t('product.product_type_service', 'Dịch vụ')}</SelectItem>
                </SelectContent>
              </Select>
              {errors.type && <p className="text-sm text-red-500">{errors.type}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="code" className="text-sm font-medium text-[#344054]">
                {t('product.product_code')} <span className="text-red-500">*</span>
              </Label>
              <div className="h-9 bg-[#F3F3F3] border border-[#E4E4E7] rounded-md flex items-center px-3 text-sm text-[#71717A]">
                {t('product.auto_generated_code', 'Tự động tạo bởi hệ thống')}
              </div>
            </div>
          </div>

          {/* Product Name */}
          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-medium text-[#344054]">
              {t('product.product_name')} <span className="text-red-500">*</span>
            </Label>
            <Input
              id="name"
              name="name"
              placeholder={t('product.product_name_placeholder', 'Nhập tên sản phẩm')}
              value={formData.name}
              onChange={handleInputChange}
              className="h-9 px-3 py-2 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"
            />
            {errors.name && <p className="text-sm text-red-500">{errors.name}</p>}
          </div>

          {/* Product Group and Price Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="group" className="text-sm font-medium text-[#344054]">
                {t('product.product_group')} <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.group}
                onValueChange={(value) => handleSelectChange('group', value)}
              >
                <SelectTrigger className="h-9 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]">
                  <SelectValue placeholder={t('product.product_group_placeholder', 'Chọn nhóm sản phẩm')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="course">Khóa học</SelectItem>
                  <SelectItem value="book">Sách giáo khoa</SelectItem>
                  <SelectItem value="material">Tài liệu</SelectItem>
                  <SelectItem value="equipment">Thiết bị</SelectItem>
                </SelectContent>
              </Select>
              {errors.group && <p className="text-sm text-red-500">{errors.group}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="price" className="text-sm font-medium text-[#344054]">
                {t('product.product_price')} <span className="text-red-500">*</span>
              </Label>
              <InputWithPostfix
                id="price"
                name="price"
                placeholder={t('product.product_price_placeholder', 'Nhập giá sản phẩm')}
                value={formData.price}
                onChange={handleInputChange}
                postfix="đ"
                className="h-9 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7]"
              />
              {errors.price && <p className="text-sm text-red-500">{errors.price}</p>}
            </div>
          </div>

          {/* Product Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-medium text-[#71717A]">
              {t('product.product_description')}
            </Label>
            <Textarea
              id="description"
              name="description"
              placeholder={t('product.product_description_placeholder', 'Nhập mô tả sản phẩm')}
              value={formData.description}
              onChange={handleInputChange}
              className="min-h-[120px] px-3 py-2 bg-white border-[#E4E4E7] focus:border-[#E4E4E7] focus:ring-[#F2F4F7] resize-none"
            />
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/products")}
              className="h-9 px-4 py-2 border-[#E4E4E7] text-[#344054] hover:text-[#344054] hover:bg-[#F9FAFB]"
            >
              {t('common.cancel', 'Hủy bỏ')}
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className={`h-9 px-4 py-2 bg-[#E67364] hover:bg-[#E67364]/90 text-white font-medium ${
                loading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {loading ? t('common.creating', 'Đang tạo...') : t('common.create', 'Thêm mới')}
            </Button>
          </div>
        </form>
      </PageContainer>
    </MainLayout>
  );
} 