import { useState, useEffect } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import MainLayout from "../../components/layout/main-layout";
import { Button } from "../../components/ui/button";
import { Label } from "../../components/ui/label";
import { PageContainer } from "@/components/page-container";
import { Skeleton } from "@/components/ui/skeleton";
import { classApi } from "@/api/services/class";
import { courseApi } from "@/api/services/course";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { Combobox } from "@/components/ui/combobox";
import { facilityApi } from "@/api/services/facility";
import { staffApi } from "@/api/services/staff";
import { ClassStatus } from "@/api/services/class";
import { showSuccessToast, showErrorToast } from "@/utils/toast";
import { ERROR_MESSAGES } from "@/data/constants";
import { useTranslation } from "react-i18next";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { DatePicker } from "@/components/ui/date-picker";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import { PrefilledInput } from "@/components/ui/prefilled-input";
import { formatNumber } from "@/lib/utils";

export default function CreateClass() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const classId = searchParams.get('classId');
  const isEdit = Boolean(id);
  const isCreateFromClass = Boolean(classId);
  const [loading, setLoading] = useState(false);
  const [formLoading, setFormLoading] = useState(true);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    subject_name: "",
    course_id: "",
    max_student_count: "",
    teacher_id: "",
    facility_id: "",
    opening_date: "",
    price_per_session: "",
    session_count: "",
    tuition_fee: ""
  });
  const [courseOptions, setCourseOptions] = useState([]);
  const [teacherOptions, setTeacherOptions] = useState([]);
  const [facilityOptions, setFacilityOptions] = useState([]);
  const [optionsLoading, setOptionsLoading] = useState(true);
  const { t } = useTranslation();

  useBreadcrumb(t('class.class_list'), '/classes');
  useBreadcrumb(isEdit ? t('class.update_class') : t('class.create_class'));

  useEffect(() => {
    const fetch = async () => {
      if (!isEdit && !isCreateFromClass) {
        setFormLoading(false);
        return;
      }
      
      try {
        setFormLoading(true);
        
        if (isEdit) {
          // Edit mode - fetch class data
          const res = await classApi.getClassById(id);
          if (res.success && res.data) {
            const c = res.data;
            setFormData({
              name: c.name || "",
              code: c.code || "",
              subject_name: c.subject_name || "",
              course_id: c.course_id ? String(c.course_id) : "",
              max_student_count: c.max_student_count || "",
              teacher_id: c.teacher_id ? String(c.teacher_id) : "",
              facility_id: c.facility_id ? String(c.facility_id) : "",
              opening_date: c.opening_date ? c.opening_date.split("T")[0] : "",
              price_per_session: c.price_per_session || "",
              session_count: c.session_count || "",
              tuition_fee: c.tuition_fee || ""
            });
          } else {
            showErrorToast(res.error || t('errors.load_class_detail'));
            navigate("/classes");
          }
        } else if (isCreateFromClass) {
          // Create from class mode - fetch class data and auto-fill
          const classRes = await classApi.getClassById(classId);
          if (classRes.success && classRes.data) {
            const classData = classRes.data;
            setFormData(prev => ({
              ...prev,
              course_id: classData.course_id ? String(classData.course_id) : "",
              subject_name: classData.subject_name || "",
              max_student_count: classData.max_student_count || "",
              facility_id: classData.facility_id ? String(classData.facility_id) : "",
              teacher_id: classData.teacher_id ? String(classData.teacher_id) : "",
            }));
            
            // Call API to get init info for class name and code using courseId
            try {
              const courseId = classData.course_id;
              const initRes = await classApi.getInitInfo(courseId);
              if (initRes.success && initRes.data) {
                setFormData(prev => ({
                  ...prev,
                  name: initRes.data.name || '',
                  code: initRes.data.code || '',
                  subject_name: initRes.data.subject_name || classData.subject_name || '',
                }));
              }
            } catch {
              // Don't show error toast for init info failure as it's not critical
            }
          } else {
            showErrorToast(classRes.error || t('errors.load_class_detail'));
            navigate(`/classes/${classId}`);
          }
        }
      } finally {
        setFormLoading(false);
      }
    };
    fetch();
  }, [id, classId, isEdit, isCreateFromClass, navigate, t]);

  useEffect(() => {
    // Fetch select options
    const fetchOptions = async () => {
      setOptionsLoading(true);
      try {
        const [coursesRes, teachersRes, facilitiesRes] = await Promise.all([
          courseApi.getCourses(),
          staffApi.getStaff({ role_code: 'TEACHER' }),
          facilityApi.getAll(),
        ]);
        setCourseOptions(coursesRes.data?.items || []);
        setTeacherOptions(teachersRes.items || []);
        setFacilityOptions(facilitiesRes.items || []);
      } catch {
        showErrorToast(t('errors.load_select_data'));
      } finally {
        setOptionsLoading(false);
      }
    };
    fetchOptions();
  }, [t]);

  // Calculate tuition fee when price_per_session or session_count changes
  useEffect(() => {
    const price = formData.price_per_session;
    const sessions = formData.session_count;
    
    if (price && sessions && price !== "" && sessions !== "") {
      // Remove any non-digit characters except dots for price
      const cleanPrice = price.toString().replace(/[^0-9.]/g, '');
      const cleanSessions = sessions.toString().replace(/[^0-9]/g, '');
      
      const total = parseFloat(cleanPrice) * parseFloat(cleanSessions);
      
      if (!isNaN(total)) {
        setFormData(prev => ({ ...prev, tuition_fee: total.toString() }));
      }
    } else {
      // Clear tuition_fee if either field is empty
      setFormData(prev => ({ ...prev, tuition_fee: "" }));
    }
  }, [formData.price_per_session, formData.session_count]);

  const handleChange = async (e) => {
    const { name, value } = e.target;

    // For money fields, strip non-digit chars except dots before storing numeric value
    const moneyFields = ["price_per_session", "tuition_fee"];
    let processedValue = value;
    if (moneyFields.includes(name)) {
      processedValue = value.replace(/[^0-9.]/g, "");
    }

    setFormData((prev) => ({ ...prev, [name]: processedValue }));

    // Calculate total price when price_per_session or total_sessions changes
    if (name === "price_per_session" || name === "session_count") {
      const price = name === "price_per_session" ? processedValue : formData.price_per_session;
      const sessions = name === "session_count" ? value : formData.session_count;
      
      if (price && sessions) {
        const total = parseFloat(price) * parseFloat(sessions);
        if (!isNaN(total)) {
          setFormData(prev => ({ ...prev, tuition_fee: total.toString() }));
        }
      }
    }

    // If course_id is selected, automatically call API to get course info and create class name/code
    if (name === 'course_id' && value) {
      try {
        // Get course information
        const courseRes = await courseApi.getCourseById(value);
        if (courseRes.success && courseRes.data) {
          const courseData = courseRes.data;
          
          // Get information to create class name and code
          const initRes = await classApi.getInitInfo(value);
          if (initRes.success && initRes.data) {
            setFormData(prev => ({
              ...prev,
              name: initRes.data.name || '',
              code: initRes.data.code || '',
              subject_name: courseData.subject_name || '',
            }));
          } else {
            // If can't get init info, only update subject_name
            setFormData(prev => ({
              ...prev,
              subject_name: courseData.subject_name || '',
            }));
          }
        } else {
          showErrorToast(courseRes.error || t('errors.load_course_detail'));
        }
      } catch (err) {
        showErrorToast(err?.response?.data?.message || err.message || t('errors.load_course_detail'));
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    const validation = classApi.validateClassData(formData);
    if (!validation.isValid) {
      setErrors(validation.errors);
      showErrorToast(t('errors.required_fields'));
      setLoading(false);
      return;
    }

    try {
      // Prepare API data to match backend
      const apiData = {
        name: formData.name,
        code: formData.code,
        course_id: formData.course_id ? Number(formData.course_id) : undefined,
        max_student_count: formData.max_student_count ? Number(formData.max_student_count) : undefined,
        teacher_id: formData.teacher_id ? Number(formData.teacher_id) : undefined,
        facility_id: formData.facility_id ? Number(formData.facility_id) : undefined,
        opening_date: formData.opening_date,
        price_per_session: formData.price_per_session ? Number(formData.price_per_session) : undefined,
        session_count: formData.session_count ? Number(formData.session_count) : undefined,
        tuition_fee: formData.tuition_fee ? Number(formData.tuition_fee) : undefined,
        status: ClassStatus.PENDING,
      };
      let res;
      if (isEdit) {
        res = await classApi.updateClass(id, apiData);
      } else {
        res = await classApi.createClass(apiData);
      }
      if (res.success) {
        showSuccessToast(isEdit ? t('success.updateClass') : t('success.createClass'));
        navigate("/classes");
      } else {
        showErrorToast(res.error || ERROR_MESSAGES.GENERIC_ERROR);
      }
    } catch (err) {
      showErrorToast(err?.response?.data?.message || err.message || ERROR_MESSAGES.GENERIC_ERROR);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <PageContainer title={isEdit ? t('class.update_class') : t('class.create_class')}>
        {formLoading || optionsLoading ? (
          <div className="space-y-4">
            <Skeleton className="w-full h-[400px] rounded-xl" />
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* First row - Course, Teacher, Facility */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Course */}
              <div className="space-y-1">
                <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">{t('course.course')}</Label>
                <Combobox
                  options={courseOptions.map(course=>({value:String(course.id), label:course.name}))}
                  value={formData.course_id}
                  onChange={(v)=>handleChange({target:{name:'course_id',value:v}})}
                  placeholder={t('course.select_course_placeholder')}
                />
                {errors.course_id && <p className="text-red-500 text-sm">{errors.course_id}</p>}
              </div>

              {/* Teacher */}
              <div className="space-y-1">
                <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">{t('teacher.teacher')}</Label>
                <Combobox
                  options={teacherOptions.map(t=>({value:String(t.user_id), label:t.full_name}))}
                  value={formData.teacher_id}
                  onChange={(v)=>handleChange({target:{name:'teacher_id',value:v}})}
                  placeholder={t('teacher.select_teacher_placeholder')}
                />
                {errors.teacher_id && <p className="text-red-500 text-sm">{errors.teacher_id}</p>}
              </div>

              {/* Facility */}
              <div className="space-y-1">
                <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">{t('facility.facility')}</Label>
                <Combobox
                  options={facilityOptions.map(f=>({value:String(f.id), label:`${f.name} - ${f.code || ''}`.trim()}))}
                  value={formData.facility_id}
                  onChange={(v)=>handleChange({target:{name:'facility_id',value:v}})}
                  placeholder={t('facility.select_facility_placeholder')}
                />
                {errors.facility_id && <p className="text-red-500 text-sm">{errors.facility_id}</p>}
              </div>
            </div>

            {/* Second row - Class name, Code, Subject */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label htmlFor="name" className="after:content-['*'] after:ml-0.5 after:text-red-500">{t('class.class_name')}</Label>
                <PrefilledInput
                  id="name"
                  name="name"
                  value={formData.name}
                />
                {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
              </div>

              <div className="space-y-1">
                <Label htmlFor="code">{t('class.class_code')}</Label>
                <PrefilledInput
                  id="code"
                  name="code"
                  value={formData.code}
                />
                {errors.code && <p className="text-red-500 text-sm">{errors.code}</p>}
              </div>

              <div className="space-y-1">
                <Label htmlFor="subject_name">{t('subject.subject')}</Label>
                <PrefilledInput
                  id="subject_name"
                  name="subject_name"
                  value={formData.subject_name}
                />
                {errors.subject_name && <p className="text-red-500 text-sm">{errors.subject_name}</p>}
              </div>
            </div>

            {/* Third row - Price per Session, Total Sessions, Total Class Fee */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label htmlFor="price_per_session" className="after:content-['*'] after:ml-0.5 after:text-red-500">{t('finance.price_per_session')}</Label>
                <InputWithPostfix
                  id="price_per_session"
                  name="price_per_session"
                  type="text"
                  placeholder={t('finance.enter_price_per_session_placeholder')}
                  value={formatNumber(formData.price_per_session)}
                  onChange={handleChange}
                  postfix={t('finance.currency_per_session')}
                />
                {errors.price_per_session && <p className="text-red-500 text-sm">{errors.price_per_session}</p>}
              </div>

              <div className="space-y-1">
                <Label htmlFor="session_count">{t('schedule.total_sessions')}</Label>
                <InputWithPostfix
                  id="session_count"
                  name="session_count"
                  type="text"
                  placeholder={t('schedule.enter_total_sessions_placeholder')}
                  value={formData.session_count}
                  onChange={handleChange}
                  postfix={t('finance.session_unit')}
                />
                {errors.session_count && <p className="text-red-500 text-sm">{errors.session_count}</p>}
              </div>

              <div className="space-y-1">
                <Label htmlFor="tuition_fee">{t('finance.tuition_fee')}</Label>
                <PrefilledInput
                  id="tuition_fee"
                  name="tuition_fee"
                  value={formatNumber(formData.tuition_fee)}
                  postfix={t('finance.currency')}
                />
                {errors.tuition_fee && <p className="text-red-500 text-sm">{errors.tuition_fee}</p>}
              </div>
            </div>

            {/* Fourth row - Class Size, Opening Date */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label htmlFor="max_student_count" className="after:content-['*'] after:ml-0.5 after:text-red-500">{t('finance.max_student_count')}</Label>
                <InputWithPostfix
                  id="max_student_count"
                  name="max_student_count"
                  type="text"
                  placeholder={t('finance.enter_max_student_count_placeholder')}
                  value={formData.max_student_count}
                  onChange={handleChange}
                  postfix={t('student.students')}
                />
                {errors.max_student_count && <p className="text-red-500 text-sm">{errors.max_student_count}</p>}
              </div>

              <div className="space-y-1">
                <Label htmlFor="opening_date">{t('registration.opening_date')}</Label>
                <DatePicker
                  value={formData.opening_date}
                  onChange={(v)=>handleChange({target:{name:'opening_date', value:v}})}
                  placeholder={t('registration.select_opening_date_placeholder')}
                />
                {errors.opening_date && <p className="text-red-500 text-sm">{errors.opening_date}</p>}
              </div>
            </div>

            {/* Submit buttons */}
            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => navigate(-1)} disabled={loading}>
                {t('common.cancel')}
              </Button>
              <Button type="submit" disabled={loading} className="bg-brand text-white hover:bg-brand/90">
                {loading ? t('common.saving') : isEdit ? t('common.update') : t('common.create')}
              </Button>
            </div>
          </form>
        )}
      </PageContainer>
    </MainLayout>
  );
} 