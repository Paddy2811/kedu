import { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import MainLayout from "../../components/layout/main-layout";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "../../components/ui/tabs";
import { PageContainer } from "@/components/page-container";
import { Skeleton } from "@/components/ui/skeleton";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { classApi, ClassStatus } from "@/api/services/class";
import { formatDateDMY } from "@/lib/utils";
import { useTranslation } from "react-i18next";

import StartClassDialog from "./components/StartClassDialog";
import StudentDetailSheet from "./components/StudentDetailSheet";
import SetupScheduleDialog from "./components/SetupScheduleDialog";
import { toast } from "sonner";
import ClassSummaryCard from "./components/ClassSummaryCard";
import StudentsTab from "./components/StudentsTab";
import ScheduleTab from "./components/ScheduleTab";
import ClassInfoTab from "./components/ClassInfoTab";

// Define mock sessions outside component to keep stable reference
// const MOCK_SESSIONS = [
//   {
//     id: 1,
//     session_no: 1,
//     title: "Múa Ballet nâng cao có những yêu cầu gì?",
//     date: "2025-06-12",
//     time: "14:00 - 16:00",
//     facility: "Cơ sở Cửa Bắc",
//     teacher: "Trương Minh Tuấn",
//     status: "COMPLETED",
//   },
//   {
//     id: 2,
//     session_no: 2,
//     title: "Múa Ballet nâng cao có những yêu cầu gì?",
//     date: "2025-06-13",
//     time: "14:00 - 16:00",
//     facility: "Cơ sở Cửa Bắc",
//     teacher: "Trương Minh Tuấn",
//     status: "UPCOMING",
//   },
//   {
//     id: 3,
//     session_no: 3,
//     title: "Múa Ballet nâng cao có những yêu cầu gì?",
//     date: "2025-06-14",
//     time: "14:00 - 16:00",
//     facility: "Cơ sở Cửa Bắc",
//     teacher: "Trương Minh Tuấn",
//     status: "NOT_STARTED",
//   },
// ];

// Mock student data for testing
// const MOCK_STUDENTS = [
//   {
//     id: "1",
//     full_name: "Nguyễn Minh Anh",
//     phone_number: "0909090909",
//     student_code: "ST00123",
//     completed_sessions: 12,
//     avatar_url: ""
//   },
//   {
//     id: "2",
//     full_name: "Trần Hoàng Nam",
//     phone_number: "0909090909",
//     student_code: "ST00124",
//     completed_sessions: 14,
//     avatar_url: ""
//   },
//   {
//     id: "3",
//     full_name: "Lê Thị Hương",
//     phone_number: "0909090909",
//     student_code: "ST00125",
//     completed_sessions: 10,
//     avatar_url: ""
//   },
//   {
//     id: "4",
//     full_name: "Phạm Văn Đức",
//     phone_number: "0909090909",
//     student_code: "ST00126",
//     completed_sessions: 15,
//     avatar_url: ""
//   },
//   {
//     id: "5",
//     full_name: "Hoàng Thị Mai",
//     phone_number: "0909090909",
//     student_code: "ST00127",
//     completed_sessions: 13,
//     avatar_url: ""
//   },
//   {
//     id: "6",
//     full_name: "Vũ Quang Minh",
//     phone_number: "0909090909",
//     student_code: "ST00128",
//     completed_sessions: 11,
//     avatar_url: ""
//   }
// ];

export default function ClassDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [classData, setClassData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("schedule");
  const [students, setStudents] = useState([]);
  const [studentsLoading, setStudentsLoading] = useState(false);
  const [studentsTotal, setStudentsTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const pageSize = 10;

  const [showStartClassDialog, setShowStartClassDialog] = useState(false);
  const [activating, setActivating] = useState(false);
  const [forceActiveStatus, setForceActiveStatus] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState(null);
  const [showStudentDetailSheet, setShowStudentDetailSheet] = useState(false);

  const { t } = useTranslation();
  
  // Set breadcrumb
  useBreadcrumb(t("class.class_list"), "/classes");
  useBreadcrumb(t("class.class_detail"));

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const res = await classApi.getClassById(id);
        if (res.success && res.data) {
          // Map API fields to UI fields
          const c = res.data;
          setClassData({
            id: c.id,
            code: c.code,
            name: c.name,
            course_name: c.course_name || '',
            course_id: c.course_id || '',
            subject_name: c.subject_name || '',
            facility_name: c.facility_name || '',
            facility_id: c.facility_id || '',
            max_student_count: c.max_student_count || 0,
            current_student_count: c.current_student_count || 0,
            session_count: c.session_count || 0,
            completed_sessions: c.completed_sessions || 0,
            opening_date: c.opening_date ? formatDateDMY(c.opening_date) : '',
            teacher_id: c.teacher_id,
            teacher_full_name: c.teacher_full_name,
            teacher_initials: c.teacher_full_name ? c.teacher_full_name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0, 2) : '',
            teacher_avatar: c.teacher_avatar || c.teacher_avatar_url || '',
            price_per_session: c.price_per_session ? `${c.price_per_session.toLocaleString('vi-VN')}đ` : '',
            tuition_fee: c.tuition_fee ? c.tuition_fee.toLocaleString('vi-VN') + 'đ' : '',
            status: c.status || '',
            sessions: c.sessions || [],
          });
        } else {
          setClassData(null);
          toast.error(res.error || t('errors.load_class_detail'));
        }
      } catch (e) {
        setClassData(null);
        toast.error(e?.response?.data?.message || e.message || t('errors.load_class_detail'));
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id, t]);

  const fetchStudents = useCallback(async () => {
    setStudentsLoading(true);
    try {
      const result = await classApi.getClassStudents(id, {
        page: currentPage,
        pagesize: pageSize,
        keyword: searchQuery,
      });
      
      if (result.success && result.data) {
        setStudents(result.data.items || []);
        setStudentsTotal(result.data.total || 0);
      } else {
        console.error("Failed to fetch students:", result.error);
        setStudents([]);
        setStudentsTotal(0);
      }
    } catch (error) {
      console.error("Error fetching students:", error);
      setStudents([]);
      setStudentsTotal(0);
    } finally {
      setStudentsLoading(false);
    }
  }, [id, currentPage, pageSize, searchQuery]);

  // Update the handleActivateClass for smoother transitions
  const handleActivateClass = async () => {
    try {
      // Start activating state
      setActivating(true);
      
      // First, immediately set UI to active state for a responsive feel
      setForceActiveStatus(true);
      
      // Call API to update class status to ACTIVE (in background)
      const resUpdate = await classApi.updateClass(id, { status: ClassStatus.ACTIVE });
      
      // Show success toast
      toast.success(t('attendance_edit.start_class_success', { name: classData?.name || '' }));
      
      // If API call failed, show error but keep UI in active state
      // Most users won't notice the error if UI already updated
      if (!resUpdate.success) {
        console.warn('API call to update class status failed, but UI shows active status:', resUpdate.error);
      }
      
      return true; // Success - close dialog
    } catch (error) {
      // Show error toast
      toast.error(error?.message || t('common.featureNotAvailable'));
      
      // Revert UI status on failure
      setForceActiveStatus(false);
      
      console.error('Error activating class:', error);
      throw error; // Keep dialog open on error
    } finally {
      setActivating(false);
    }
  };

  // Run student fetch when Students tab active
  useEffect(() => {
    if (tab === "students" && id) {
      fetchStudents();
    }
  }, [tab, id, currentPage, searchQuery, fetchStudents]);



  const displayStatus = forceActiveStatus ? ClassStatus.ACTIVE : classData?.status;

  // Handle student click
  const handleStudentClick = (studentId) => {
    setSelectedStudentId(studentId);
    setShowStudentDetailSheet(true);
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="space-y-4">
          <Skeleton className="w-full h-[139px] rounded-xl" />
          <Skeleton className="w-full h-[44px] rounded-lg" />
          <Skeleton className="w-full h-[174px] rounded-lg" />
        </div>
      );
    }

    if (!classData) {
      return (
        <div className="w-full rounded-xl border border-[#E2E8F0] bg-white p-6 text-sm text-[#8B9AA2]">
          {t('errors.load_class_detail')}
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {/* Summary Card */}
        <ClassSummaryCard 
          classData={classData}
          displayStatus={displayStatus}
          onEdit={() => navigate(`/classes/${id}/edit`)}
          onStartClass={() => setShowStartClassDialog(true)}
          activating={activating}
        />

        {/* Tabs Section */}
        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="bg-[#F8FAFC] p-1 h-auto rounded-lg mb-4 border border-[#E2E8F0]">
            <TabsTrigger
              value="schedule"
              className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
            >
              {t('schedule.schedule')}
            </TabsTrigger>
            <TabsTrigger
              value="students"
              className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
            >
              {t('student.students_plural')}
            </TabsTrigger>
            <TabsTrigger
              value="info"
              className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
            >
              {t('registration.info')}
            </TabsTrigger>
          </TabsList>

          {/* Class Information Tab */}
          <TabsContent value="info" className="mt-0">
            <ClassInfoTab loading={loading} classData={classData} />
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule" className="mt-0">
            <ScheduleTab
              classId={id}
              classSessionCount={classData?.session_count || 0}
              onAddSession={() => navigate(`/classes/${id}/add-session`)}
            />
          </TabsContent>

          {/* Students Tab */}
          <TabsContent value="students" className="mt-0">
            <div className="w-full rounded-xl border border-[#E2E8F0] bg-white">
              <StudentsTab
                students={students}
                studentsLoading={studentsLoading}
                studentsTotal={studentsTotal}
                pageSize={pageSize}
                currentPage={currentPage}
                onPageChange={setCurrentPage}
                searchQuery={searchQuery}
                onAddStudent={() => navigate('/register')}
                onStudentClick={handleStudentClick}
                sessionCount={classData?.session_count || 0}
                onSearchChange={(value) => {
                  setSearchQuery(value);
                  setCurrentPage(1);
                }}
              />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    );
  };

  return (
    <MainLayout>
      <PageContainer title={t("class.class_detail")}>
        {renderContent()}
        <StartClassDialog 
          open={showStartClassDialog}
          onOpenChange={setShowStartClassDialog}
          onConfirm={handleActivateClass}
          classData={classData}
          activating={activating}
        />
        <StudentDetailSheet
          open={showStudentDetailSheet}
          onOpenChange={setShowStudentDetailSheet}
          studentId={selectedStudentId}
          classId={id}
        />
      </PageContainer>
    </MainLayout>
  );
} 