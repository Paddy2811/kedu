import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MoreVertical, Plus } from "lucide-react";
import { Button } from "../../components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useBreadcrumb } from "@/contexts/breadcrumb-context";
import { useTranslation } from "react-i18next";
import { useToast } from '@/components/ui/use-toast';
import { getClassStatusBadgeProps } from '@/api/services/class';
import { classApi } from '@/api/services/class';
import { MasterListLayout } from '@/components/layout/master-list-layout';

export default function ClassList() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [classes, setClasses] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const SEARCH_MIN_CHARS = 1;
  
  // Set breadcrumb
  useBreadcrumb(t("class.list.title"), "/classes");
  
  // Fetch classes from API
  useEffect(() => {
    const fetchClasses = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = {
          page: currentPage,
          pagesize: itemsPerPage,
        };
        if (searchTerm.length === 0 || searchTerm.length >= SEARCH_MIN_CHARS) {
          if (searchTerm) params.keyword = searchTerm;
          const res = await classApi.getClasses(params);
          if (res.success) {
            setClasses(res.data.items);
            setTotal(res.data.total);
          } else {
            setClasses([]);
            setTotal(0);
            setError(res.error || t('common.no_data'));
            toast({
              variant: "destructive",
              title: t('error'),
              description: res.error || t('common.no_data'),
            });
          }
        } else {
          setClasses([]);
          setTotal(0);
        }
      } catch (err) {
        setClasses([]);
        setTotal(0);
        setError(err.message || t('common.no_data'));
        toast({
          variant: "destructive",
          title: t('error'),
          description: err.message || t('common.no_data'),
        });
      } finally {
        setLoading(false);
      }
    };
    fetchClasses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, searchTerm, itemsPerPage]);

  // Calculate pagination
  const totalPages = Math.ceil(total / itemsPerPage);

  // Handle page change
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  // Handle actions
  const handleView = (classId) => {
    navigate(`/classes/${classId}`);
  };

  const handleEdit = (classId) => {
    navigate(`/classes/${classId}/edit`);
  };

  const handleDelete = (classId) => {
    toast({
      title: t("common.notImplemented"),
      description: t("common.featureNotAvailable") + ` (ID: ${classId})`,
      variant: "destructive",
    });
  };

  // Define columns for DataTable
  const columns = [
    {
      key: 'name',
      header: t('class.class'),
      width: '300px',
      cellRenderer: (classItem) => (
        <div className="flex flex-col">
          <span className="text-[#020617] font-medium">{classItem.code}</span>
          <span className="text-[#64748B] text-sm">{classItem.course_name}</span>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex flex-col gap-2">
          <Skeleton className="h-4 w-24 mb-1" />
          <Skeleton className="h-3 w-32" />
        </div>
      )
    },
    {
      key: 'teacher',
      header: t('teacher.teacher'),
      width: '200px',
      cellRenderer: (classItem) => (
        <span className="text-[#020617]">{classItem.teacher_full_name}</span>
      ),
      skeletonWidth: 'w-[150px]'
    },
    {
      key: 'class_size',
      header: t('class.class_size'),
      width: '180px',
      align: 'center',
      cellRenderer: (classItem) => (
        <span className="text-[#020617]">{`${classItem.current_student_count || 0}/${classItem.max_student_count || 0}`}</span>
      ),
      skeletonRenderer: () => (
        <Skeleton className="h-4 w-16 mx-auto" />
      )
    },
    {
      key: 'facility',
      header: t('facility.facility'),
      width: '200px',
      cellRenderer: (classItem) => (
        <span className="text-[#020617]">{classItem.facility_name}</span>
      ),
      skeletonWidth: 'w-[150px]'
    },
    {
      key: 'status',
      header: t('common.status'),
      width: '150px',
      align: 'center',
      cellRenderer: (classItem) => (
        <Badge
          variant="outline"
          {...getClassStatusBadgeProps(classItem.status)}
          className={
            getClassStatusBadgeProps(classItem.status).className +
            " border-0 px-2.5 py-0.5 text-xs font-semibold"
          }
        >
          {getClassStatusBadgeProps(classItem.status).children}
        </Badge>
      ),
      skeletonRenderer: () => (
        <Skeleton className="h-4 w-20 mx-auto" />
      )
    },
    {
      key: 'actions',
      header: '',
      width: '120px',
      align: 'right',
      cellRenderer: (classItem) => (
        <div className="flex items-center justify-end gap-3">
          <Button
            variant="link"
            className="text-brand hover:text-brand/90 p-0 h-auto"
            onClick={() => handleView(classItem.id)}
          >
            {t('common.detail')}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-9 w-9 p-0 hover:bg-[#F1F5F9]">
                <MoreVertical className="w-4 h-4 text-brand" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleEdit(classItem.id)}>
                {t('common.edit')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleDelete(classItem.id)} className="text-destructive">
                {t('common.delete')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      skeletonRenderer: () => (
        <div className="flex items-center justify-end gap-3">
          <Skeleton className="h-8 w-16" />
          <Skeleton className="h-8 w-8 rounded-md" />
        </div>
      )
    }
  ];

  return (
    <MasterListLayout
      title={t("class.class_list", "Class List")}
      searchPlaceholder={t("class.search_class_placeholder", "Search class...")}
      searchValue={searchTerm}
      onSearchChange={(value) => {
        setSearchTerm(value);
        setCurrentPage(1);
      }}
      columns={columns}
      data={classes}
      loading={loading}
      error={error}
      currentPage={currentPage}
      totalPages={totalPages}
      onPageChange={handlePageChange}
      totalItems={total}
      itemsLabel={t('class.classes', 'classes')?.toLowerCase()}
      emptyTitle={t('class.no_classes', 'No classes yet')}
      emptySubtitle={t('class.no_classes_subtitle', 'When classes are available, they will appear here.')}
      emptyButtonText={t('common.addNew', 'Add new')}
      onEmptyAction={() => navigate('/classes/create')}
      emptyButtonIcon={<Plus className="w-4 h-4" />}
      showAddButton={true}
      addButtonText={t('common.addNew', 'Add new')}
      onAddClick={() => navigate('/classes/create')}
    />
  );
} 