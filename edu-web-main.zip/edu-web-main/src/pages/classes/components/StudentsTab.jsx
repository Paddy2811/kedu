import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Pagination } from "@/components/ui/pagination";
import { Search, UserPlus } from "lucide-react";
import StudentCard from "./StudentCard";

export default function StudentsTab({
  students,
  studentsLoading,
  studentsTotal,
  pageSize,
  currentPage,
  onPageChange,
  searchQuery,
  onSearchChange,
  onAddStudent,
  onStudentClick,
  sessionCount,
}) {
  const { t } = useTranslation();

  // Local state for search input
  const [localSearch, setLocalSearch] = useState(searchQuery || "");

  // Sync local state with prop if parent changes (e.g. clear)
  useEffect(() => {
    setLocalSearch(searchQuery || "");
  }, [searchQuery]);

  return (
    <div className="p-4">
      {/* Search and Add */}
      <div className="flex items-center justify-between mb-4">
        <div className="relative w-[384px]">
          <div className="flex items-center border border-[#E2E8F0] rounded-lg focus-within:ring-1 focus-within:ring-brand focus-within:border-brand bg-white">
            <Search className="w-4 h-4 ml-3 text-[#94A3B8]" />
            <input
              type="text"
              placeholder={t("student.search_student_placeholder")}
              className="border-0 h-9 px-3 py-2 text-[13px] focus-visible:ring-0 placeholder:text-[#94A3B8] w-full"
              value={localSearch}
              onChange={(e) => {
                const value = e.target.value;
                setLocalSearch(value);
                if (value) onSearchChange(value);
              }}
            />
          </div>
        </div>
        <Button variant="outline" onClick={onAddStudent}>
          <UserPlus className="w-4 h-4 mr-2" />
          {t("student.add_student")}
        </Button>
      </div>

      {/* Total */}
      <div className="flex items-center mb-4">
        <span className="text-[14px] text-[#64748B] mr-1">{t("common.total")}:</span>
        <span className="text-[14px] font-medium text-[#020617]">{studentsTotal} {t("student.student_count_unit").toLowerCase()}</span>
      </div>

      {studentsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-[120px] w-full rounded-lg" />
          ))}
        </div>
      ) : students.length === 0 ? (
        <EmptyState
          title={t("student.no_student_data")}
          subtitle={t("student.add_student")}
          buttonText={t("student.add_student")}
          buttonIcon={<UserPlus className="w-4 h-4" />}
          onButtonClick={onAddStudent}
          className="py-8"
          noBorder
        />
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {students.map((student) => (
              <StudentCard
                key={student.id}
                student={student}
                totalSessions={sessionCount}
                onClick={() => onStudentClick(student.id)}
                onDetailClick={(id) => onStudentClick(id)}
              />
            ))}
          </div>
          {/* Pagination */}
          {studentsTotal > pageSize && (
            <div className="flex justify-end">
              <Pagination
                currentPage={currentPage}
                totalPages={Math.ceil(studentsTotal / pageSize)}
                onPageChange={onPageChange}
                className="mt-4"
              />
            </div>
          )}
        </>
      )}
    </div>
  );
} 