import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useTranslation } from "react-i18next";
import { CalendarIcon, Clock, Plus, Trash2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { scheduleApi } from "@/api/services/schedule";
import { showSuccessToast, showErrorToast, getErrorMessage } from "@/utils/toast";

const weekdays = [
  { value: "monday", label: "Thứ 2" },
  { value: "tuesday", label: "Thứ 3" },
  { value: "wednesday", label: "Thứ 4" },
  { value: "thursday", label: "Thứ 5" },
  { value: "friday", label: "Thứ 6" },
  { value: "saturday", label: "Thứ 7" },
  { value: "sunday", label: "Chủ nhật" },
];

function SetupScheduleDialog({ open, onOpenChange, classId, onConfirm }) {
  const { t } = useTranslation();
  const [startDate, setStartDate] = useState(null);
  const [classDuration, setClassDuration] = useState("");
  const [sessions, setSessions] = useState([
    { day: "", startTime: "", endTime: "" }
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Recompute end times whenever course duration changes
  useEffect(() => {
    if (!classDuration) return;
    setSessions(prev => prev.map(session => {
      if (!session.startTime) return session;

      const [hours, minutes] = session.startTime.split(":").map(Number);
      const startMinutes = hours * 60 + minutes;
      const endMinutes = startMinutes + parseInt(classDuration, 10);
      const endHours = Math.floor(endMinutes / 60) % 24;
      const endMins = endMinutes % 60;

      const formattedEndHours = endHours.toString().padStart(2, "0");
      const formattedEndMins = endMins.toString().padStart(2, "0");

      return {
        ...session,
        endTime: `${formattedEndHours}:${formattedEndMins}`,
      };
    }));
  }, [classDuration]);

  const handleAddSession = () => {
    setSessions([...sessions, { day: "", startTime: "", endTime: "" }]);
  };

  const handleRemoveSession = (indexToRemove) => {
    setSessions(sessions.filter((_, index) => index !== indexToRemove));
  };

  const handleSessionChange = (index, field, value) => {
    const updatedSessions = [...sessions];
    updatedSessions[index] = { ...updatedSessions[index], [field]: value };
    
    // Auto-calculate end time based on start time and course duration
    if (field === "startTime" && value && classDuration) {
      const startTime = new Date(`2000-01-01T${value}`);
      const endTime = new Date(startTime.getTime() + classDuration * 60 * 1000);
      const endTimeString = endTime.toTimeString().slice(0, 5);
      updatedSessions[index].endTime = endTimeString;
    }
    
    // Recalculate end time when day changes and we have start time + duration
    if (field === "day" && updatedSessions[index].startTime && classDuration) {
      const startTime = new Date(`2000-01-01T${updatedSessions[index].startTime}`);
      const endTime = new Date(startTime.getTime() + classDuration * 60 * 1000);
      const endTimeString = endTime.toTimeString().slice(0, 5);
      updatedSessions[index].endTime = endTimeString;
    }
    
    setSessions(updatedSessions);
  };

  // Recalculate all end times when course duration changes
  useEffect(() => {
    if (!classDuration) return;

    const updated = sessions.map((session) => {
      if (!session.startTime) return session;
      const startTime = new Date(`2000-01-01T${session.startTime}`);
      const endTime = new Date(startTime.getTime() + classDuration * 60 * 1000);
      const endTimeString = endTime.toTimeString().slice(0, 5);
      // Only update if endTime actually changed to avoid re-renders
      if (session.endTime === endTimeString) return session;
      return { ...session, endTime: endTimeString };
    });

    // Compare shallow equality
    const isEqual = updated.every((s, idx) => s === sessions[idx]);
    if (!isEqual) setSessions(updated);
  }, [classDuration, sessions]);

  const handleSubmit = async () => {
    // Prevent multiple submissions
    if (isSubmitting) return;

    try {
      setIsSubmitting(true);

      // Validate required fields
      if (!startDate) {
        showErrorToast(t("please_select_opening_date", "Vui lòng chọn ngày khai giảng"));
        return;
      }

      if (!classDuration) {
        showErrorToast(t("please_enter_duration", "Vui lòng nhập thời lượng buổi học"));
        return;
      }

      const validSessions = sessions.filter(s => s.day && s.startTime && s.endTime);
      if (validSessions.length === 0) {
        showErrorToast(t("please_add_at_least_one_session", "Vui lòng thêm ít nhất một buổi học"));
        return;
      }
      
      // Convert weekday string to number (0-6, where 0 is Monday)
      const weekdayMap = {
        "monday": 0,
        "tuesday": 1,
        "wednesday": 2,
        "thursday": 3,
        "friday": 4,
        "saturday": 5,
        "sunday": 6
      };

      // Format data for API
      const scheduleData = {
        class_id: parseInt(classId),
        opening_date: format(startDate, 'yyyy-MM-dd'),
        duration_per_session: parseInt(classDuration),
        status: "ACTIVE",
        session_config: validSessions.map(session => ({
          weekday: weekdayMap[session.day],
          start_time: session.startTime
        }))
      };
      
      // Call API
      const result = await scheduleApi.createSchedule(scheduleData);
      
      if (result.success) {
        showSuccessToast(t("schedule_created_successfully", "Lịch học đã được tạo thành công"));

        // Call onConfirm with response data
        if (onConfirm) {
          await onConfirm(result.data);
        }
      
      // Close dialog on success
      onOpenChange(false);
      } else {
        showErrorToast(getErrorMessage(result.error) || t("failed_to_create_schedule", "Không thể tạo lịch học"));
      }
    } catch (error) {
      console.error("Failed to setup schedule:", error);
      showErrorToast(getErrorMessage(error) || t("failed_to_create_schedule", "Không thể tạo lịch học"));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[750px]">
        <DialogHeader>
          <DialogTitle className="text-[18px] font-semibold">
            {t("schedule.setup_schedule", "Thiết lập lịch học")}
          </DialogTitle>
          <DialogDescription>
            {t(
              "setup_schedule_description",
              "Thiết lập lịch học định kỳ cho lớp. Bạn có thể thêm nhiều buổi học mỗi tuần."
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-8">
          {/* Start Date and Duration */}
          <div className="flex gap-4 w-full">
            <div className="flex-1">
              <Label htmlFor="startDate" className="after:content-['*'] after:ml-0.5 after:text-red-500">
                {t("registration.opening_date", "Ngày khai giảng")}
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="startDate"
                    variant="outline"
                    className={cn(
                      "w-full justify-between text-left font-normal mt-1",
                      !startDate && "text-[#71717A]"
                    )}
                  >
                    {startDate ? (
                      format(startDate, "dd/MM/yyyy")
                    ) : (
                      <span>{t("registration.select_opening_date_placeholder", "Chọn ngày khai giảng")}</span>
                    )}
                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex-1">
              <Label htmlFor="classDuration">
                {t("schedule.duration", "Thời lượng")}
              </Label>
              <InputWithPostfix
                id="classDuration"
                type="number"
                value={classDuration}
                onChange={(e) => setClassDuration(e.target.value)}
                placeholder={t("schedule.enter_duration", "Nhập thời lượng")}
                postfix={t("schedule.minute_unit", "phút")}
                className="mt-1 h-9"
              />
            </div>
          </div>

          {/* Schedule Section */}
          <div className="flex flex-col gap-1 w-full">
            <h3 className="font-semibold text-base">
              {t("schedule.schedule", "Lịch học")}
            </h3>
            
            <div className="flex flex-col gap-4">
              {/* Sessions */}
              {sessions.map((session, index) => (
                <div key={index} className="flex gap-4 w-full items-end">
                  <div className="flex-1">
                    <Label htmlFor={`day-${index}`} className="after:content-['*'] after:ml-0.5 after:text-red-500">
                      {t("schedule.day", "Ngày")}
                    </Label>
                    <Select
                      value={session.day}
                      onValueChange={(value) => handleSessionChange(index, "day", value)}
                      required
                    >
                      <SelectTrigger 
                        id={`day-${index}`} 
                        className="mt-1"
                      >
                        <SelectValue placeholder={t("schedule.select_day", "Chọn thứ")} />
                      </SelectTrigger>
                      <SelectContent>
                        {weekdays.map((day) => (
                          <SelectItem key={day.value} value={day.value}>
                            {day.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex-1">
                    <Label htmlFor={`time-picker-${index}`} className="after:content-['*'] after:ml-0.5 after:text-red-500">
                      {t("schedule.start_time", "Bắt đầu")}
                    </Label>
                    <div className="flex items-center mt-1 border rounded-md relative">
                      <Input
                        type="time"
                        id={`time-picker-${index}`}
                        className="flex-grow border-0 pr-8 [&::-webkit-calendar-picker-indicator]:appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                        value={session.startTime}
                        onChange={(e) => handleSessionChange(index, "startTime", e.target.value)}
                        required
                      />
                      <button
                        type="button"
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        onClick={() => document.getElementById(`time-picker-${index}`).showPicker()}
                      >
                        <Clock className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex-1">
                    <Label htmlFor={`end-time-${index}`} className="after:content-['*'] after:ml-0.5 after:text-red-500">
                      {t("end_time", "Kết thúc")}
                    </Label>
                    <div className="flex items-center mt-1 border rounded-md relative bg-muted">
                      <Input
                        type="time"
                        id={`end-time-${index}`}
                        className="flex-grow border-0 pr-8 [&::-webkit-calendar-picker-indicator]:appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                        value={session.endTime}
                        readOnly
                        required
                        disabled={true}
                      />
                      <div className="absolute right-2 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                        <Clock className="h-4 w-4" />
                      </div>
                    </div>
                  </div>

                  {/* Delete button - only show if there are 2 or more sessions */}
                  {sessions.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveSession(index)}
                      className="h-10 w-10"
                    >
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  )}
                </div>
              ))}
              
              {/* Add Session Button */}
              <Button 
                variant="outline"
                onClick={handleAddSession}
                className="border-dashed w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                {t("add_session", "Thêm buổi học")}
              </Button>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            {t("common.cancel", "Huỷ bỏ")}
          </Button>
          <Button 
            variant="brand"
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? t("common.creating", "Đang tạo...") : t("common.create", "Thêm mới")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default SetupScheduleDialog; 