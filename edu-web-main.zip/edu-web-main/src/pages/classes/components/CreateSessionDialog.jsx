import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import { PrefilledInput } from "@/components/ui/prefilled-input";
import { DatePicker } from "@/components/ui/date-picker";
import { Combobox } from "@/components/ui/combobox";
import { Calendar, Clock } from "lucide-react";
import { sessionApi } from "@/api/services/session";
import { showSuccessToast, showErrorToast } from "@/utils/toast";

export default function CreateSessionDialog({ 
  open, 
  onOpenChange, 
  sessionNumber = 1,
  teachers = [],
  classId,
  onSave 
}) {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({
    sessionName: "",
    date: "",
    duration: "",
    startTime: "",
    endTime: "",
    teacherId: ""
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  // Reset form when dialog opens
  useEffect(() => {
    if (open) {
      setFormData({
        sessionName: "",
        date: "",
        duration: "",
        startTime: "",
        endTime: "",
        teacherId: ""
      });
      setErrors({});
      
      // Debug logging when dialog opens
      console.log('Dialog opened with props:', {
        classId,
        teachers,
        sessionNumber
      });
    }
  }, [open, classId, teachers, sessionNumber]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleDateChange = (date) => {
    setFormData(prev => ({ ...prev, date }));
    if (errors.date) {
      setErrors(prev => ({ ...prev, date: "" }));
    }
  };

  const handleTeacherChange = (teacherId) => {
    setFormData(prev => ({ ...prev, teacherId }));
    if (errors.teacherId) {
      setErrors(prev => ({ ...prev, teacherId: "" }));
    }
  };

  // Calculate end time based on start time and duration
  const calculateEndTime = (startTime, duration) => {
    if (!startTime || !duration) return "";
    
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + Number(duration);
    const endHours = Math.floor(totalMinutes / 60);
    const endMinutes = totalMinutes % 60;
    
    return `${endHours.toString().padStart(2, '0')}:${endMinutes.toString().padStart(2, '0')}`;
  };

  // Update end time when start time or duration changes
  useEffect(() => {
    if (formData.startTime && formData.duration) {
      const endTime = calculateEndTime(formData.startTime, formData.duration);
      setFormData(prev => ({ ...prev, endTime }));
    }
  }, [formData.startTime, formData.duration]);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.sessionName.trim()) {
      newErrors.sessionName = t('validation.required_session_name');
    }
    
    if (!formData.date) {
      newErrors.date = t('validation.required_session_date');
    }
    
    if (!formData.duration) {
      newErrors.duration = t('validation.required_session_duration');
    } else if (isNaN(formData.duration) || Number(formData.duration) <= 0) {
      newErrors.duration = t('validation.invalid_duration');
    }
    
    if (!formData.startTime) {
      newErrors.startTime = t('validation.required_session_start_time');
    }
    
    if (!formData.teacherId) {
      newErrors.teacherId = t('validation.required_session_teacher');
    }
    
    // Validate classId is provided
    if (!classId) {
      console.error('Class ID is missing');
      showErrorToast('Class ID is required');
      return false;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    try {
      // Debug logging
      console.log('Form Data:', formData);
      console.log('Class ID:', classId);
      console.log('Teachers:', teachers);
      
      // Validate required data
      if (!formData.teacherId) {
        showErrorToast('Vui lòng chọn giáo viên');
        return;
      }
      
      if (!classId) {
        showErrorToast('Class ID is required');
        return;
      }
      
      // Prepare API data according to the API specification
      const apiData = {
        idx: sessionNumber, // sessionNumber is already the next index (0-based)
        name: formData.sessionName,
        study_date: formData.date,
        start_time: formData.startTime,
        duration_per_session: Number(formData.duration),
        teacher_id: Number(formData.teacherId),
        class_id: Number(classId)
      };
      
      console.log('API Data:', apiData);
      
      const result = await sessionApi.createSession(apiData);
      
      if (result.success) {
        showSuccessToast(t('schedule.create_session_success'));
        
        // Call the onSave callback with the created session data
        onSave({
          sessionNumber,
          sessionName: formData.sessionName,
          date: formData.date,
          duration: Number(formData.duration),
          startTime: formData.startTime,
          endTime: formData.endTime,
          teacherId: formData.teacherId,
          ...result.data // Include any additional data returned from API
        });
        
        onOpenChange(false);
      } else {
        console.error('API Error:', result.error);
        showErrorToast(result.error || t('schedule.create_session_error'));
      }
    } catch (error) {
      showErrorToast(t('schedule.create_session_error'));
      console.error('Error creating session:', error);
    } finally {
      setIsLoading(false);
    }
  };



  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">
            {t('schedule.create_new_session')}
          </DialogTitle>
          <p className="text-sm text-muted-foreground mt-1">
            {t('schedule.create_new_session_description')}
          </p>
        </DialogHeader>

        <div className="space-y-4 my-4">
          {/* Session Number and Session Name */}
          <div className="space-y-2">
            <div className="space-y-1">
              <Label>{t('schedule.session')}</Label>
              <PrefilledInput 
                value={`${t('schedule.session')} ${sessionNumber}`}
                postfix=""
              />
            </div>
            
            <div className="space-y-1">
              <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
                {t('schedule.session_name')}
              </Label>
              <Input
                name="sessionName"
                placeholder={t('schedule.enter_session_name_placeholder')}
                value={formData.sessionName}
                onChange={handleChange}
                className="h-10"
              />
              {errors.sessionName && (
                <p className="text-sm text-red-500">{errors.sessionName}</p>
              )}
            </div>
          </div>

          {/* Date and Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
                {t('schedule.date')}
              </Label>
              <div className="relative">
                <DatePicker
                  value={formData.date}
                  onChange={handleDateChange}
                  placeholder={t('schedule.enter_date_placeholder')}
                  className="h-10"
                />
              </div>
              {errors.date && (
                <p className="text-sm text-red-500">{errors.date}</p>
              )}
            </div>
            
            <div className="space-y-1">
              <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
                {t('schedule.duration_per_session')}
              </Label>
              <InputWithPostfix
                name="duration"
                type="text"
                placeholder={t('schedule.enter_duration_placeholder')}
                value={formData.duration}
                onChange={handleChange}
                postfix={t('schedule.minute_unit')}
                className="h-10"
              />
              {errors.duration && (
                <p className="text-sm text-red-500">{errors.duration}</p>
              )}
            </div>
          </div>

          {/* Start Time and End Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-3">
              <Label htmlFor="startTime" className="px-1">
                {t('schedule.start_time')}
              </Label>
              <div className="relative">
                <Input
                  type="time"
                  id="startTime"
                  name="startTime"
                  value={formData.startTime}
                  onChange={handleChange}
                  className="bg-background appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-calendar-picker-indicator]:appearance-none h-10 pr-10"
                />
                <Clock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
              {errors.startTime && (
                <p className="text-sm text-red-500">{errors.startTime}</p>
              )}
            </div>
            
            <div className="space-y-1">
              <Label>{t('schedule.end_time')}</Label>
              <div className="relative">
                <PrefilledInput
                  value={formData.endTime}
                  className="h-10 pr-10"
                  postfix=""
                  readOnly
                />
                <Clock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Teacher */}
          <div className="space-y-1">
            <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
              {t('teacher.teacher')}
            </Label>
            <Combobox
              options={teachers.map(teacher => ({
                value: String(teacher.user_id || teacher.id || teacher.staff_id),
                label: teacher.full_name
              }))}
              value={formData.teacherId}
              onChange={handleTeacherChange}
              placeholder={t('teacher.select_teacher_placeholder')}
            />
            {errors.teacherId && (
              <p className="text-sm text-red-500">{errors.teacherId}</p>
            )}
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)} 
            className="h-10 px-8"
            disabled={isLoading}
          >
            {t("common.cancel")}
          </Button>
          <Button 
            onClick={handleSave} 
            className="bg-brand text-white hover:bg-brand/90 h-10 px-8"
            disabled={isLoading}
          >
            {isLoading ? t("common.saving") : t("schedule.create_session")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 