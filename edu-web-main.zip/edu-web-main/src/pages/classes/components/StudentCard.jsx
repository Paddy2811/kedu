import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FileText } from "lucide-react";
import { useTranslation } from "react-i18next";

const StudentCard = ({ student, totalSessions, onClick }) => {
  const { t } = useTranslation();
  
  // Calculate completion percentage
  const completionPercentage = totalSessions ? (student.completed_sessions / totalSessions) * 100 : 0;
  
  // Get initials for avatar fallback
  const getInitials = (name) => {
    if (!name) return '';
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div 
      className="rounded-lg border border-[#E2E8F0] p-4 cursor-pointer hover:border-[#E67364] transition-colors"
      onClick={onClick}
    >
      <div className="flex items-start gap-3">
        <Avatar className="h-10 w-10 rounded-lg">
          <AvatarImage src={student.avatar_url} alt={student.full_name} />
          <AvatarFallback className="bg-[#F1F5F9] text-[#64748B] rounded-lg text-xs">
            {getInitials(student.full_name)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-[15px] font-medium text-[#020617] mb-0.5">{student.full_name}</h3>
              <p className="text-[13px] text-[#71717A]">{student.phone_number}</p>
            </div>
            <p className="text-[13px] text-[#71717A]">{student.student_code}</p>
          </div>
          
          <div className="mt-3 pt-3 border-t border-[#F1F5F9]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-[13px] text-[#64748B]">
                  Đã học
                </span>
              </div>
              <span className="text-[13px] font-medium text-[#020617]">
                {student.completed_sessions || 0}/{totalSessions || 0}  {t('schedule.session_count_unit')}
              </span>
            </div>
            
            <div className="mt-2">
              <Progress 
                value={completionPercentage} 
                className="h-1.5 bg-[#F1F5F9]" 
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentCard; 