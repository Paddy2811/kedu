import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { InputWithPostfix } from "@/components/ui/input-with-postfix";
import { PrefilledInput } from "@/components/ui/prefilled-input";
import { DatePicker } from "@/components/ui/date-picker";
import { Combobox } from "@/components/ui/combobox";
import { Calendar, Clock } from "lucide-react";
import { sessionApi } from "@/api/services/session";
import { showSuccessToast, showErrorToast } from "@/utils/toast";

export default function EditSessionDialog({ 
  open, 
  onOpenChange, 
  session,
  teachers = [],
  onSave 
}) {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({
    sessionName: "",
    date: "",
    duration: "",
    startTime: "",
    endTime: "",
    teacherId: ""
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  // Reset form when dialog opens and populate with session data
  useEffect(() => {
    if (open && session) {
      setFormData({
        sessionName: session.name || "",
        date: session.study_date || "",
        duration: session.duration_per_session ? String(session.duration_per_session) : "",
        startTime: session.start_time || "",
        endTime: session.end_time || "",
        teacherId: session.teacher_id ? String(session.teacher_id) : ""
      });
      setErrors({});
      
      // Debug logging when dialog opens
      console.log('Edit dialog opened with session:', session);
      console.log('Teachers:', teachers);
    }
  }, [open, session, teachers]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleDateChange = (date) => {
    setFormData(prev => ({ ...prev, date }));
    if (errors.date) {
      setErrors(prev => ({ ...prev, date: "" }));
    }
  };

  const handleTeacherChange = (teacherId) => {
    setFormData(prev => ({ ...prev, teacherId }));
    if (errors.teacherId) {
      setErrors(prev => ({ ...prev, teacherId: "" }));
    }
  };

  // Calculate end time based on start time and duration
  const calculateEndTime = (startTime, duration) => {
    if (!startTime || !duration) return "";
    
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + Number(duration);
    const endHours = Math.floor(totalMinutes / 60);
    const endMinutes = totalMinutes % 60;
    
    return `${endHours.toString().padStart(2, '0')}:${endMinutes.toString().padStart(2, '0')}`;
  };

  // Update end time when start time or duration changes
  useEffect(() => {
    if (formData.startTime && formData.duration) {
      const endTime = calculateEndTime(formData.startTime, formData.duration);
      setFormData(prev => ({ ...prev, endTime }));
    }
  }, [formData.startTime, formData.duration]);

  // Validate that date/time is not in the past
  const isDateTimeInPast = (date, startTime) => {
    if (!date || !startTime) return false;
    
    const sessionDateTime = new Date(`${date}T${startTime}`);
    const now = new Date();
    
    return sessionDateTime < now;
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.sessionName.trim()) {
      newErrors.sessionName = t('validation.required_session_name');
    }
    
    if (!formData.date) {
      newErrors.date = t('validation.required_session_date');
    }
    
    if (!formData.duration) {
      newErrors.duration = t('validation.required_session_duration');
    } else if (isNaN(formData.duration) || Number(formData.duration) <= 0) {
      newErrors.duration = t('validation.invalid_duration');
    }
    
    if (!formData.startTime) {
      newErrors.startTime = t('validation.required_session_start_time');
    }
    
    // Check if date/time is in the past
    if (formData.date && formData.startTime && isDateTimeInPast(formData.date, formData.startTime)) {
      newErrors.startTime = t('validation.session_time_past', 'Session time cannot be in the past');
    }
    
    if (!formData.teacherId) {
      newErrors.teacherId = t('validation.required_session_teacher');
    }
    
    // Validate session exists
    if (!session?.id) {
      console.error('Session ID is missing');
      showErrorToast('Session ID is required');
      return false;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    try {
      // Debug logging
      console.log('Form Data:', formData);
      console.log('Session ID:', session?.id);
      console.log('Teachers:', teachers);
      
      // Validate required data
      if (!formData.teacherId) {
        showErrorToast(t('validation.required_session_teacher'));
        return;
      }
      
      if (!session?.id) {
        showErrorToast('Session ID is required');
        return;
      }
      
      // Prepare API data according to the API specification
      const apiData = {
        name: formData.sessionName,
        study_date: formData.date,
        start_time: formData.startTime,
        duration_per_session: Number(formData.duration),
        teacher_id: Number(formData.teacherId)
      };
      
      console.log('API Data:', apiData);
      
      const result = await sessionApi.updateSession(session.id, apiData);
      
      if (result.success) {
        showSuccessToast(t('schedule.edit_session_success', 'Session updated successfully'));
        
        // Call the onSave callback with the updated session data
        onSave({
          ...session,
          name: formData.sessionName,
          study_date: formData.date,
          duration_per_session: Number(formData.duration),
          start_time: formData.startTime,
          end_time: formData.endTime,
          teacher_id: Number(formData.teacherId),
          ...result.data // Include any additional data returned from API
        });
        
        onOpenChange(false);
      } else {
        console.error('API Error:', result.error);
        showErrorToast(result.error || t('schedule.edit_session_error', 'Failed to update session'));
      }
    } catch (error) {
      showErrorToast(t('schedule.edit_session_error', 'Failed to update session'));
      console.error('Error updating session:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] p-6">
        <DialogHeader className="text-left">
          <DialogTitle className="text-lg font-semibold">
            {t('edit_session.edit_session', 'Edit Session')}
          </DialogTitle>
          <p className="text-sm text-muted-foreground mt-1">
            {t('edit_session.edit_session_description', 'Update session information')}
          </p>
        </DialogHeader>

        <div className="space-y-4 my-4">
          {/* Session Number and Session Name */}
          <div className="space-y-2">
            <div className="space-y-1">
              <Label>{t('schedule.session')}</Label>
              <PrefilledInput 
                value={`${t('schedule.session')} ${session?.idx + 1 || 1}`}
                postfix=""
              />
            </div>
            
            <div className="space-y-1">
              <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
                {t('schedule.session_name')}
              </Label>
              <Input
                name="sessionName"
                placeholder={t('schedule.enter_session_name_placeholder', 'Enter session name')}
                value={formData.sessionName}
                onChange={handleChange}
                className="h-10"
              />
              {errors.sessionName && (
                <p className="text-sm text-red-500">{errors.sessionName}</p>
              )}
            </div>
          </div>

          {/* Date and Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
                {t('schedule.date')}
              </Label>
              <div className="relative">
                <DatePicker
                  value={formData.date}
                  onChange={handleDateChange}
                  placeholder={t('schedule.enter_date_placeholder', 'Enter date')}
                  className="h-10"
                  minDate={new Date()} // Prevent selecting past dates
                />
              </div>
              {errors.date && (
                <p className="text-sm text-red-500">{errors.date}</p>
              )}
            </div>
            
            <div className="space-y-1">
              <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
                {t('schedule.duration_per_session')}
              </Label>
              <InputWithPostfix
                name="duration"
                type="text"
                placeholder={t('schedule.enter_duration_placeholder', 'Enter duration')}
                value={formData.duration}
                onChange={handleChange}
                postfix={t('schedule.minute_unit')}
                className="h-10"
              />
              {errors.duration && (
                <p className="text-sm text-red-500">{errors.duration}</p>
              )}
            </div>
          </div>

          {/* Start Time and End Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-3">
              <Label htmlFor="startTime" className="px-1">
                {t('schedule.start_time')}
              </Label>
              <div className="relative">
                <Input
                  type="time"
                  id="startTime"
                  name="startTime"
                  value={formData.startTime}
                  onChange={handleChange}
                  className="bg-background appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-calendar-picker-indicator]:appearance-none h-10 pr-10"
                />
                <Clock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
              {errors.startTime && (
                <p className="text-sm text-red-500">{errors.startTime}</p>
              )}
            </div>
            
            <div className="space-y-1">
              <Label>{t('schedule.end_time')}</Label>
              <div className="relative">
                <PrefilledInput
                  value={formData.endTime}
                  className="h-10 pr-10"
                  postfix=""
                  readOnly
                />
                <Clock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Teacher */}
          <div className="space-y-1">
            <Label className="after:content-['*'] after:ml-0.5 after:text-red-500">
              {t('teacher.teacher')}
            </Label>
            <Combobox
              options={teachers.map(teacher => ({
                value: String(teacher.user_id || teacher.id || teacher.staff_id),
                label: teacher.full_name
              }))}
              value={formData.teacherId}
              onChange={handleTeacherChange}
              placeholder={t('teacher.select_teacher_placeholder', 'Select teacher')}
            />
            {errors.teacherId && (
              <p className="text-sm text-red-500">{errors.teacherId}</p>
            )}
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)} 
            className="h-10 px-8"
            disabled={isLoading}
          >
            {t("common.cancel", "Cancel")}
          </Button>
          <Button 
            onClick={handleSave} 
            className="bg-brand text-white hover:bg-brand/90 h-10 px-8"
            disabled={isLoading}
          >
            {isLoading ? t("common.saving", "Saving...") : t("common.save", "Save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 