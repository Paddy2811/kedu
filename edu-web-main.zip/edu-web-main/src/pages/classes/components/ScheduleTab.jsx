import React, { useState, useEffect, useCallback } from "react";
// import { useNavigate, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Pagination } from "@/components/ui/pagination";
import { Plus, Calendar as CalendarIcon, Clock, Building2, Users2 } from "lucide-react";
import { formatDateDMY } from "@/lib/utils";
import { getSessionStatusBadgeProps } from "@/api/services/class";
import { sessionApi } from "@/api/services/session";
import { staffApi } from "@/api/services/staff";
import { showErrorToast, showSuccessToast } from "@/utils/toast";
import SetupScheduleDialog from "./SetupScheduleDialog";
import CreateSessionDialog from "./CreateSessionDialog";
import EditSessionDialog from "./EditSessionDialog";

export default function ScheduleTab({
  classId,
  classSessionCount,
}) {
  const { t } = useTranslation();
  // const navigate = useNavigate();
  // const { id } = useParams();

  // State for sessions data
  const [sessions, setSessions] = useState([]);
  const [sessionsTotal, setSessionsTotal] = useState(0);
  const [sessionsLoading, setSessionsLoading] = useState(true);
  const [sessionsPage, setSessionsPage] = useState(1);
  const [sessionsPageSize] = useState(10);
  const [showSetupScheduleDialog, setShowSetupScheduleDialog] = useState(false);
  const [showCreateSessionDialog, setShowCreateSessionDialog] = useState(false);
  const [teachers, setTeachers] = useState([]);
  const [showEditSessionDialog, setShowEditSessionDialog] = useState(false);
  const [editingSession, setEditingSession] = useState(null);

  // Fetch sessions data with useCallback to prevent recreation
  const fetchSessions = useCallback(async (page = 1) => {
    if (!classId) return;
    
    setSessionsLoading(true);
    try {
      const result = await sessionApi.getSessionsByClass({
        classId: parseInt(classId),
        page,
        pagesize: sessionsPageSize
      });

      if (result.success) {
        setSessions(result.items);
        setSessionsTotal(result.total);
        setSessionsPage(result.page);
      } else {
        showErrorToast(result.error);
      }
    } catch (error) {
      console.error('Error fetching sessions:', error);
      showErrorToast('Có lỗi xảy ra khi tải danh sách buổi học');
    } finally {
      setSessionsLoading(false);
    }
  }, [classId, sessionsPageSize]);

  // Load sessions only on component mount and when classId changes
  useEffect(() => {
    fetchSessions(1);
  }, [fetchSessions]);

  // Handle page change
  const handlePageChange = (newPage) => {
    setSessionsPage(newPage);
    fetchSessions(newPage);
  };

  // Handle successful schedule creation
  const handleScheduleCreated = async () => {
    // Reload sessions data after successful schedule creation
    await fetchSessions(1);
  };

  // Fetch teachers for the dialog
  const fetchTeachers = useCallback(async () => {
    try {
      const result = await staffApi.getStaff({
        page: 1,
        pagesize: 100,
        role_code: 'TEACHER' // Assuming teachers have TEACHER role
      });

      if (result.success) {
        console.log('Teachers data:', result.items);
        setTeachers(result.items);
      } else {
        showErrorToast(result.error);
      }
    } catch (error) {
      console.error('Error fetching teachers:', error);
      showErrorToast('Có lỗi xảy ra khi tải danh sách giáo viên');
    }
  }, []);

  // Load teachers on component mount
  useEffect(() => {
    fetchTeachers();
  }, [fetchTeachers]);

  // Calculate next session index based on total from API
  const getNextSessionIndex = () => {
    // Use sessionsTotal from API response and increment by 1
    const nextIdx = sessionsTotal;
    
    console.log('Sessions total from API:', sessionsTotal);
    console.log('Next idx:', nextIdx);
    
    return nextIdx;
  };

  // Handle open create session dialog
  const handleOpenCreateSessionDialog = () => {
    setShowCreateSessionDialog(true);
  };

  // Handle create session success
  const handleCreateSession = async () => {
    try {
      // Session was already created in the dialog, just refresh the list
      showSuccessToast('Tạo buổi học thành công');
      await fetchSessions(1); // Refresh sessions list
    } catch (error) {
      console.error('Error refreshing sessions:', error);
      showErrorToast('Có lỗi xảy ra khi tải lại danh sách buổi học');
    }
  };

  return (
    <>
      <div className="w-full rounded-xl border border-[#E2E8F0] bg-white">
        {sessions.length > 0 ? (
          <div className="p-4">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
              <div className="flex items-center gap-1 text-sm text-[#64748B]">
                <span>{t("common.total")}:</span>
                <span className="font-medium text-[#020617]">{sessionsTotal}</span>
                <span>{t("schedule.session_count_unit")}</span>
              </div>
              <div className="flex items-center gap-3 w-full md:w-auto">
                <Button
                  variant="outline"
                  className="border-[#E2E8F0] text-[#0F172A] whitespace-nowrap"
                  onClick={handleOpenCreateSessionDialog}
                >
                  {t("add_session", "Thêm buổi học")}
                </Button>
              </div>
            </div>

            {/* Content */}
            {sessionsLoading ? (
              <div className="flex flex-col gap-4 mb-6">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-[120px] w-full rounded-lg" />
                ))}
              </div>
            ) : (
              <>
                <div className="flex flex-col gap-4 mb-6">
                  {sessions.map((s) => {
                    const badgeProps = getSessionStatusBadgeProps(s.status);
                    return (
                      <div
                        key={s.id}
                        className={`rounded-lg border p-4 flex flex-col gap-4 ${badgeProps.cardBg} ${badgeProps.borderColor}`}
                      >
                        {/* Header row with badges & edit link */}
                        <div className="flex items-start justify-between w-full">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="px-2 py-0.5 text-xs">
                              {t("schedule.session") + " " + s.idx + "/" + classSessionCount}
                            </Badge>
                            <Badge
                              variant="outline"
                              className={`border-0 px-2 py-0.5 text-xs font-medium ${badgeProps.className}`}
                            >
                              {badgeProps.label}
                            </Badge>
                          </div>
                          <Button
                            variant="link"
                            className="text-[#E67364] p-0 h-auto"
                            onClick={() => {
                              setEditingSession(s);
                              setShowEditSessionDialog(true);
                            }}
                            disabled={s.status === "COMPLETED"}
                          >
                            {t("common.edit")}
                          </Button>
                        </div>
                        {/* Title */}
                        <h3 className="text-[16px] font-medium text-[#020617]">{s.name}</h3>
                        {/* Info row */}
                        <div className="flex flex-wrap gap-8 text-sm text-[#64748B]">
                          <div className="flex items-center gap-2">
                            <CalendarIcon className="w-4 h-4" />
                            <span>{formatDateDMY(s.study_date)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4" />
                            <span>{s.start_time}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Building2 className="w-4 h-4" />
                            <span>{s.facility_name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users2 className="w-4 h-4" />
                            <span>{s.teacher_full_name}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                {/* Pagination */}
                {sessionsTotal > sessionsPageSize && (
                  <div className="flex justify-end mt-4">
                    <Pagination
                      currentPage={sessionsPage}
                      totalPages={Math.ceil(sessionsTotal / sessionsPageSize)}
                      onPageChange={handlePageChange}
                    />
                  </div>
                )}
              </>
            )}
          </div>
        ) : (
          <div className="p-6">
            {sessionsLoading ? (
              <div className="flex flex-col gap-4">
                <Skeleton className="h-[120px] w-full rounded-lg" />
                <Skeleton className="h-[120px] w-full rounded-lg" />
                <Skeleton className="h-[120px] w-full rounded-lg" />
              </div>
            ) : (
              <EmptyState
                title={t("schedule.no_schedule", "Lớp hiện chưa có lịch học nào")}
                subtitle={t("schedule.start_journey_by_adding_session", "Bắt đầu hành trình ngay bằng việc tạo lịch học đầu tiên!")}
                buttonText={t("schedule.setup_schedule", "Thiết lập lịch học")}
                buttonIcon={<Plus className="w-4 h-4" />}
                onButtonClick={handleOpenCreateSessionDialog}
                className="py-8"
                noBorder
              />
            )}
          </div>
        )}
      </div>

      {/* Setup Schedule Dialog */}
      <SetupScheduleDialog
        open={showSetupScheduleDialog}
        onOpenChange={setShowSetupScheduleDialog}
        classId={classId}
        onConfirm={handleScheduleCreated}
      />

      {/* Create New Session Dialog */}
      <CreateSessionDialog
        open={showCreateSessionDialog}
        onOpenChange={setShowCreateSessionDialog}
        sessionNumber={getNextSessionIndex()}
        teachers={teachers}
        classId={classId}
        onSave={handleCreateSession}
      />
      {/* Edit Session Dialog */}
      <EditSessionDialog
        open={showEditSessionDialog}
        onOpenChange={setShowEditSessionDialog}
        session={editingSession}
        teachers={teachers}
        onSave={async () => {
          await fetchSessions(1);
          setShowEditSessionDialog(false);
        }}
      />
    </>
  );
} 