import React from "react";
import { useTranslation } from "react-i18next";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { PlaceholderText } from "@/components/ui/placeholder-text";
import { Building2, Calendar, Users, Wallet, GraduationCap, Pencil } from "lucide-react";
import { getClassStatusBadgeProps } from "@/api/services/class";

/**
 * ClassSummaryCard component renders the top summary section of Class Detail page.
 * Props:
 *  - classData: mapped class object
 *  - displayStatus: class status string
 *  - onEdit: edit button handler
 *  - onStartClass: start class handler (only visible in PENDING status)
 *  - activating: boolean loading state for start class action
 */
export default function ClassSummaryCard({ classData, displayStatus, onEdit, onStartClass, activating = false }) {
  const { t } = useTranslation();

  // Helper – progress percentage
  const percentage = classData ? Math.round((classData.completed_sessions / classData.session_count) * 100) : 0;

  // Prepare class info items
  const infoItems = [
    {
      icon: Building2,
      content: (
        <>
          {t("facility.facility")}: {classData.facility_name}
        </>
      ),
    },
    {
      icon: Calendar,
      content: (
        <>
          <span className="font-semibold">{t("registration.opening_date")}: </span>
          <PlaceholderText value={classData.opening_date} />
        </>
      ),
    },
    {
      icon: Users,
      content: (
        <>
          <span>{t("class.class_size")}: </span>
          <span className="font-semibold">
            {classData.current_student_count}/{classData.max_student_count}
          </span>{" "}
          <span>{t("student.students")}</span>
        </>
      ),
    },
    {
      icon: Wallet,
      content: (
        <>
          <span className="font-semibold">{t("finance.price_per_session")}: </span>
          <span>{classData.price_per_session}</span>
        </>
      ),
    },
  ];

  const badgeProps = getClassStatusBadgeProps(displayStatus);

  return (
    <div className="rounded-xl bg-white border border-[#E2E8F0] p-6">
      <div className="flex flex-col gap-5">
        {/* Header */}
        <div className="flex flex-row justify-between items-start w-full">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <h1 className="text-[20px] font-semibold text-[#020617]">{classData.name}</h1>
              <Badge
                variant="outline"
                {...badgeProps}
                className={badgeProps.className + " border-0 px-2.5 py-0.5 text-xs font-semibold"}
              >
                {badgeProps.children}
              </Badge>
            </div>
            <p className="text-sm text-[#64748B]">{classData.code}</p>
          </div>
          <div className="flex gap-3">
            {displayStatus === "PENDING" && (
              <Button className="bg-[#E67364] hover:bg-[#E67364]/90 text-white" onClick={onStartClass} disabled={activating}>
                <GraduationCap className="w-4 h-4 mr-2" />
                {activating ? t("common.processing") : t("class.start_class")}
              </Button>
            )}
            <Button variant="outline" className="border-[#E2E8F0] text-[#0F172A]" onClick={onEdit}>
              <Pencil className="w-4 h-4 mr-2" />
              {t("common.edit")}
            </Button>
          </div>
        </div>

        {/* Teacher */}
        <div className="flex flex-col gap-2">
          <span className="text-sm font-medium text-[#64748B]">{t("teacher.teacher")}</span>
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8 rounded-lg">
              <AvatarImage src={classData.teacher_avatar} alt={classData.teacher_full_name} />
              <AvatarFallback className="rounded-lg">{classData.teacher_initials}</AvatarFallback>
            </Avatar>
            <span className="text-sm text-[#0973DC] font-medium">{classData.teacher_full_name}</span>
          </div>
        </div>

        <hr className="border-[#E2E8F0]" />

        {/* Info & progress */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Info list */}
          <div className="flex flex-col gap-2 lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-2">
              {infoItems.map((item, idx) => {
                const Icon = item.icon;
                const colSpanClass = idx % 2 === 0 ? "lg:col-span-1" : "lg:col-span-2";
                return (
                  <div key={idx} className={`flex items-center gap-2 ${colSpanClass}`}>
                    <Icon className="w-4 h-4 text-[#64748B]" />
                    <span className="text-sm text-[#64748B]">{item.content}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Progress bar */}
          <div className="flex items-center w-full lg:col-span-2">
            <div className="flex flex-col gap-2 w-full">
              <div className="flex justify-between">
                <span className="text-sm text-[#3F3F46]">{t("registration.progress")}</span>
                <span className="text-sm text-[#3F3F46]">
                  {classData.completed_sessions}/{classData.session_count} {t("schedule.session_count_unit")}
                </span>
              </div>
              <Progress value={percentage} className="h-4 bg-[#F4F4F5]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 