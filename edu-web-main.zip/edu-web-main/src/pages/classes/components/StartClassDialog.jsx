import { useTranslation } from "react-i18next";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function StartClassDialog({ 
  open, 
  onOpenChange, 
  onConfirm,
  classData,
  activating = false
}) {
  const { t } = useTranslation();

  // Handle confirm button click
  const handleConfirm = async () => {
    try {
      await onConfirm();
      onOpenChange(false);
    } catch (err) {
      // Error handled by caller toast, keep dialog open
      console.error('Error confirm start class', err);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="w-[550px] max-w-[90vw] p-6 border border-[#E4E4E7] shadow-lg rounded-xl"
        style={{ 
          boxShadow: "0px 4px 6px -4px rgba(16, 24, 40, 0.1), 0px 10px 15px -3px rgba(0, 0, 0, 0.1)"
        }}
      >
        <DialogHeader className="text-left p-0 space-y-1">
          <DialogTitle className="text-xl font-semibold text-[#18181B]">
            {t("start_class_dialog.title")}
          </DialogTitle>
          <DialogDescription className="text-[#71717A] font-normal">
            {t("start_class_dialog.description")}
          </DialogDescription>
        </DialogHeader>
          
        <div className="space-y-3 my-6">
          {/* Class Info Fields */}
          <div className="flex justify-between items-center">
            <div className="text-[#64748B]">{t("teacher.teacher", "Teacher")}</div>
            <div className="text-[#0973DC] font-medium">
              {classData?.teacher_full_name || t("start_class_dialog.default_teacher_name", "Teacher Name")}
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-[#64748B]">{t("registration.opening_date", "Opening date")}</div>
            <div className="text-[#020617] font-medium">
              {classData?.opening_date || t("start_class_dialog.default_opening_date", "22/06/2025")}
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-[#64748B]">{t("student.student_count", "Student count")}</div>
            <div className="text-[#020617] font-medium">
              {classData?.current_student_count || 0}/{classData?.max_student_count || 16} {t("student.students", "students")}
            </div>
          </div>
          
          <div className="flex justify-between">
            <div className="text-[#64748B]">{t("schedule.schedule", "Schedule")}</div>
            <div className="text-right">
              <div className="text-[#020617] font-medium">{t("start_class_dialog.default_schedule_1", "Monday, 14:00 - 16:00")}</div>
              <div className="text-[#020617] font-medium mt-2">{t("start_class_dialog.default_schedule_2", "Friday, 14:00 - 16:00")}</div>
            </div>
          </div>
        </div>
        
        <DialogFooter className="flex justify-end gap-3 p-0">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            className="h-10 px-4 py-2 border-[#E4E4E7] text-[#18181B] rounded-md font-medium"
          >
            {t("common.cancel", "Cancel")}
          </Button>
          <Button 
            className="h-10 px-4 py-2 bg-[#E67364] hover:bg-[#E67364]/90 text-white rounded-md font-medium"
            onClick={handleConfirm}
            disabled={activating}
          >
            {activating ? t('common.processing', 'Processing...') : t('class.start_class', 'Start class')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
} 