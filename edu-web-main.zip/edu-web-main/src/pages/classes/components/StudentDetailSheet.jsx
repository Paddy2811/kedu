import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle 
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  User,
  Phone, 
  Mail, 
  Calendar, 
  FileText,
  BookText,
  Clock,
  GraduationCap,
  AlertCircle,
  BarChart3,
  Copy,
  CheckCircle,
  Building2
} from "lucide-react";
import { formatDateDMY } from "@/lib/utils";
import { classApi } from "@/api/services/class";
import { Progress } from "@/components/ui/progress";
import { PlaceholderText } from "@/components/ui/placeholder-text";
import { showSuccessToast } from "@/utils/toast";

// Mock data for testing when API fails or is not available
const MOCK_STUDENT_DATA = {
  id: "mock-student-1",
  full_name: "Nguyễn Minh Anh",
  student_code: "ST00123",
  avatar_url: "",
  guardian_name: "Nguyễn Văn Bình",
  phone: "0912345678",
  email: "minhanh@example.com",
  date_of_birth: "2010-05-15",
  completed_sessions: 12,
  total_sessions: 36,
  course_name: "Ballet Nâng Cao",
  schedule: "Thứ 2, Thứ 4 (14:00 - 16:00)",
  enrollment_date: "2023-09-01",
  performance_grade: "Xuất sắc",
  teacher_name: "Trần Văn Minh",
  attendance: [
    {
      session_number: 15,
      total_sessions: 36,
      date: "2023-12-15",
      time: "14:00 - 16:00",
      status: "PRESENT",
      name: "Múa Ballet nâng cao có những yêu cầu gì?",
      facility_name: "Cơ sở Cầu Giấy"
    },
    {
      session_number: 14,
      total_sessions: 36,
      date: "2023-12-12",
      time: "14:00 - 16:00",
      status: "PRESENT",
      name: "Kỹ thuật xoay người trong múa Ballet",
      facility_name: "Cơ sở Cầu Giấy"
    },
    {
      session_number: 13,
      total_sessions: 36,
      date: "2023-12-08",
      time: "14:00 - 16:00",
      status: "ABSENT",
      name: "Các tư thế cơ bản trong múa Ballet",
      facility_name: "Cơ sở Cầu Giấy"
    },
    {
      session_number: 12,
      total_sessions: 36,
      date: "2023-12-05",
      time: "14:00 - 16:00",
      status: "PRESENT",
      name: "Lịch sử và nguồn gốc của múa Ballet",
      facility_name: "Cơ sở Cầu Giấy"
    }
  ]
};

// Mock data for different students
const MOCK_STUDENTS = {
  "1": {
    ...MOCK_STUDENT_DATA,
    id: "1",
    full_name: "Nguyễn Minh Anh",
    student_code: "ST00123",
    completed_sessions: 12,
    total_sessions: 36,
    attendance: [
      {
        session_number: 15,
        total_sessions: 36,
        date: "2023-12-15",
        time: "14:00 - 16:00",
        status: "PRESENT",
        name: "Múa Ballet nâng cao có những yêu cầu gì?"
      },
      {
        session_number: 14,
        total_sessions: 36,
        date: "2023-12-12",
        time: "14:00 - 16:00",
        status: "PRESENT",
        name: "Kỹ thuật xoay người trong múa Ballet"
      },
      {
        session_number: 13,
        total_sessions: 36,
        date: "2023-12-08",
        time: "14:00 - 16:00",
        status: "ABSENT",
        name: "Các tư thế cơ bản trong múa Ballet"
      }
    ]
  },
  "2": {
    ...MOCK_STUDENT_DATA,
    id: "2",
    full_name: "Trần Hoàng Nam",
    student_code: "ST00124",
    guardian_name: "Trần Văn Hùng",
    phone: "0923456789",
    email: "hoangnam@example.com",
    completed_sessions: 14,
    total_sessions: 36,
    performance_grade: "Tốt",
    attendance: [
      {
        session_number: 15,
        total_sessions: 36,
        date: "2023-12-15",
        time: "14:00 - 16:00",
        status: "PRESENT",
        name: "Múa Ballet nâng cao có những yêu cầu gì?"
      },
      {
        session_number: 14,
        total_sessions: 36,
        date: "2023-12-12",
        time: "14:00 - 16:00",
        status: "PRESENT",
        name: "Kỹ thuật xoay người trong múa Ballet"
      },
      {
        session_number: 13,
        total_sessions: 36,
        date: "2023-12-08",
        time: "14:00 - 16:00",
        status: "PRESENT",
        name: "Các tư thế cơ bản trong múa Ballet"
      }
    ]
  },
  "3": {
    ...MOCK_STUDENT_DATA,
    id: "3",
    full_name: "Lê Thị Hương",
    student_code: "ST00125",
    guardian_name: "Lê Văn Đức",
    phone: "0934567890",
    email: "thihuong@example.com",
    completed_sessions: 10,
    total_sessions: 36,
    performance_grade: "Khá",
    attendance: [
      {
        session_number: 15,
        total_sessions: 36,
        date: "2023-12-15",
        time: "14:00 - 16:00",
        status: "ABSENT",
        name: "Múa Ballet nâng cao có những yêu cầu gì?"
      },
      {
        session_number: 14,
        total_sessions: 36,
        date: "2023-12-12",
        time: "14:00 - 16:00",
        status: "PRESENT",
        name: "Kỹ thuật xoay người trong múa Ballet"
      },
      {
        session_number: 13,
        total_sessions: 36,
        date: "2023-12-08",
        time: "14:00 - 16:00",
        status: "ABSENT",
        name: "Các tư thế cơ bản trong múa Ballet"
      }
    ]
  }
};

const StudentDetailSheet = ({ open, onOpenChange, studentId, classId, classData }) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [studentData, setStudentData] = useState(null);
  const [attendanceData, setAttendanceData] = useState([]);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [activeTab, setActiveTab] = useState("attendance");
  const [classInfo, setClassInfo] = useState(null);

  useEffect(() => {
    // Set class data from props if available
    if (classData) {
      setClassInfo(classData);
    }
  }, [classData]);

  useEffect(() => {
    const fetchData = async () => {
      if (!open || !studentId || !classId) return;
      
      setLoading(true);
      try {
        // Fetch student details from the API
        const response = await classApi.getClassStudentDetail(classId, studentId);
        
        if (response.success && response.data) {
          setStudentData(response.data);
          
          // If there's attendance data, set it
          if (response.data.attendance) {
            setAttendanceData(response.data.attendance);
          }
        } else {
          console.warn("Failed to fetch student details from API, using mock data");
          // Use mock data if API fails
          const mockStudent = MOCK_STUDENTS[studentId] || MOCK_STUDENT_DATA;
          setStudentData(mockStudent);
          setAttendanceData(mockStudent.attendance || []);
        }

        // If we don't have class data from props, fetch it
        if (!classInfo) {
          try {
            const classResponse = await classApi.getClassById(classId);
            if (classResponse.success && classResponse.data) {
              setClassInfo(classResponse.data);
            }
          } catch (error) {
            console.error("Error fetching class details:", error);
          }
        }
      } catch (error) {
        console.error("Error fetching student details:", error);
        // Use mock data on error
        console.warn("Using mock data due to API error");
        const mockStudent = MOCK_STUDENTS[studentId] || MOCK_STUDENT_DATA;
        setStudentData(mockStudent);
        setAttendanceData(mockStudent.attendance || []);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [open, studentId, classId, classInfo]);

  // Calculate attendance percentage
  const getAttendanceStats = () => {
    if (!studentData || !studentData.completed_sessions || !studentData.total_sessions) {
      return {
        percentage: 0,
        present: 0,
        absent: 0,
        total: 0
      };
    }
    
    const present = studentData.completed_sessions || 0;
    const total = studentData.total_sessions || 0;
    const absent = total - present;
    const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
    
    return {
      percentage,
      present,
      absent,
      total
    };
  };

  // Get the total sessions from class data or fallback to student data
  const getTotalSessions = () => {
    if (classInfo && classInfo.total_sessions) {
      return classInfo.total_sessions;
    }
    
    if (studentData && studentData.total_sessions) {
      return studentData.total_sessions;
    }
    
    return 36; // Default fallback
  };

  const totalSessions = getTotalSessions();
  const attendanceStats = getAttendanceStats();

  // Get initials from full name
  const getInitials = (name) => {
    if (!name) return '';
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleCopyToClipboard = async (text, type) => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'phone') {
        setCopiedPhone(true);
        setTimeout(() => setCopiedPhone(false), 2000);
        showSuccessToast(t('success.copy_phone_success'));
      } else if (type === 'email') {
        setCopiedEmail(true);
        setTimeout(() => setCopiedEmail(false), 2000);
        showSuccessToast(t('success.copy_email_success'));
      }
    } catch (error) {
      console.error('Copy to clipboard error:', error);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-md md:max-w-xl lg:max-w-2xl xl:max-w-3xl w-full overflow-y-auto">
        <SheetHeader className="mb-6">
          <SheetTitle className="text-xl font-semibold text-[#020617]">
            {t('student.student_detail')}
          </SheetTitle>
        </SheetHeader>

        {loading ? (
          <div className="space-y-6">
            <div className="flex gap-4 items-center">
              <Skeleton className="h-16 w-16 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-4 w-28" />
              </div>
            </div>
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-36 w-full" />
          </div>
        ) : (
          <>
            {/* Student Basic Info - Updated to match image layout */}
            <div className="flex items-start gap-4 mb-6 border border-[#E2E8F0] px-4 py-5 rounded-lg">
              <Avatar className="h-16 w-16">
                <AvatarImage src={studentData?.avatar_url} alt={studentData?.full_name} />
                <AvatarFallback className="bg-[#E67364] text-white">
                  {getInitials(studentData?.full_name)}
                </AvatarFallback>
              </Avatar>
              <div className="w-full">
                <h3 className="text-lg font-semibold text-[#0973DC] mb-2">
                  {studentData?.full_name || <PlaceholderText />}
                </h3>
                
                <div className="flex flex-wrap gap-9">
                  <div>
                    <span className="text-[13px] text-[#64748B]">{t('personal.student_code')}</span>
                    <div className="text-[13px] text-[#0F172A] mt-1">
                      {studentData?.student_code || <PlaceholderText />}
                    </div>
                  </div>
                  
                  <div>
                    <span className="text-[13px] text-[#64748B]">{t('personal.phone')}</span>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-[13px] text-[#0973DC]">
                        {studentData?.phone || <PlaceholderText />}
                      </span>
                      <button 
                        onClick={() => handleCopyToClipboard(studentData?.phone, 'phone')}
                        className="p-0.5 hover:bg-[#F8FAFC] rounded"
                      >
                        {copiedPhone ? (
                          <CheckCircle className="w-3.5 h-3.5 text-[#008A2E]" />
                        ) : (
                          <Copy className="w-3.5 h-3.5 text-[#64748B]" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <span className="text-[13px] text-[#64748B]">{t('personal.email')}</span>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-[13px] text-[#0973DC]">
                        {studentData?.email || "---"}
                      </span>
                      {studentData?.email && (
                        <button 
                          onClick={() => handleCopyToClipboard(studentData?.email, 'email')}
                          className="p-0.5 hover:bg-[#F8FAFC] rounded"
                        >
                          {copiedEmail ? (
                            <CheckCircle className="w-3.5 h-3.5 text-[#008A2E]" />
                          ) : (
                            <Copy className="w-3.5 h-3.5 text-[#64748B]" />
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="bg-[#F8FAFC] p-1 h-auto rounded-lg mb-4 border border-[#E2E8F0]">
                <TabsTrigger 
                  value="attendance"
                  className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
                >
                  Chuyên cần
                </TabsTrigger>
                <TabsTrigger 
                  value="learning"
                  className="text-[13px] data-[state=active]:bg-white data-[state=active]:text-[#0F172A] data-[state=active]:shadow-sm px-3 py-2 rounded-md"
                >
                  Học tập
                </TabsTrigger>
              </TabsList>

              <TabsContent value="attendance" className="space-y-6">
                {/* Attendance Stats */}
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="text-sm font-medium text-[#64748B]">
                      {t('attendance')}
                    </h4>
                  </div>
                  
                  <div className="bg-[#F8FAFC] rounded-lg p-4 mb-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-[#64748B]">{t('attendance_rate')}</span>
                      <span className="text-sm font-medium text-[#0F172A]">{attendanceStats.percentage}%</span>
                    </div>
                    <Progress value={attendanceStats.percentage} className="h-2" />
                    
                    <div className="grid grid-cols-3 gap-3 mt-4">
                      <div className="flex flex-col items-center p-2 bg-white rounded border border-[#E2E8F0]">
                        <span className="text-xs text-[#64748B]">{t('present')}</span>
                        <span className="text-base font-medium text-[#0F172A]">{attendanceStats.present}</span>
                      </div>
                      <div className="flex flex-col items-center p-2 bg-white rounded border border-[#E2E8F0]">
                        <span className="text-xs text-[#64748B]">{t('absent')}</span>
                        <span className="text-base font-medium text-[#0F172A]">{attendanceStats.absent}</span>
                      </div>
                      <div className="flex flex-col items-center p-2 bg-white rounded border border-[#E2E8F0]">
                        <span className="text-xs text-[#64748B]">{t('common.total')}</span>
                        <span className="text-base font-medium text-[#0F172A]">{attendanceStats.total}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Attendance */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-[#64748B] mb-3">
                    {t('recent_attendance')}
                  </h4>
                  
                  <div className="space-y-3">
                    {attendanceData && attendanceData.length > 0 ? (
                      attendanceData.slice(0, 3).map((session, index) => (
                        <div key={index} className="flex items-start gap-4 p-4 bg-white border border-[#EDEDED] rounded-lg">
                          <div className="flex-1">
                            <div className="mb-2">
                              <Badge 
                                variant="outline"
                                className="bg-[#F1F5F9] text-[#64748B] font-medium px-2 py-0.5 text-xs"
                              >
                                Buổi {session.session_number} / {totalSessions}
                              </Badge>
                            </div>
                            <h5 className="text-sm font-medium text-[#0F172A] mb-2 line-clamp-2">
                              {session.name || `Múa Ballet nâng cao có những yêu cầu gì?`}
                            </h5>
                            <div className="flex flex-wrap items-center gap-x-10 gap-y-2 text-xs text-[#64748B]">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-3.5 w-3.5 text-[#64748B]" />
                                <span>{session.date ? formatDateDMY(session.date) : ''}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Clock className="h-3.5 w-3.5 text-[#64748B]" />
                                <span>{session.time || ''}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Building2 className="h-3.5 w-3.5 text-[#64748B]" />
                                <span>{classInfo?.facility?.name || classInfo?.facility_name || session.facility_name || 'Cơ sở Cầu Giấy'}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <User className="h-3.5 w-3.5 text-[#64748B]" />
                                <span>{classInfo?.teacher?.name || classInfo?.teacher_name || session.teacher_name || studentData?.teacher_name || 'Giáo viên'}</span>
                              </div>
                            </div>
                          </div>
                          <Badge 
                            variant="outline"
                            className={`border-0 ${
                              session.status === 'PRESENT' 
                                ? 'bg-[#ECFDF2] text-[#008A2E]' 
                                : 'bg-[#FFF1F2] text-[#E02D3C]'
                            }`}
                          >
                            {session.status === 'PRESENT' ? t('present') : t('absent')}
                          </Badge>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-4 text-sm text-[#64748B]">
                        {t('no_attendance_data')}
                      </div>
                    )}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="learning" className="space-y-6">
                {/* Academic Information */}
                <div>
                  <h4 className="text-sm font-medium text-[#64748B] mb-3">
                    {t('academic_information')}
                  </h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 border border-[#E2E8F0] rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <BookText className="h-4 w-4 text-[#64748B]" />
                        <span className="text-xs text-[#64748B]">{t('course.course')}</span>
                      </div>
                      <p className="text-sm font-medium text-[#0F172A]">
                        {studentData?.course_name || <PlaceholderText />}
                      </p>
                    </div>
                    
                    <div className="p-3 border border-[#E2E8F0] rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-4 w-4 text-[#64748B]" />
                        <span className="text-xs text-[#64748B]">{t('schedule.schedule')}</span>
                      </div>
                      <p className="text-sm font-medium text-[#0F172A]">
                        {studentData?.schedule || <PlaceholderText />}
                      </p>
                    </div>
                    
                    <div className="p-3 border border-[#E2E8F0] rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <GraduationCap className="h-4 w-4 text-[#64748B]" />
                        <span className="text-xs text-[#64748B]">{t('enrollment_date')}</span>
                      </div>
                      <p className="text-sm font-medium text-[#0F172A]">
                        {studentData?.enrollment_date ? formatDateDMY(studentData.enrollment_date) : <PlaceholderText />}
                      </p>
                    </div>
                    
                    <div className="p-3 border border-[#E2E8F0] rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <BarChart3 className="h-4 w-4 text-[#64748B]" />
                        <span className="text-xs text-[#64748B]">{t('performance')}</span>
                      </div>
                      <p className="text-sm font-medium text-[#0F172A]">
                        {studentData?.performance_grade || <PlaceholderText />}
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
};

export default StudentDetailSheet; 