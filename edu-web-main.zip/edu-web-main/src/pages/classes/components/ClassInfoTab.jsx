import React from "react";
import { useTranslation } from "react-i18next";
import { Skeleton } from "@/components/ui/skeleton";
import { PlaceholderText } from "@/components/ui/placeholder-text";
import { EmptyState } from "@/components/ui/empty-state";
import { GraduationCap, BookText, Building2 } from "lucide-react";

/**
 * ClassInfoTab renders the course / tuition information of a class.
 * Props:
 *  - loading (bool): loading state
 *  - classData (object): mapped class data
 */
export default function ClassInfoTab({ loading, classData }) {
  const { t } = useTranslation();

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="w-full h-[120px] rounded-xl" />
        <Skeleton className="w-full h-[180px] rounded-xl" />
        <Skeleton className="w-full h-[100px] rounded-xl" />
      </div>
    );
  }

  if (!classData) {
    return (
      <EmptyState title={t("errors.load_class_detail") ?? "Load error"} noBorder className="py-8" />
    );
  }

  return (
    <div className="space-y-4">
      <div className="w-full rounded-xl border border-[#E2E8F0] bg-white px-6 py-4">
        <div className="flex items-center gap-2 mb-4">
          <GraduationCap className="w-4 h-4 text-[#0F172A]" />
          <h3 className="text-[15px] font-medium text-[#0F172A]">{t("course.course_information")}</h3>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <InfoItem label={t("course.course")} value={classData.course_name} isLink link={`/courses/${classData.course_id}`} />
          <InfoItem label={t("subject.subject")} value={classData.subject_name} />
          <InfoItem label={t("facility.facility")} value={classData.facility_name} />
          <InfoItem label={t("schedule.total_sessions_label")} value={`${classData.session_count} ${t("schedule.session_count_unit")}`} />
          <InfoItem label={t("finance.price_per_session")} value={classData.price_per_session} />
          <InfoItem label={t("finance.tuition_fee")} value={classData.tuition_fee} />
          <InfoItem label={t("student.student_count")} value={`${classData.current_student_count}/${classData.max_student_count} ${t("student.students")}`} />
          <InfoItem label={t("registration.opening_date")} value={classData.opening_date} />
        </div>
      </div>
    </div>
  );
}

function InfoItem({ label, value, isLink = false, link = "" }) {
  return (
    <div>
      <span className="text-[13px] text-[#64748B]">{label}</span>
      <div
        className={`text-[13px] mt-1 ${isLink ? "text-[#0973DC] cursor-pointer hover:underline" : "text-[#0F172A]"}`}
        onClick={() => {
          if (isLink && link) {
            window.location.href = link;
          }
        }}
      >
        <PlaceholderText value={value} />
      </div>
    </div>
  );
} 