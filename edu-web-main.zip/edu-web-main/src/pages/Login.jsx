import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";

// Components
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

// Hooks
import { useAuth } from "../contexts/auth.hooks";

// Form validation
const validateForm = (username, password) => {
  const errors = {};
  
  if (!username.trim()) {
    errors.username = "username_required";
  }
  
  if (!password) {
    errors.password = "password_required";
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export default function Login() {
  // State
  const [formData, setFormData] = useState({
    username: "",
    password: ""
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  
  // Hooks
  const { login } = useAuth();
  const { t } = useTranslation();

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user types
    if (formErrors[name]) {
      setFormErrors(prev => ({
        ...prev,
        [name]: null
      }));
    }
  };

  // Toggle password visibility
  const togglePasswordVisibility = () => {
    setShowPassword(prev => !prev);
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate form
    const { isValid, errors } = validateForm(formData.username, formData.password);
    
    if (!isValid) {
      setFormErrors(errors);
      return;
    }

    setLoading(true);

    try {
      await login(formData.username, formData.password);
    } catch (error) {
      console.error('Login error:', error);
      toast.error(t('errors.login_failed') || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-screen h-screen flex items-center justify-center bg-[#343F4A]">
      <div className="bg-white rounded-xl shadow-lg px-10 py-8 w-full max-w-md">
        {/* Logo + Brand */}
        <div className="flex items-center mb-6">
          <img
            src="/images/logo.png"
            alt="logo"
            className="h-6 w-auto mr-2"
          />
          <span className="font-bold text-xl text-[#1F2329]">K-EDU</span>
        </div>
        
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-[#1F2329] mb-1">{t('auth.login')}</h2>
          <p className="text-[#1F2329]/50 text-base">{t('auth.login_description')}</p>
        </div>
        
        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Username Field */}
          <div>
            <Label htmlFor="username" className="text-sm font-medium text-[#1F2329] mb-1">
              {t('auth.username')}<span className="text-red-500">*</span>
            </Label>
            <Input
              id="username"
              name="username"
              type="text"
              className="w-full border border-[#D0D3D6] rounded-md px-3 py-2 text-[#1F2329] focus:outline-none focus:ring-2 focus:ring-brand text-sm"
              placeholder={t('auth.username_placeholder')}
              value={formData.username}
              onChange={handleChange}
              disabled={loading}
              aria-invalid={!!formErrors.username}
            />
            {formErrors.username && (
              <p className="text-red-500 text-xs mt-1">{t(formErrors.username)}</p>
            )}
          </div>
          
          {/* Password Field */}
          <div>
            <Label htmlFor="password" className="text-sm font-medium text-[#1F2329] mb-1">
              {t('auth.password')}<span className="text-red-500">*</span>
            </Label>
            <div className="relative">
              <Input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                className="w-full border border-[#D0D3D6] rounded-md px-3 py-2 text-[#1F2329] focus:outline-none focus:ring-2 focus:ring-brand text-sm pr-10"
                placeholder={t('auth.password_placeholder')}
                value={formData.password}
                onChange={handleChange}
                disabled={loading}
                aria-invalid={!!formErrors.password}
              />
              <button
                type="button"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700"
                tabIndex={-1}
                onClick={togglePasswordVisibility}
                aria-label={showPassword ? t('auth.hide_password') : t('auth.show_password')}
                disabled={loading}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
            {formErrors.password && (
              <p className="text-red-500 text-xs mt-1">{t(formErrors.password)}</p>
            )}
          </div>
          
          {/* Forgot Password */}
          <div className="flex justify-end">
            <button 
              type="button" 
              className="text-brand text-xs font-medium hover:underline bg-transparent border-none p-0 cursor-pointer"
              disabled={loading}
            >
              {t('auth.forgot_password')}
            </button>
          </div>
          
          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full bg-brand text-white rounded-lg py-2 font-semibold text-base mt-2 hover:bg-brand-hover transition disabled:opacity-60"
            disabled={loading}
          >
            {loading ? t('auth.logging_in') : t('auth.login_button')}
          </Button>
        </form>
      </div>
    </div>
  );
} 