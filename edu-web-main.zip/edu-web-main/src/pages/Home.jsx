import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useAuth } from '../contexts/auth.hooks';
import { useNavigate } from 'react-router-dom';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Clock, Users, Building, User, UserRoundCheck, UserRoundPlus } from "lucide-react";
import MainLayout from "../components/layout/main-layout";
import { PageContainer } from "@/components/page-container";
import { EmptyState } from "@/components/ui/empty-state";

function Home() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // Toggle state to show/hide data (for demo purposes)
  const [showData, setShowData] = useState({
    upcomingClasses: false,
    recentActivities: false,
    notifications: false
  });

  // Handle attendance check navigation
  const handleAttendanceCheck = (classItem) => {
    // Get today's date in YYYY-MM-DD format for the date parameter
    const today = new Date().toISOString().split('T')[0];
    
    // Navigate to attendance check page with query parameters
    navigate('/attendance', { 
      state: {
        classId: classItem.id,
        date: today,
        facilityId: classItem.facilityId,
        sessionId: classItem.sessionId,
        autoCheck: true
      }
    });
  };

  // Mock data for upcoming classes
  const upcomingClasses = [
    {
      id: "1",
      code: "BF12",
      title: "Múa Ballet nâng cao có những yêu cầu gì?",
      time: "8:00 - 10:00",
      facility: "Cơ Sở Cửa Bắc",
      facilityId: "FB1",
      teacher: "Trương Minh Tuấn",
      studentCount: "8/16",
      session: "1/36",
      sessionId: "S123",
    },
    {
      id: "2",
      code: "BF12",
      title: "Múa Ballet nâng cao có những yêu cầu gì?",
      time: "8:00 - 10:00",
      facility: "Cơ Sở Cửa Bắc",
      facilityId: "FB1",
      teacher: "Trương Minh Tuấn",
      studentCount: "8/16",
      session: "1/36",
      sessionId: "S124",
    },
    {
      id: "3",
      code: "BF12",
      title: "Múa Ballet nâng cao có những yêu cầu gì?",
      time: "8:00 - 10:00",
      facility: "Cơ Sở Cửa Bắc",
      facilityId: "FB1",
      teacher: "Trương Minh Tuấn",
      studentCount: "8/16",
      session: "1/36",
      sessionId: "S125",
    }
  ];

  // Mock data for recent activities
  const recentActivities = [
    {
      id: "1", 
      type: "course",
      content: 'Phạm Thị B đăng ký khoá "Tiếng Anh giao tiếp"',
      time: "5 phút trước",
    },
    {
      id: "2", 
      type: "course",
      content: 'Phạm Thị B đăng ký khoá "Tiếng Anh giao tiếp"',
      time: "5 phút trước",
    }
  ];

  // Mock data for notifications
  const notifications = [
    {
      id: "1",
      type: "registration",
      title: "Đăng ký mới",
      facility: "Cơ Sở Cửa Bắc",
      time: "5 phút trước"
    },
    {
      id: "2",
      type: "registration",
      title: "Đăng ký mới",
      facility: "Cơ Sở Cửa Bắc",
      time: "5 phút trước"
    },
    {
      id: "3",
      type: "registration",
      title: "Đăng ký mới",
      facility: "Cơ Sở Cửa Bắc",
      time: "5 phút trước"
    },
    {
      id: "4",
      type: "registration",
      title: "Đăng ký mới",
      facility: "Cơ Sở Cửa Bắc",
      time: "5 phút trước"
    },
    {
      id: "5",
      type: "registration",
      title: "Đăng ký mới",
      facility: "Cơ Sở Cửa Bắc",
      time: "5 phút trước"
    }
  ];

  return (
    <MainLayout>
      <PageContainer>
        {/* Header section */}
        <div className="flex flex-col gap-4 w-full mb-6">
          <div className="flex justify-between items-center">
            <div className="flex flex-col">
              <h1 className="text-2xl font-semibold text-slate-900">
                {t("home.hello")}, {user?.full_name || "Trần Thanh Long"}
              </h1>
              <p className="text-base font-normal text-zinc-500">
                {t("home.dashboard_subtitle")}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Button className="bg-[#E67364] hover:bg-[#E67364]/90 text-white flex items-center gap-2" 
                onClick={() => navigate('/attendance')}>
                <UserRoundCheck />
                {t("attendance.attendance", "Điểm danh")}
              </Button>
              <Button 
                variant="outline" 
                className="text-slate-900 border-slate-200 flex items-center gap-2"
                onClick={() => navigate('/register')}
              >
                <UserRoundPlus />
                {t("registration.register_student")}
              </Button>
            </div>
          </div>
        </div>
        
        {/* Main content with 2:1 ratio */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column (2/3) - Stats, Upcoming Classes, Recent Activities */}
          <div className="lg:col-span-2 flex flex-col gap-6">
            {/* Stats cards */}
            <div className="flex flex-row gap-4">
              <Card className="w-full p-4 flex items-center gap-6 border-slate-200 shadow-none">
                <div className="flex flex-col gap-1.5">
                  <span className="text-2xl font-semibold text-slate-900">28</span>
                  <span className="text-sm text-zinc-500">{t("home.students_today")}</span>
                </div>
              </Card>
              <Card className="w-full p-4 flex items-center gap-6 border-slate-200 shadow-none">
                <div className="flex flex-col gap-1.5">
                  <span className="text-2xl font-semibold text-slate-900">6/8</span>
                  <span className="text-sm text-zinc-500">{t("home.classes_today")}</span>
                </div>
              </Card>
            </div>
            
            {/* Upcoming classes */}
            <Card className="border-slate-200 px-6 py-4 shadow-none">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-slate-900">
                  {t("home.upcoming_classes")}
                </h2>
                <Button 
                  variant="link" 
                  className="text-[#E67364] p-0"
                  onClick={() => setShowData(prev => ({...prev, upcomingClasses: !prev.upcomingClasses}))}
                >
                  {showData.upcomingClasses ? t("home.hide") : t("home.view_all")}
                </Button>
              </div>
              
              {showData.upcomingClasses && upcomingClasses.length > 0 ? (
                <div className="flex flex-col gap-4">
                  {upcomingClasses.map((classItem) => (
                    <Card key={classItem.id} className="p-4 border-slate-200 shadow-none">
                      <div className="flex flex-col gap-2 relative">
                        <div className="absolute top-1/2 right-0 -translate-y-1/2 mr-1">
                          <Button 
                            variant="outline" 
                            title={t("home.check_attendance")}
                            onClick={() => handleAttendanceCheck(classItem)}
                          >
                            <UserRoundCheck />
                            <span>{t("home.check_attendance")}</span>
                          </Button>
                        </div>
                        <div className="flex gap-2 items-center pr-10">
                          <span className="py-0.5 px-2.5 border border-zinc-200 text-xs font-semibold rounded">
                            {classItem.code}
                          </span>
                          <Badge className="bg-blue-50 hover:bg-blue-50 text-blue-600 font-semibold text-xs">
                            {t("schedule.session_count", "Buổi")} {classItem.session}
                          </Badge>
                        </div>
                        
                        <div className="flex flex-col">
                          <h3 className="font-medium text-base text-slate-900">
                            {classItem.title}
                          </h3>
                        </div>

                        <div className="flex flex-row gap-4">
                          <div className="flex items-center gap-2 w-1/3">
                            <Clock size={14} className="text-slate-500" />
                            <span className="text-xs text-slate-500">{classItem.time}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Building size={14} className="text-zinc-500" />
                            <span className="text-xs text-slate-500">{classItem.facility}</span>
                          </div>
                        </div>

                        <div className="flex flex-row gap-4">
                          <div className="flex items-center gap-2 w-1/3">
                            <User size={14} className="text-zinc-500" />
                            <span className="text-xs text-slate-500">{classItem.teacher}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users size={14} className="text-slate-500" />
                            <span className="text-xs text-slate-500">
                              {classItem.studentCount} {t("student.students", "học viên")}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title={t("home.no_upcoming_classes")}
                  noBorder={true}
                />
              )}
            </Card>

            {/* Recent Activities - moved from right to left column */}
            <Card className="border-slate-200 px-6 py-4 shadow-none">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold text-slate-900">
                  {t("home.recent_activities")}
                </h2>
                <Button 
                  variant="link" 
                  className="text-[#E67364] p-0"
                  onClick={() => setShowData(prev => ({...prev, recentActivities: !prev.recentActivities}))}
                >
                  {showData.recentActivities ? t("home.hide") : t("home.view_all")}
                </Button>
              </div>
              
              {showData.recentActivities && recentActivities.length > 0 ? (
                <div className="flex flex-col">
                  {recentActivities.map((activity, index) => (
                    <React.Fragment key={activity.id}>
                      <div className="flex py-6">
                        <div className="w-8 h-8 rounded-full bg-blue-50 mr-4 flex items-center justify-center">
                          <Users size={14} className="text-blue-600" />
                        </div>
                        <div className="flex flex-1 justify-between">
                          <div className="flex flex-col">
                            <p className="font-medium text-sm text-slate-900">
                              {activity.content}
                            </p>
                            <Badge className="w-fit mt-1 bg-blue-50 hover:bg-blue-50 text-blue-600 font-semibold text-xs">
                              {t("course.course", "Khoá học")}
                            </Badge>
                          </div>
                          <span className="text-xs text-slate-500">
                            {activity.time}
                          </span>
                        </div>
                      </div>
                      {index < recentActivities.length - 1 && <Separator />}
                    </React.Fragment>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title={t("home.no_recent_activities")}
                  noBorder={true}
                />
              )}
            </Card>
          </div>

          {/* Right column (1/3) - Only Notifications */}
          <div className="lg:col-span-1">
            {/* Notifications */}
            <Card className="border-slate-200 px-6 py-4 h-full shadow-none">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold text-slate-900">
                  {t("home.notifications")}
                </h2>
                <Button 
                  variant="link" 
                  className="text-[#E67364] p-0"
                  onClick={() => setShowData(prev => ({...prev, notifications: !prev.notifications}))}
                >
                  {showData.notifications ? t("home.hide") : t("home.view_all")}
                </Button>
              </div>
              
              {showData.notifications && notifications.length > 0 ? (
                <div className="flex flex-col">
                  {notifications.slice(0, 5).map((notification, index) => (
                    <React.Fragment key={notification.id}>
                      <div className="flex py-4">
                        <div className="w-8 h-8 rounded-full bg-blue-50 mr-3 flex items-center justify-center">
                          <Users size={14} className="text-blue-600" />
                        </div>
                        <div className="flex flex-1 justify-between">
                          <div className="flex flex-col">
                            <span className="font-medium text-sm text-slate-900">
                              {notification.title}
                            </span>
                            <span className="text-xs text-slate-500">
                              {notification.facility}
                            </span>
                          </div>
                          <span className="text-xs text-slate-500">
                            {notification.time}
                          </span>
                        </div>
                      </div>
                      {index < notifications.slice(0, 5).length - 1 && <Separator />}
                    </React.Fragment>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title={t("home.no_notifications")}
                  noBorder={true}
                />
              )}
            </Card>
          </div>
        </div>
      </PageContainer>
    </MainLayout>
  );
}

export default Home; 